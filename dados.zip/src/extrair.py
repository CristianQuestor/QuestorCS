"""Casa os cancelamentos com as empresas do Chatwoot e extrai as conversas."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import cancelamentos as csvmod
from chatwoot import Chatwoot, ChatwootErro

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

# Campos da conversa que interessam ao dashboard. O resto e descartado
# para manter o arquivo em disco pequeno.
CAMPOS_CONVERSA = (
    "id", "status", "created_at", "updated_at", "last_activity_at",
    "first_reply_created_at", "waiting_since", "labels", "custom_attributes",
    "inbox_id", "priority", "csat_rating", "unread_count",
)


def nome_servico(conversa: dict) -> str | None:
    servico = conversa.get("service")
    if isinstance(servico, dict):
        return servico.get("name")
    return servico if isinstance(servico, str) else None


def enxugar(conversa: dict, id_contato: int) -> dict:
    magro = {campo: conversa.get(campo) for campo in CAMPOS_CONVERSA}
    magro["servico"] = nome_servico(conversa)
    magro["contato_id"] = id_contato
    atributos = conversa.get("custom_attributes") or {}
    magro["atributo_status"] = atributos.get("Status")
    magro["atributo_produto"] = atributos.get("produto")
    magro.pop("custom_attributes", None)
    return magro


# --------------------------------------------------------------- etapa 2
def resolver_empresa(api: Chatwoot, cancelamento: dict) -> dict:
    """Localiza a empresa no Chatwoot. Prioriza o CNPJ, cai para o nome."""
    documento = cancelamento["documento"]
    if documento:
        try:
            achados = api.buscar_empresa(documento)
        except ChatwootErro:
            achados = []
        for empresa in achados:
            if csvmod.so_digitos(empresa.get("registration_number")) == documento:
                return {"empresa": empresa, "criterio": "cnpj", "confiavel": True}

    # sem documento ou sem casamento exato: tenta pelo nome
    for termo in csvmod.termos_do_nome(cancelamento["cliente"]):
        try:
            achados = api.buscar_empresa(termo)
        except ChatwootErro:
            continue
        alvo = set(csvmod.termos_do_nome(cancelamento["cliente"], 5))
        for empresa in achados:
            nome = set(csvmod.termos_do_nome(empresa.get("name", ""), 8))
            if len(alvo & nome) >= 2:
                return {"empresa": empresa, "criterio": "nome", "confiavel": False}
    return {"empresa": None, "criterio": "nenhum", "confiavel": False}


def resolver_todas(api: Chatwoot, lista: list[dict]) -> list[dict]:
    resultado = []
    for i, cancelamento in enumerate(lista, 1):
        achado = resolver_empresa(api, cancelamento)
        empresa = achado["empresa"]
        registro = dict(cancelamento)
        registro["criterio_casamento"] = achado["criterio"]
        registro["casamento_confiavel"] = achado["confiavel"]
        if empresa:
            grupo = empresa.get("group_company") or {}
            registro.update(
                {
                    "empresa_id": empresa.get("id"),
                    "empresa_nome": empresa.get("name"),
                    "tier": grupo.get("name"),
                    "ambiente": (empresa.get("custom_attributes") or {}).get("ambiente"),
                    "contatos_total": empresa.get("contacts_count"),
                }
            )
        else:
            registro.update(
                {"empresa_id": None, "empresa_nome": None, "tier": None,
                 "ambiente": None, "contatos_total": 0}
            )
        resultado.append(registro)
        marca = {"cnpj": "ok", "nome": "~~", "nenhum": "XX"}[achado["criterio"]]
        print(f"  [{i:3}/{len(lista)}] {marca} {cancelamento['cliente'][:44]:44} "
              f"-> {registro['empresa_nome'] or 'NAO ENCONTRADA'}"[:120])
    return resultado


# --------------------------------------------------------------- etapa 3
def extrair_conversas(api: Chatwoot, empresas: list[dict]) -> dict[str, list[dict]]:
    """Conversas por empresa, deduplicadas por id."""
    por_empresa: dict[str, list[dict]] = {}
    alvos = [e for e in empresas if e.get("empresa_id")]
    for i, registro in enumerate(alvos, 1):
        id_empresa = registro["empresa_id"]
        try:
            detalhe = api.empresa(id_empresa)
        except ChatwootErro as exc:
            print(f"  [{i:3}/{len(alvos)}] ERRO empresa {id_empresa}: {exc}")
            por_empresa[str(id_empresa)] = []
            continue

        contatos = detalhe.get("contacts") or []
        vistas: set[int] = set()
        conversas: list[dict] = []
        for contato in contatos:
            try:
                brutas = api.conversas_do_contato(contato["id"])
            except ChatwootErro:
                continue
            for conversa in brutas:
                if conversa.get("id") in vistas:
                    continue
                vistas.add(conversa["id"])
                conversas.append(enxugar(conversa, contato["id"]))

        por_empresa[str(id_empresa)] = conversas
        print(f"  [{i:3}/{len(alvos)}] {registro['cliente'][:40]:40} "
              f"{len(contatos):3} contatos  {len(conversas):4} conversas")
    return por_empresa


# ---------------------------------------------------------------- execucao
def principal() -> None:
    inicio = time.time()
    DADOS.mkdir(parents=True, exist_ok=True)
    api = Chatwoot()

    print("== etapa 1: lendo a matriz de cancelamentos ==")
    lista = csvmod.ler()
    print(f"   {len(lista)} cancelamentos, arquivo {csvmod.achar_csv().name}\n")

    print("== etapa 2: casando empresas no Chatwoot ==")
    empresas = resolver_todas(api, lista)
    por_cnpj = sum(1 for e in empresas if e["criterio_casamento"] == "cnpj")
    por_nome = sum(1 for e in empresas if e["criterio_casamento"] == "nome")
    sem = [e["cliente"] for e in empresas if not e["empresa_id"]]
    print(f"\n   casadas por CNPJ: {por_cnpj}   por nome (revisar): {por_nome}   "
          f"nao encontradas: {len(sem)}")
    if sem:
        print(f"   pendentes: {sem}")
    (DADOS / "empresas.json").write_text(
        json.dumps(empresas, ensure_ascii=False, indent=2), encoding="utf-8")

    print("\n== etapa 3: extraindo conversas ==")
    conversas = extrair_conversas(api, empresas)
    total = sum(len(v) for v in conversas.values())
    (DADOS / "conversas.json").write_text(
        json.dumps(conversas, ensure_ascii=False), encoding="utf-8")

    print(f"\n== concluido em {time.time() - inicio:.0f}s ==")
    print(f"   {total} conversas de {len(conversas)} empresas")
    print(f"   {api.resumo()}")
    print(f"   dados/empresas.json e dados/conversas.json gravados")


if __name__ == "__main__":
    sys.exit(principal())
