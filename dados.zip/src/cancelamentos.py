"""Leitura e normalizacao da matriz de cancelamentos em CSV."""
from __future__ import annotations

import csv
import glob
import re
import unicodedata
from datetime import date, datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent


def achar_csv() -> Path:
    """Localiza a matriz de cancelamentos.

    Procura em entrada/ primeiro e depois na raiz do projeto, para que colar um
    arquivo novo na pasta seja suficiente. Havendo mais de um, vence o que
    mencionar cancelamento no nome e, em seguida, o mais recente.
    """
    candidatos = sorted(glob.glob(str(RAIZ / "entrada" / "*.csv"))
                        + glob.glob(str(RAIZ / "*.csv")))
    if not candidatos:
        raise FileNotFoundError(
            f"Nenhum CSV encontrado em {RAIZ / 'entrada'} nem em {RAIZ}"
        )
    preferidos = [c for c in candidatos if "cancelamento" in Path(c).name.lower()]
    escolha = preferidos or candidatos
    return Path(max(escolha, key=lambda c: Path(c).stat().st_mtime))


def so_digitos(texto: str | None) -> str:
    return re.sub(r"\D", "", texto or "")


def sem_acento(texto: str) -> str:
    return unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode()


def data_br(texto: str | None) -> date | None:
    texto = (texto or "").strip()
    for formato in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d"):
        try:
            return datetime.strptime(texto, formato).date()
        except ValueError:
            continue
    return None


def numero_br(texto: str | None) -> float | None:
    """Converte '1.234,56' para 1234.56."""
    texto = (texto or "").strip()
    if not texto:
        return None
    texto = re.sub(r"[^\d,.-]", "", texto).replace(".", "").replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        return None


def ler(caminho: Path | None = None) -> list[dict]:
    """Devolve os cancelamentos normalizados, ignorando linhas sem cliente."""
    caminho = caminho or achar_csv()
    with open(caminho, encoding="utf-8-sig", newline="") as fh:
        linhas = list(csv.DictReader(fh, delimiter=";"))

    registros: list[dict] = []
    for indice, linha in enumerate(linhas):
        linha = {(k or "").strip(): (v or "").strip() for k, v in linha.items()}
        cliente = linha.get("Cliente", "")
        if not cliente:
            continue
        data_cancelamento = data_br(linha.get("Data do cancelamento"))
        registros.append(
            {
                "linha": indice + 2,
                "cliente": cliente,
                "documento": so_digitos(linha.get("CNPJ / CPF")),
                "mes": linha.get("Mês"),
                "data_cancelamento": data_cancelamento.isoformat()
                if data_cancelamento
                else None,
                "produtos": linha.get("Produto(s)"),
                "tipo": linha.get("Tipo"),
                "status_quadro": linha.get("Status no quadro"),
                "motivo": linha.get("Motivo (tag)"),
                "relato": linha.get("Relato registrado"),
                "observacoes": linha.get("Observações Pedido (PipeRun)"),
                "squad": linha.get("Squad"),
                "origem": linha.get("Etapa / origem"),
                "ambiente_csv": linha.get("Ambiente"),
                "concorrente": linha.get("Concorrente"),
                "responsavel": linha.get("Responsável pelo registro"),
                "inicio_contrato": (data_br(linha.get("Início do contrato")) or "")
                and data_br(linha.get("Início do contrato")).isoformat(),
                "meses_contrato": numero_br(linha.get("Meses de contrato")),
                "anos_contrato": numero_br(linha.get("Tempo (anos)")),
                "maturidade": linha.get("Faixa de maturidade"),
                "mrr": numero_br(linha.get("MRR impactado")),
                "mrr_anual": numero_br(linha.get("MRR anualizado")),
                "link_piperun": linha.get("Link PipeRun"),
                "link_monday": linha.get("Link Monday"),
            }
        )
    return registros


PALAVRAS_VAZIAS = {
    "LTDA", "SS", "ME", "EPP", "EIRELI", "SA", "CIA", "DE", "DA", "DO",
    "DOS", "DAS", "E", "MEI", "SC", "MATRIZ", "MUNICIPAL",
}


def termos_do_nome(nome: str, quantidade: int = 3) -> list[str]:
    """Tokens distintivos do nome, para busca quando nao ha documento."""
    limpo = sem_acento(nome).upper()
    tokens = [
        t for t in re.split(r"[^A-Z0-9]+", limpo)
        if len(t) > 2 and t not in PALAVRAS_VAZIAS
    ]
    return tokens[:quantidade]


if __name__ == "__main__":
    dados = ler()
    sem_doc = [d for d in dados if not d["documento"]]
    print(f"arquivo........: {achar_csv().name}")
    print(f"cancelamentos..: {len(dados)}")
    print(f"sem documento..: {len(sem_doc)} -> {[d['cliente'] for d in sem_doc]}")
    print(f"com data.......: {sum(1 for d in dados if d['data_cancelamento'])}")
    print(f"com MRR........: {sum(1 for d in dados if d['mrr'])}")
    print(f"MRR total......: R$ {sum(d['mrr'] or 0 for d in dados):,.2f}")
