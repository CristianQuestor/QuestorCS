"""Junta a analise de atrito ao painel, comparando churn com o grupo de controle.

Duas decisoes de metodo que mudam o resultado e por isso ficam explicitas:

1. So entram conversas abertas ANTES da data de cancelamento. Chamado aberto
   depois da saida existe nos cancelamentos parciais e nao explica a saida.
2. O grupo de controle e recortado na mesma faixa de datas do grupo de churn.
   Comparar maio-agosto com maio-setembro colocaria um mes a mais de um lado e
   a diferenca poderia ser so calendario.
"""
from __future__ import annotations

import json
import math
from collections import Counter
from datetime import date, datetime, timezone
from pathlib import Path

import confronto
import precisao
from atrito import (TEMAS, analisar_texto, analise_guardada,
                    validar_contra_csat)
from chatwoot import link_conversa

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

MIN_CONVERSAS_TEMA = 8      # abaixo disso a taxa e ruido, nao evidencia
MAX_EVIDENCIAS = 6          # trechos guardados por tema


def teste_duas_proporcoes(x1: int, n1: int, x2: int, n2: int) -> dict | None:
    """Teste z para diferenca entre duas proporcoes.

    Existe para impedir que uma diferenca de amostra pequena seja lida como
    descoberta. Sem isso, um tema com 16 ocorrencias de um lado e 25 do outro
    vira "1,37x mais" e alguem toma decisao em cima de ruido.
    """
    if n1 < 30 or n2 < 30:
        return None
    p1, p2 = x1 / n1, x2 / n2
    p = (x1 + x2) / (n1 + n2)
    if p <= 0 or p >= 1:
        return None

    # A aproximacao normal so vale com contagem esperada suficiente dos dois
    # lados. Sem esta checagem, 4 ocorrencias contra 1 davam "8,47x mais, p =
    # 0,02" e viravam descoberta. Sao 5 chamados no total: nao da para concluir.
    esperado_minimo = min(n1 * p, n1 * (1 - p), n2 * p, n2 * (1 - p))
    if esperado_minimo < 5:
        return {"z": None, "p": None, "significativo": False,
                "invalido": "amostra pequena demais para o teste"}

    erro = math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2))
    if erro == 0:
        return None
    z = (p1 - p2) / erro
    # normal padrao bicaudal, sem dependencia externa
    valor_p = math.erfc(abs(z) / math.sqrt(2))
    return {"z": round(z, 2), "p": round(valor_p, 4), "significativo": valor_p < 0.05}


def _data(marca):
    """Epoch para data local, igual ao resto do projeto."""
    try:
        return datetime.fromtimestamp(int(marca)).date()
    except (TypeError, ValueError, OSError):
        return None


def _carregar(nome):
    caminho = DADOS / nome
    if not caminho.exists():
        return None
    return json.loads(caminho.read_text(encoding="utf-8"))


def _taxas(ids, analises):
    """Quantas conversas com texto tocam cada tema, e a proporcao."""
    porTema = Counter()
    escores = []
    com_texto = 0
    for cid in ids:
        registro = analises.get(cid)
        if not registro:
            continue
        a = analise_guardada(registro)
        if a["mensagens_cliente"] == 0:
            continue
        com_texto += 1
        escores.append(a["escore"])
        for chave in a["temas"]:
            porTema[chave] += 1
    return {
        "conversas_com_texto": com_texto,
        "por_tema": dict(porTema),
        "taxa": {c: round(n / com_texto, 4) for c, n in porTema.items()} if com_texto else {},
        "escore_medio": round(sum(escores) / len(escores), 2) if escores else 0,
    }


def temas_por_satisfacao(conversas: list[dict], analises: dict) -> dict:
    """Quais temas aparecem nos chamados que o cliente avaliou mal.

    O CSAT e o unico sentimento declarado pelo proprio cliente que existe nesta
    base. Em vez de inferir humor a partir de palavras, esta funcao usa a nota
    como verdade e pergunta sobre o que falavam os chamados com nota baixa.
    """
    ruins, bons = Counter(), Counter()
    n_ruins = n_bons = 0
    exemplos: dict[str, list[dict]] = {}
    for cv in conversas:
        nota = cv.get("csat_rating")
        if not str(nota or "").isdigit():
            continue
        nota = int(nota)
        if nota == 3:
            continue
        registro = analises.get(cv["id"])
        if not registro:
            continue
        a = analise_guardada(registro)
        if a["mensagens_cliente"] == 0:
            continue
        alvo, ruim = (ruins, True) if nota <= 2 else (bons, False)
        if ruim:
            n_ruins += 1
        else:
            n_bons += 1
        for chave, trechos in a["temas"].items():
            alvo[chave] += 1
            if ruim and len(exemplos.setdefault(chave, [])) < 4:
                exemplos[chave].append({
                    "conversa": cv["id"], "link": link_conversa(cv["id"]),
                    "csat": nota, "servico": cv.get("servico"),
                    "trecho": trechos[0],
                })

    # abaixo de 30 o teste de proporcoes nem roda. Mostrar "2,24x" apoiado em
    # 4 chamados seria convidar alguem a decidir em cima de ruido.
    if n_ruins < 30 or n_bons < 30:
        return {"suficiente": False, "n_ruins": n_ruins, "n_bons": n_bons,
                "taxa_detratores": round(n_ruins / (n_ruins + n_bons), 4)
                if (n_ruins + n_bons) else None}

    linhas = []
    for chave, meta in TEMAS.items():
        t_ruim = ruins.get(chave, 0) / n_ruins
        t_bom = bons.get(chave, 0) / n_bons
        linha_sat = {
            "tema": chave, "rotulo": meta["rotulo"],
            "n_ruins": ruins.get(chave, 0), "taxa_ruins": round(t_ruim, 4),
            "n_bons": bons.get(chave, 0), "taxa_bons": round(t_bom, 4),
            "lift": round(t_ruim / t_bom, 2) if t_bom > 0 else None,
            "teste": teste_duas_proporcoes(
                ruins.get(chave, 0), n_ruins, bons.get(chave, 0), n_bons),
        }
        linha_sat["confiavel"] = bool(
            linha_sat["teste"] and linha_sat["teste"]["significativo"])
        linhas.append(linha_sat)
    linhas.sort(key=lambda x: (x["lift"] is None, -(x["lift"] or 0)))
    return {
        "suficiente": True, "n_ruins": n_ruins, "n_bons": n_bons,
        "linhas": linhas, "exemplos": {k: v for k, v in exemplos.items() if v},
    }


def construir(clientes: list[dict], con=None) -> dict:
    """Monta a analise de atrito lendo do banco restaurado.

    O grupo de controle deixou de ser amostra: passa a ser todo cliente que nao
    cancelou, na mesma faixa de datas do grupo de churn.
    """
    import banco
    import fonte

    fechar = con is None
    con = con or banco.abrir()
    try:
        return _construir(clientes, con, banco, fonte)
    finally:
        if fechar:
            con.close()


def _construir(clientes, con, banco, fonte) -> dict:
    empresas_churn = [c["empresa_id"] for c in clientes if c.get("empresa_id")]
    conversas_churn = banco.conversas_por_empresa(con, empresas_churn)

    # ------------------------------------------------ grupo de churn
    # so conversas abertas antes da data de cancelamento
    ids_churn = []
    datas_churn = []
    vistos_churn: set = set()
    por_cliente = {}
    for c in clientes:
        if not c.get("empresa_id"):
            continue
        corte = date.fromisoformat(c["data_cancelamento"]) if c.get("data_cancelamento") else None
        meus = []
        for cv in conversas_churn.get(str(c["empresa_id"]), []):
            aberta = _data(cv.get("created_at"))
            if corte and aberta and aberta <= corte:
                meus.append(cv)
        por_cliente[c["linha"]] = meus
        # duas linhas do CSV podem apontar a mesma empresa (cancelamento parcial
        # de produtos diferentes). Sem deduplicar, as conversas entram duas vezes
        # e inflam o n do teste estatistico.
        for cv in meus:
            if cv["id"] in vistos_churn:
                continue
            vistos_churn.add(cv["id"])
            ids_churn.append(cv["id"])
            d = _data(cv.get("created_at"))
            if d:
                datas_churn.append(d)

    # a analise do lexico ja esta gravada; aqui so se busca a das conversas
    # que entram em cada grupo
    analises = fonte.analises(con, ids_churn)
    churn = _taxas(ids_churn, analises)

    # ------------------------------------------------ grupo de controle
    controle = None
    controle_conversas = {}
    if datas_churn:
        inicio, fim = min(datas_churn), max(datas_churn)
        controle_conversas = fonte.conversas_do_controle(
            con, inicio, fim, set(empresas_churn))
        ids_controle = [cv["id"] for lista in controle_conversas.values()
                        for cv in lista]
        analises.update(fonte.analises(con, ids_controle))
        controle = _taxas(ids_controle, analises)
        controle["janela"] = [inicio.isoformat(), fim.isoformat()]
        controle["empresas"] = len(controle_conversas)

    # ------------------------------------------------ comparacao
    comparacao = []
    for chave, meta in TEMAS.items():
        n_churn = churn["por_tema"].get(chave, 0)
        taxa_churn = churn["taxa"].get(chave, 0)
        linha = {
            "tema": chave,
            "rotulo": meta["rotulo"],
            "n_churn": n_churn,
            "taxa_churn": taxa_churn,
            "n_controle": None,
            "taxa_controle": None,
            "lift": None,
            "confiavel": n_churn >= MIN_CONVERSAS_TEMA,
        }
        if controle:
            n_ctrl = controle["por_tema"].get(chave, 0)
            taxa_ctrl = controle["taxa"].get(chave, 0)
            linha["n_controle"] = n_ctrl
            linha["taxa_controle"] = taxa_ctrl
            if taxa_ctrl > 0:
                linha["lift"] = round(taxa_churn / taxa_ctrl, 2)
            teste = teste_duas_proporcoes(
                n_churn, churn["conversas_com_texto"],
                n_ctrl, controle["conversas_com_texto"])
            linha["teste"] = teste
            # so e "confiavel" o que passa no teste. Amostra grande sozinha nao
            # basta: a diferenca precisa ser maior do que o acaso explica.
            linha["confiavel"] = bool(teste and teste["significativo"])
        comparacao.append(linha)
    comparacao.sort(key=lambda x: (x["lift"] is None, -(x["lift"] or 0)))

    # ------------------------------------------------ evidencias por tema
    evidencias = {chave: [] for chave in TEMAS}
    indice = {}
    for c in clientes:
        for cv in por_cliente.get(c["linha"], []):
            indice[cv["id"]] = (c, cv)
    ordenado = sorted(
        indice.items(),
        key=lambda par: 0 if any(
            s not in (None, "indefinido")
            for s in ((analises.get(par[0]) or {}).get("sujeitos") or {}).values()
        ) else 1,
    )
    for cid, (cliente, cv) in ordenado:
        registro = analises.get(cid)
        if not registro:
            continue
        a = analise_guardada(registro)
        for chave, trechos in a["temas"].items():
            if len(evidencias[chave]) >= MAX_EVIDENCIAS:
                continue
            evidencias[chave].append({
                "cliente": cliente["cliente"],
                "sujeito": a.get("sujeitos", {}).get(chave),
                "origem": a.get("origens", {}).get(chave),
                "conversa": cid,
                "link": link_conversa(cid),
                "data": (_data(cv.get("created_at")) or "").isoformat()
                        if _data(cv.get("created_at")) else None,
                "csat": cv.get("csat_rating"),
                "servico": cv.get("servico"),
                "trecho": trechos[0],
            })

    # ------------------------------------------------ o relato do cancelamento
    # "mencao a cancelar" e tautologico num registro de cancelamento
    relato_temas = Counter()
    for c in clientes:
        texto = " ".join(filter(None, [c.get("relato"), c.get("observacoes")]))
        if not texto:
            continue
        achados = analisar_texto(texto)["temas"]
        achados.pop("ameaca_saida", None)
        c["relato_temas"] = sorted(achados)
        for chave in achados:
            relato_temas[chave] += 1

    # ------------------------------------------------ confronto relato x chamados
    # so entram como tema de risco os que passaram no teste de proporcoes e
    # aparecem MAIS em quem saiu. O resto e taxa de fundo do suporte.
    discriminantes = frozenset(
        l["tema"] for l in comparacao
        if l.get("confiavel") and (l.get("lift") or 0) > 1
    )
    for c in clientes:
        c["confronto"] = confronto.confrontar(
            c, por_cliente.get(c["linha"], []), analises, discriminantes)

    # ------------------------------------------------ atrito por cliente
    for c in clientes:
        meus = por_cliente.get(c["linha"], [])
        perfil = _taxas([cv["id"] for cv in meus], analises)
        trechos = []
        for cv in meus:
            registro = analises.get(cv["id"])
            if not registro:
                continue
            a = analise_guardada(registro)
            for chave, achados in a["temas"].items():
                trechos.append({
                    "tema": chave,
                    "sujeito": a.get("sujeitos", {}).get(chave),
                    "origem": a.get("origens", {}).get(chave),
                    "conversa": cv["id"],
                    "link": link_conversa(cv["id"]),
                    "trecho": achados[0],
                })
        trechos.sort(key=lambda t: -TEMAS[t["tema"]]["peso"])
        c["atrito"] = {
            "conversas_com_texto": perfil["conversas_com_texto"],
            "escore_medio": perfil["escore_medio"],
            "por_tema": perfil["por_tema"],
            "trechos": trechos[:8],
        }

    # ------------------------------------------------ de que e a queixa
    # "esta lento" nao diz o que esta lento. Esta contagem responde a pergunta
    # que o time faz ao ler o trecho, e separa o que e problema do produto do
    # que e maquina do cliente ou portal de terceiro.
    por_origem = Counter()

    def contar_sujeitos(ids):
        fora = Counter()
        for cid in ids:
            reg = analises.get(cid)
            if not reg:
                continue
            origens = reg.get("origens") or {}
            for chave, suj in (reg.get("sujeitos") or {}).items():
                fora[(chave, suj or "indefinido")] += 1
                por_origem[(chave, origens.get(chave) or "nenhuma")] += 1
        return fora

    sujeitos_churn = contar_sujeitos(ids_churn)
    sujeitos_base = contar_sujeitos(ids_churn + [
        cv["id"] for lista in controle_conversas.values() for cv in lista])

    def arrumar(contagem):
        saida = {}
        for (tema, suj), n in contagem.items():
            saida.setdefault(tema, {})[suj] = n
        return saida

    # ------------------------------------------------ validacao do lexico
    # usa todas as conversas com texto, dos dois grupos: a pergunta aqui nao e
    # sobre churn, e sim se o lexico acerta o sentimento que o cliente declarou
    # no CSAT. Quanto maior a amostra, mais honesta a resposta.
    universo = [cv for lista in conversas_churn.values() for cv in lista]
    universo += [cv for lista in controle_conversas.values() for cv in lista]
    validacao = validar_contra_csat(universo, analises)
    satisfacao = temas_por_satisfacao(universo, analises)

    return {
        "disponivel": True,
        "temas": {c: m["rotulo"] for c, m in TEMAS.items()},
        "pesos": {c: m["peso"] for c, m in TEMAS.items()},
        "churn": churn,
        "controle": controle,
        "comparacao": comparacao,
        "evidencias": {c: v for c, v in evidencias.items() if v},
        "relato_temas": dict(relato_temas),
        "relatos_analisados": sum(1 for c in clientes if c.get("relato")),
        "validacao": validacao,
        "satisfacao": satisfacao,
        "sujeitos": {
            "rotulos": precisao.ROTULOS_SUJEITO,
            "do_produto": sorted(precisao.DO_PRODUTO),
            "churn": arrumar(sujeitos_churn),
            "base": arrumar(sujeitos_base),
            "origens": arrumar(por_origem),
            "rotulos_origem": precisao.ROTULOS_ORIGEM,
            "origem_direta": sorted(precisao.ORIGEM_DIRETA),
        },
        "discriminantes": sorted(discriminantes),
        "vereditos": {k: v[0] for k, v in confronto.VEREDITOS.items()},
        "classes_veredito": {k: v[1] for k, v in confronto.VEREDITOS.items()},
        "regra_repeticao": [confronto.REPETICAO_QUE_VIRA_CASO,
                            confronto.JANELA_REPETICAO_DIAS],
        "minimo_confiavel": MIN_CONVERSAS_TEMA,
    }
