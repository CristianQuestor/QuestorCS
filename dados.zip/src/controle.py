"""Monta um grupo de controle de clientes que NAO cancelaram.

Sem isso, dizer que 65% dos chamados de quem cancelou mencionam erro nao
significa nada: todo chamado de suporte e, por definicao, alguem que nao
conseguiu fazer algo. O numero so vira evidencia quando comparado com a mesma
medida entre clientes que ficaram.

O sorteio e estratificado por tier, para que o grupo de controle tenha a mesma
composicao do grupo que cancelou e a comparacao nao confunda churn com perfil
de cliente.
"""
from __future__ import annotations

import json
import random
import re
import sys
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from chatwoot import Chatwoot, ChatwootErro
from extrair import enxugar

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

POR_CANCELADO = 2        # empresas de controle para cada empresa que cancelou
SEMENTE = 20260914       # sorteio reprodutivel
TRABALHADORES = 4


def so_digitos(t) -> str:
    return re.sub(r"\D", "", t or "")


def paginas_de_empresas(api: Chatwoot, quantas: int, total_paginas: int) -> list[dict]:
    """Sorteia paginas do cadastro e devolve as empresas encontradas nelas."""
    sorteio = random.Random(SEMENTE)
    paginas = sorteio.sample(range(1, total_paginas + 1), min(quantas, total_paginas))
    achadas: list[dict] = []

    def puxar(p):
        try:
            return api.get(f"/companies?page={p}").get("payload", [])
        except ChatwootErro:
            return []

    with ThreadPoolExecutor(max_workers=TRABALHADORES) as piscina:
        for futuro in as_completed([piscina.submit(puxar, p) for p in paginas]):
            achadas.extend(futuro.result())
    return achadas


def escolher(candidatas: list[dict], alvo_por_tier: Counter,
             excluir: set[str]) -> list[dict]:
    """Seleciona empresas respeitando a composicao de tier desejada."""
    sorteio = random.Random(SEMENTE)
    sorteio.shuffle(candidatas)
    escolhidas: list[dict] = []
    contagem: Counter = Counter()
    for empresa in candidatas:
        if so_digitos(empresa.get("registration_number")) in excluir:
            continue
        if not empresa.get("contacts_count"):
            continue
        tier = (empresa.get("group_company") or {}).get("name") or "Nao informado"
        if contagem[tier] >= alvo_por_tier.get(tier, 0):
            continue
        contagem[tier] += 1
        escolhidas.append(empresa)
    return escolhidas


def principal() -> int:
    api = Chatwoot()
    cancelados = json.loads((DADOS / "empresas.json").read_text(encoding="utf-8"))
    excluir = {so_digitos(c["documento"]) for c in cancelados if c["documento"]}
    excluir |= {str(c["empresa_id"]) for c in cancelados if c.get("empresa_id")}

    # mesma composicao de tier do grupo que cancelou, multiplicada
    tiers = Counter((c.get("tier") or "Nao informado") for c in cancelados)
    alvo = Counter({t: n * POR_CANCELADO for t, n in tiers.items()})
    quantas = sum(alvo.values())
    print(f"alvo do controle: {quantas} empresas")
    print(f"  composicao: {dict(alvo)}\n")

    meta = api.get("/companies?page=1").get("meta", {})
    total_paginas = meta.get("total_pages", 369)

    # sorteia paginas com folga, porque muitas empresas nao tem contato
    candidatas: list[dict] = []
    vistas: set[int] = set()
    rodada = 0
    while rodada < 6:
        rodada += 1
        novas = paginas_de_empresas(api, 60, total_paginas)
        for e in novas:
            if e["id"] not in vistas:
                vistas.add(e["id"])
                candidatas.append(e)
        escolhidas = escolher(list(candidatas), alvo, excluir)
        print(f"  rodada {rodada}: {len(candidatas)} candidatas, "
              f"{len(escolhidas)} selecionadas")
        if len(escolhidas) >= quantas * 0.8:
            break

    escolhidas = escolher(list(candidatas), alvo, excluir)
    print(f"\nselecionadas: {len(escolhidas)} empresas de controle")
    print(f"  por tier: {dict(Counter((e.get('group_company') or {}).get('name') for e in escolhidas))}")

    # conversas de cada empresa de controle
    print("\nextraindo conversas do controle...")
    inicio = time.time()
    resultado: dict[str, list[dict]] = {}
    registro: list[dict] = []

    def puxar_empresa(e):
        try:
            detalhe = api.empresa(e["id"])
        except ChatwootErro:
            return e, []
        conversas, vistas_c = [], set()
        for contato in detalhe.get("contacts") or []:
            try:
                brutas = api.conversas_do_contato(contato["id"])
            except ChatwootErro:
                continue
            for cv in brutas:
                if cv["id"] in vistas_c:
                    continue
                vistas_c.add(cv["id"])
                conversas.append(enxugar(cv, contato["id"]))
        return e, conversas

    feitas = 0
    with ThreadPoolExecutor(max_workers=TRABALHADORES) as piscina:
        futuros = [piscina.submit(puxar_empresa, e) for e in escolhidas]
        for futuro in as_completed(futuros):
            e, conversas = futuro.result()
            resultado[str(e["id"])] = conversas
            registro.append({
                "empresa_id": e["id"],
                "empresa_nome": e.get("name"),
                "documento": so_digitos(e.get("registration_number")),
                "tier": (e.get("group_company") or {}).get("name"),
                "ambiente": (e.get("custom_attributes") or {}).get("ambiente"),
                "contatos_total": e.get("contacts_count"),
                "conversas": len(conversas),
            })
            feitas += 1
            if feitas % 20 == 0 or feitas == len(escolhidas):
                print(f"  {feitas}/{len(escolhidas)} empresas, "
                      f"{sum(len(v) for v in resultado.values())} conversas")

    (DADOS / "controle-empresas.json").write_text(
        json.dumps(registro, ensure_ascii=False, indent=2), encoding="utf-8")
    (DADOS / "controle-conversas.json").write_text(
        json.dumps(resultado, ensure_ascii=False), encoding="utf-8")

    total = sum(len(v) for v in resultado.values())
    print(f"\nconcluido em {(time.time() - inicio) / 60:.1f} min")
    print(f"  {len(registro)} empresas, {total} conversas")
    print(f"  {api.resumo()}")
    return 0


if __name__ == "__main__":
    sys.exit(principal())
