"""Calcula as metricas do dashboard a partir dos dados extraidos."""
from __future__ import annotations

import json
import os
import statistics
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from pathlib import Path

import sintese
from chatwoot import link_conversa

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

JANELA_LONGA = 365    # dias de historico antes do cancelamento
JANELA_RISCO = 90     # dias usados nos indicadores de risco

# A base do Chatwoot so tem conversas a partir de uma certa data. Cancelamentos
# anteriores a ela nao tem historico possivel, e contar zero chamados nesses
# casos seria ler falta de dado como falta de atendimento. O inicio real e
# descoberto a partir dos proprios dados, nunca fixado no codigo.
COBERTURA_MINIMA = 30   # dias de historico exigidos para analisar um cliente
FRACAO_RAMPA = 0.10     # da mediana diaria, para achar a entrada em producao
CONTA = int(os.getenv("CHATWOOT_ACCOUNT", "3"))


def inicio_da_base(conversas_por_empresa, con=None):
    """Data em que a instancia entrou em producao, medida pela rampa de volume.

    A primeira conversa da conta e de 25/02/2026, mas fevereiro tem 3 conversas,
    marco tem 52 e abril tem 784: foi piloto. Em 05/05 o volume salta de 60 para
    634 por dia e se estabiliza. Usar 25/02 como inicio faria um cancelamento de
    marco parecer "cliente que nunca procurou o suporte", quando na verdade o
    suporte ainda nao estava ali.

    A regra: primeiro dia em que a media movel de 7 dias alcanca 10% da mediana
    da serie. E um corte generoso, e ainda assim cai exatamente no salto.
    """
    if con is not None:
        with con.cursor() as cur:
            cur.execute("""
                with dia as (select created_at::date d, count(*) n
                               from conversations where account_id = %s group by 1)
                select d, avg(n) over (order by d rows between 6 preceding and current row)
                  from dia order by d
            """, (CONTA,))
            serie = [(d, float(m)) for d, m in cur.fetchall()]
        if serie:
            mediana = sorted(m for _, m in serie)[len(serie) // 2]
            alvo = mediana * FRACAO_RAMPA
            for d, m in serie:
                if m >= alvo:
                    return d
    marcas = [c["created_at"] for lista in conversas_por_empresa.values()
              for c in lista if c.get("created_at")]
    return para_data(min(marcas)) if marcas else None


def classificar_cobertura(dias):
    if dias is None:
        return "desconhecida"
    if dias >= JANELA_LONGA * 0.8:
        return "completa"
    if dias >= COBERTURA_MINIMA:
        return "parcial"
    return "insuficiente"


def para_data(marca):
    """Epoch para data local, igual ao resto do projeto."""
    if not marca:
        return None
    try:
        return datetime.fromtimestamp(int(marca)).date()
    except (ValueError, OSError, TypeError):
        return None


def media(valores):
    return round(statistics.fmean(valores), 2) if valores else None


def horas_entre(inicio, fim):
    if not inicio or not fim:
        return None
    delta = (int(fim) - int(inicio)) / 3600
    return round(delta, 2) if 0 <= delta < 24 * 90 else None


# ------------------------------------------------------- metricas por cliente
def metricas_cliente(cancelamento, conversas, inicio_base=None):
    corte = None
    if cancelamento.get("data_cancelamento"):
        corte = date.fromisoformat(cancelamento["data_cancelamento"])

    # quantos dias de historico existiam na base antes deste cancelamento
    dias_observaveis = None
    if corte and inicio_base:
        dias_observaveis = max(0, (corte - inicio_base).days)
    cobertura = classificar_cobertura(dias_observaveis)

    enriquecidas = []
    for c in conversas:
        aberta = para_data(c.get("created_at"))
        dias = (corte - aberta).days if (corte and aberta) else None
        enriquecidas.append({
            **c,
            "data": aberta.isoformat() if aberta else None,
            "dias_antes": dias,
        })

    def na_janela(limite):
        return [c for c in enriquecidas
                if c["dias_antes"] is not None and 0 <= c["dias_antes"] <= limite]

    longa = na_janela(JANELA_LONGA)
    risco = na_janela(JANELA_RISCO)
    anterior = [c for c in enriquecidas if c["dias_antes"] is not None
                and JANELA_RISCO < c["dias_antes"] <= JANELA_LONGA]

    def notas_de(lista):
        return [int(c["csat_rating"]) for c in lista
                if str(c.get("csat_rating") or "").isdigit()]

    notas = notas_de(enriquecidas)
    notas_risco = notas_de(risco)

    # linha do tempo: blocos de 30 dias, de -12 ate 0
    linha = {str(-m): 0 for m in range(12, -1, -1)}
    for c in enriquecidas:
        if c["dias_antes"] is None or not (0 <= c["dias_antes"] <= JANELA_LONGA):
            continue
        bloco = str(-(c["dias_antes"] // 30))
        if bloco in linha:
            linha[bloco] += 1

    # blocos de 30 dias que a base realmente cobre. O resto do grafico e
    # ausencia de dado, nao ausencia de chamado.
    blocos_observaveis = (
        min(13, dias_observaveis // 30 + 1) if dias_observaveis is not None else 13
    )

    # ritmo de chamados nos 90 dias finais contra os 9 meses anteriores
    ritmo_risco = len(risco) / 3
    ritmo_base = len(anterior) / 9 if anterior else 0
    escalada = round(ritmo_risco / ritmo_base, 2) if ritmo_base > 0 else None

    respostas = [h for h in (horas_entre(c.get("created_at"),
                                         c.get("first_reply_created_at"))
                             for c in enriquecidas) if h is not None]

    produtos = Counter(c["atributo_produto"] for c in longa if c.get("atributo_produto"))
    servicos = Counter(c["servico"] for c in longa if c.get("servico"))
    situacoes = Counter(c["atributo_status"] for c in longa if c.get("atributo_status"))
    etiquetas = Counter(t for c in longa for t in (c.get("labels") or []))
    top_servico = servicos.most_common(1)[0] if servicos else None

    detalhadas = sorted(
        [
            {
                "id": c["id"],
                "data": c["data"],
                "dias_antes": c["dias_antes"],
                "status": c.get("status"),
                "produto": c.get("atributo_produto"),
                "servico": c.get("servico"),
                "situacao": c.get("atributo_status"),
                "csat": c.get("csat_rating"),
                "labels": c.get("labels") or [],
                "link": link_conversa(c["id"]),
            }
            for c in enriquecidas if c["data"]
        ],
        key=lambda x: x["data"],
        reverse=True,
    )

    return {
        "dias_observaveis": dias_observaveis,
        "cobertura": cobertura,
        "blocos_observaveis": blocos_observaveis,
        "conversas_total": len(enriquecidas),
        "conversas_12m": len(longa),
        "conversas_90d": len(risco),
        "conversas_90a365d": len(anterior),
        "escalada": escalada,
        "csat_media": media([float(n) for n in notas]),
        "csat_media_90d": media([float(n) for n in notas_risco]),
        "csat_notas": len(notas),
        "csat_detratores": sum(1 for n in notas if n <= 2),
        "primeira_resposta_h": media(respostas),
        "produtos": produtos.most_common(6),
        "servicos": servicos.most_common(6),
        "situacoes": situacoes.most_common(6),
        "etiquetas": etiquetas.most_common(6),
        "servico_reincidente": list(top_servico) if top_servico else None,
        "linha_tempo": linha,
        "conversas": detalhadas[:400],
    }


def sinais_de_risco(m):
    """Rotulos curtos que explicam por que o cliente merecia atencao."""
    if m["cobertura"] == "insuficiente":
        # cancelou antes de a base ter historico: nada a concluir
        return ["Fora da janela"]
    if m["conversas_total"] == 0:
        return ["Sem chamado"]
    sinais = []
    if m["escalada"] and m["escalada"] >= 1.5:
        sinais.append("Chamados em alta")
    if m["csat_media"] is not None and m["csat_media"] < 3.5:
        sinais.append("CSAT baixo")
    if m["csat_detratores"] >= 2:
        sinais.append("Detratores")
    if m["servico_reincidente"] and m["servico_reincidente"][1] >= 4:
        sinais.append("Assunto reincidente")
    if m["primeira_resposta_h"] is not None and m["primeira_resposta_h"] > 8:
        sinais.append("Resposta lenta")
    return sinais


# ------------------------------------------------------------------ agregados
CAMPOS_CLIENTE = (
    "linha", "cliente", "documento", "mes", "data_cancelamento", "produtos",
    "tipo", "status_quadro", "motivo", "relato", "observacoes", "squad",
    "origem", "concorrente", "responsavel", "anos_contrato", "maturidade",
    "mrr", "mrr_anual", "link_piperun", "link_monday", "empresa_id",
    "empresa_nome", "tier", "ambiente", "criterio_casamento",
)


def construir():
    """Monta o painel lendo do banco restaurado do Chatwoot."""
    import banco
    import cancelamentos as csvmod
    import fonte

    with banco.conexao() as con:
        empresas = fonte.cancelamentos_casados(con, csvmod.ler())
        ids = [e["empresa_id"] for e in empresas if e.get("empresa_id")]
        conversas = banco.conversas_por_empresa(con, ids)
        return _construir(empresas, conversas, con)


def _construir(empresas, conversas, con):

    inicio_base = inicio_da_base(conversas, con)

    clientes = []
    for registro in empresas:
        minhas = conversas.get(str(registro.get("empresa_id")), [])
        m = metricas_cliente(registro, minhas, inicio_base)
        clientes.append({
            **{k: registro.get(k) for k in CAMPOS_CLIENTE},
            "metricas": m,
            "sinais": sinais_de_risco(m),
        })

    clientes.sort(key=lambda c: c["data_cancelamento"] or "")

    def soma(campo, filtro=None):
        alvo = [c for c in clientes if filtro is None or filtro(c)]
        return round(sum(c[campo] or 0 for c in alvo), 2)

    def contar(chave):
        return Counter(chave(c) or "Nao informado" for c in clientes).most_common()

    por_mes = defaultdict(lambda: {"quantidade": 0, "mrr": 0.0})
    for c in clientes:
        if c["data_cancelamento"]:
            chave = c["data_cancelamento"][:7]
            por_mes[chave]["quantidade"] += 1
            por_mes[chave]["mrr"] = round(por_mes[chave]["mrr"] + (c["mrr"] or 0), 2)

    # so entram na leitura de churn os clientes com historico suficiente na base
    analisaveis = [c for c in clientes if c["metricas"]["cobertura"] != "insuficiente"]
    fora = [c for c in clientes if c["metricas"]["cobertura"] == "insuficiente"]
    com_chamado = [c for c in analisaveis if c["metricas"]["conversas_total"] > 0]
    sem_chamado = [c for c in analisaveis if c["metricas"]["conversas_total"] == 0]
    notas = [c["metricas"]["csat_media"] for c in com_chamado
             if c["metricas"]["csat_media"] is not None]

    linha_geral = {str(-m): 0 for m in range(12, -1, -1)}
    observaveis_por_bloco = {str(-m): 0 for m in range(12, -1, -1)}
    for c in analisaveis:
        for m_ in range(13):
            if m_ < c["metricas"]["blocos_observaveis"]:
                observaveis_por_bloco[str(-m_)] += 1

    produtos_gerais = Counter()
    servicos_gerais = Counter()
    for c in com_chamado:
        for bloco, valor in c["metricas"]["linha_tempo"].items():
            linha_geral[bloco] += valor
        produtos_gerais.update(dict(c["metricas"]["produtos"]))
        servicos_gerais.update(dict(c["metricas"]["servicos"]))

    media_12m = 0
    if com_chamado:
        media_12m = round(
            statistics.fmean([c["metricas"]["conversas_12m"] for c in com_chamado]), 1
        )

    # a analise de atrito precisa do texto das conversas e escreve dentro de
    # cada cliente, por isso roda depois de os clientes estarem montados
    atrito = sintese.construir(clientes, con)

    # a tela de Atencao usa a mesma regra validada na analise de churn, entao
    # recebe os temas que passaram no teste em vez de ter lista propria
    try:
        import atencao as _atencao
        vigilancia = _atencao.construir(set(atrito.get("discriminantes") or []))
    except FileNotFoundError:
        vigilancia = {"disponivel": False, "motivo": "varredura da base nao encontrada"}

    import banco as _banco
    return {
        "atrito": atrito,
        "atencao": vigilancia,
        "base": _banco.resumo(con),
        "gerado_em": datetime.now().isoformat(timespec="seconds"),
        "janela_longa_dias": JANELA_LONGA,
        "janela_risco_dias": JANELA_RISCO,
        "inicio_base": inicio_base.isoformat() if inicio_base else None,
        "cobertura_minima_dias": COBERTURA_MINIMA,
        "resumo": {
            "cancelamentos": len(clientes),
            "analisaveis": len(analisaveis),
            "fora_da_janela": len(fora),
            "empresas_casadas": sum(1 for c in clientes if c["empresa_id"]),
            "mrr_total": soma("mrr"),
            "mrr_anual_total": soma("mrr_anual"),
            "conversas_total": sum(c["metricas"]["conversas_total"] for c in clientes),
            "conversas_12m": sum(c["metricas"]["conversas_12m"] for c in clientes),
            "com_chamado": len(com_chamado),
            "sem_chamado": len(sem_chamado),
            "mrr_sem_chamado": soma(
                "mrr", lambda c: c["metricas"]["conversas_total"] == 0
            ),
            "csat_medio": media(notas),
            "media_chamados_12m": media_12m,
        },
        "por_mes": [{"mes": k, **v} for k, v in sorted(por_mes.items())],
        "por_motivo": contar(lambda c: c["motivo"]),
        "por_tipo": contar(lambda c: c["tipo"]),
        "por_tier": contar(lambda c: c["tier"]),
        "por_ambiente": contar(lambda c: c["ambiente"]),
        "por_squad": contar(lambda c: c["squad"]),
        "por_maturidade": contar(lambda c: c["maturidade"]),
        "linha_tempo_geral": linha_geral,
        "observaveis_por_bloco": observaveis_por_bloco,
        "produtos_gerais": produtos_gerais.most_common(10),
        "servicos_gerais": servicos_gerais.most_common(10),
        "clientes": clientes,
    }


if __name__ == "__main__":
    painel = construir()
    destino = DADOS / "dashboard.json"
    destino.write_text(json.dumps(painel, ensure_ascii=False), encoding="utf-8")
    r = painel["resumo"]
    print(f"dashboard.json gravado ({destino.stat().st_size / 1024:.0f} KB)")
    print(f"  base comeca em..: {painel['inicio_base']}")
    print(f"  cancelamentos...: {r['cancelamentos']}  MRR R$ {r['mrr_total']:,.2f}")
    print(f"  analisaveis.....: {r['analisaveis']}   fora da janela: {r['fora_da_janela']}")
    print(f"  com chamado.....: {r['com_chamado']}   sem chamado: {r['sem_chamado']}")
    print(f"  conversas 12m...: {r['conversas_12m']} de {r['conversas_total']} no total")
    print(f"  CSAT medio......: {r['csat_medio']}")
    print(f"  media 12m.......: {r['media_chamados_12m']} chamados por cliente ativo")
