"""Precisao do lexico: o que NAO conta, e de que e a queixa.

Nasceu de conferir 40 trechos sorteados que o tema "lentidao" havia capturado.
Cerca de um em cada quatro nao falava do produto:

    "Desculpe pela demora"                      -> cortesia de quem escreve
    "achei q ja nao iam atender pela demora"    -> demora do atendimento
    "esse note é meio lento"                    -> maquina do proprio cliente
    "o site da receita demora para atualizar"   -> portal de terceiro
    "isso tem muito tempo"                      -> expressao temporal, nao lentidao

Contar esses casos como lentidao do sistema inflava justamente o tema que
sustenta a conclusao do relatorio. Aqui ficam as duas correcoes:

1. EXCLUSOES anulam a ocorrencia que cai dentro de uma expressao desqualificante.
   A checagem e por ocorrencia, nao por mensagem: "perdao pela demora, o sistema
   esta travando" continua contando, porque so a primeira parte e anulada.

2. SUJEITOS respondem a pergunta que o time de CS faz ao ler o trecho: a demora
   e do sistema, da rotina de trabalho, da maquina do cliente ou de terceiro?
   Sem isso, "esta lento" nao diz o que esta lento, e nao da para agir.
"""
from __future__ import annotations

import re

# Sobe a mao quando a LOGICA muda, nao so as listas. O hash da versao do lexico
# so enxerga as definicoes; sem isto, mudar a janela de inferencia do sujeito
# nao dispararia o reprocessamento e a base ficaria com o resultado antigo.
VERSAO_REGRAS = 3

# ---------------------------------------------------------------- exclusoes
EXCLUSOES: dict[str, list[str]] = {
    "lentidao": [
        # cortesia: quem pede desculpa pela demora nao esta relatando o sistema
        r"(desculp\w*|perdao|perdoe|foi mal|me desculp\w*)[^.!?\n]{0,40}demor",
        r"demor\w*[^.!?\n]{0,25}(desculp|perdao)",
        r"\bobrigad\w+ pela paciencia\b",
        # demora do atendimento, que e queixa de outro tipo
        r"demor\w*[^.!?\n]{0,25}(para|pra) (responder|retornar|atender|dar retorno)",
        r"(atender|responder|retorno|resposta)[^.!?\n]{0,20}demor",
        r"\bdemora (do|no|de) (suporte|atendimento|retorno|chamado)\b",
        # maquina, rede ou navegador do proprio cliente
        r"\b(meu|nosso|esse|este|essa|minha|nossa)\s+"
        r"(computador|note|notebook|pc|maquina|micro|celular|internet|rede|link|wifi|navegador)",
        r"\b(internet|rede|wifi|link|conexao) (daqui|aqui|nossa|minha|do cliente)\b",
        # portais de terceiros
        r"\b(site|portal|servidor|sistema) (da|do) (receita|sefaz|caixa|gov|prefeitura|inss|banco)\b",
        r"\b(receita federal|gov\.?br|e-?cac|sefaz)\b[^.!?\n]{0,40}demor",
    ],
    "atendimento": [
        # o proprio cliente avisando que vai demorar a responder
        r"(vou|vamos|posso) demorar",
        r"\bsem retorno (meu|nosso)\b",
    ],
}

# ------------------------------------------------------------------ sujeitos
# A ordem importa: maquina do cliente e terceiro sao checados antes de sistema,
# porque "meu computador esta lento para abrir o questor" e problema da maquina.
SUJEITOS: list[tuple[str, str, list[str]]] = [
    ("maquina_cliente", "Máquina ou rede do cliente", [
        r"\b(meu|nosso|esse|este|minha|nossa|essa)\s+"
        r"(computador|note|notebook|pc|maquina|micro|celular)",
        r"\b(internet|wifi|conexao)\b",
        r"\bmaquina (do|da) (usuario|cliente|contador)\b",
    ]),
    ("terceiro", "Portal de terceiro", [
        r"\b(receita|sefaz|caixa|gov\.?br|e-?cac|prefeitura|inss)\b",
        r"\b(site|portal) (da|do)\b",
    ]),
    ("sistema", "Sistema Questor", [
        r"\b(questor|zen|sistema|programa|servidor|base|banco de dados|tela|janela|"
        r"esocial|e-social|reinf|dctf|sped|dirf|modulo|relatorio|importacao)\b",
        r"\b(abrir|gerar|carregar|processar|calcular|importar|salvar|enviar|rodar|"
        r"atualizar|imprimir)\b",
    ]),
    ("rotina", "Rotina de trabalho", [
        r"\b(processo|procedimento|rotina|fechamento|conferencia|lancamento|"
        r"apuracao|calculo)\b",
    ]),
]

ROTULOS_SUJEITO = {chave: rotulo for chave, rotulo, _ in SUJEITOS}
ROTULOS_SUJEITO["indefinido"] = "Não dá para saber pelo texto"

# quao segura foi a conclusao sobre o sujeito
ROTULOS_ORIGEM = {
    "frase": "dito na própria frase",
    "mensagem": "dito na mesma mensagem",
    "conversa": "dito em outra fala do mesmo chamado",
    "chamado": "inferido do assunto do chamado",
    "nenhuma": "não identificado",
}
ORIGEM_DIRETA = {"frase", "mensagem"}

# sujeitos que representam problema do produto Questor
DO_PRODUTO = {"sistema", "rotina"}

_EXC = {c: [re.compile(t) for t in lista] for c, lista in EXCLUSOES.items()}
_SUJ = [(c, r, [re.compile(t) for t in lista]) for c, r, lista in SUJEITOS]


def excluido(tema: str, plano: str, inicio: int, fim: int) -> bool:
    """A ocorrencia esta dentro de uma expressao que a desqualifica?"""
    for padrao in _EXC.get(tema, []):
        for m in padrao.finditer(plano):
            if m.start() <= inicio and fim <= m.end() + 2:
                return True
            # sobreposicao parcial tambem conta: as expressoes sao curtas e a
            # ocorrencia costuma ficar na borda delas
            if m.start() < fim and inicio < m.end():
                return True
    return False


def _primeiro(trecho: str) -> str | None:
    """Primeiro sujeito que casa, na ordem de prioridade das regras."""
    for chave, _rotulo, padroes in _SUJ:
        if any(p.search(trecho) for p in padroes):
            return chave
    return None


def _mais_forte(trecho: str) -> str | None:
    """Sujeito com mais evidencia no trecho, nao o primeiro da lista.

    A ordem de prioridade foi pensada para uma janela curta, onde o sujeito
    esta colado na queixa. Numa conversa inteira ela atrapalha: basta a palavra
    "receita" aparecer uma vez em qualquer lugar para o caso virar "portal de
    terceiro". A distancia, quem tem mais ocorrencias descreve melhor o assunto.
    """
    contagem: dict[str, int] = {}
    for chave, _rotulo, padroes in _SUJ:
        n = sum(len(p.findall(trecho)) for p in padroes)
        if n:
            contagem[chave] = n
    if not contagem:
        return None
    ordem = {c: i for i, (c, _r, _p) in enumerate(_SUJ)}
    return min(contagem, key=lambda c: (-contagem[c], ordem[c]))


def sujeito(plano: str, inicio: int, fim: int, contexto: str = "",
            conversa: str = "") -> tuple[str, str]:
    """De que e a queixa, e de onde essa conclusao saiu.

    Quatro niveis, do mais seguro ao mais frouxo:

    frase     o sujeito esta colado na queixa ("o questor esta lento")
    mensagem  esta na mesma mensagem, mas mais longe
    conversa  esta em outra fala do mesmo chamado
    chamado   so o servico e o produto registrados no chamado dizem

    A origem viaja junto com o resultado para que a tela possa mostrar o que foi
    dito e o que foi inferido, em vez de misturar os dois num numero so.
    """
    achado = _primeiro(plano[max(0, inicio - 90):fim + 90])
    if achado:
        return achado, "frase"
    achado = _primeiro(plano)
    if achado:
        return achado, "mensagem"
    if conversa:
        achado = _mais_forte(conversa)
        if achado:
            return achado, "conversa"
    if contexto:
        achado = _primeiro(contexto)
        if achado:
            return achado, "chamado"
    return "indefinido", "nenhuma"
