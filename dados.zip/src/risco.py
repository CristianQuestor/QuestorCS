"""Tela de Atencao: clientes ativos que repetem o padrao de quem cancelou.

A regra central nao foi inventada. Ela sai do que o teste estatistico mostrou:
lentidao e travamento e o unico tema que separa quem saiu de quem ficou, 1,78x
mais frequente, com p = 0,0091. Entao o alerta procura exatamente isso -- o mesmo
tema, repetido, sem ninguem ter assumido o caso.

O caminho tem duas etapas porque ler o texto de 78 mil conversas nao e viavel:

1. Uma peneira sobre metadados, que existem para toda a base.
2. Leitura do texto so dos candidatos, para confirmar o tema e trazer a frase.

Clientes que ja cancelaram ficam de fora, e contas de demonstracao tambem.
"""
from __future__ import annotations

import json
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from atrito import TEMAS, analise_guardada
from chatwoot import link_conversa
from confronto import (JANELA_REPETICAO_DIAS, MARCAS_ESCALADA,
                       REPETICAO_QUE_VIRA_CASO, janela_deslizante)

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

JANELA_ALERTA = 90        # dias olhados para tras a partir da ultima conversa
MIN_CHAMADOS = 3          # abaixo disso nao ha padrao para ler
MAX_CANDIDATOS = 250      # quantos clientes passam para a leitura de texto
# ler tudo de todo mundo nao cabe: 250 clientes x 12 conversas recentes dao
# cerca de 3 mil leituras, uns 20 minutos. O painel diz que e um recorte.
MAX_CONVERSAS_LIDAS = 12

# contas internas, que nao sao cliente
PADRAO_INTERNO = re.compile(
    r"demonstra|demo\b|questor demo|teste|treinamento|homologa", re.I)


def plano(texto) -> str:
    t = unicodedata.normalize("NFKD", (texto or "").lower())
    return t.encode("ascii", "ignore").decode()


def para_data(marca):
    """Epoch para data local, igual ao resto do projeto."""
    try:
        return datetime.fromtimestamp(int(marca)).date()
    except (TypeError, ValueError, OSError):
        return None


def escalado(conversa: dict) -> bool:
    return any(m in plano(" ".join(conversa.get("labels") or []))
               for m in MARCAS_ESCALADA)


def carregar():
    base = json.loads((DADOS / "base-conversas.json").read_text(encoding="utf-8"))
    empresas = json.loads((DADOS / "base-empresas.json").read_text(encoding="utf-8"))
    return base, empresas


def agrupar(base: dict, empresas: dict, excluir: set[str]) -> dict[str, list[dict]]:
    """Conversas por empresa, fora as canceladas e as contas internas."""
    por_empresa: dict[str, list[dict]] = defaultdict(list)
    for c in base.values():
        eid = c.get("empresa_id")
        if not eid:
            continue
        chave = str(eid)
        if chave in excluir:
            continue
        ficha = empresas.get(chave) or {}
        if ficha.get("documento") in excluir:
            continue
        if PADRAO_INTERNO.search(ficha.get("nome") or ""):
            continue
        por_empresa[chave].append(c)
    return por_empresa


# ------------------------------------------------------------------- peneira
def peneirar(por_empresa: dict, referencia: date) -> list[dict]:
    """Ordena os clientes por indicios de metadado, sem ainda ler texto."""
    inicio = referencia - timedelta(days=JANELA_ALERTA)
    candidatos = []

    for eid, conversas in por_empresa.items():
        recentes = []
        for c in conversas:
            d = para_data(c.get("criada"))
            if d and d >= inicio:
                recentes.append({**c, "data": d})
        if len(recentes) < MIN_CHAMADOS:
            continue

        # ritmo: ultimos 30 dias contra a media dos 60 anteriores
        # as duas janelas usam a mesma borda; antes, "ultimos" pegava 31 dias
        # dividido por 30 e inflava o ritmo em cerca de 3%
        corte = referencia - timedelta(days=30)
        ultimos = [c for c in recentes if c["data"] > corte]
        antes = [c for c in recentes if c["data"] <= corte]
        ritmo = None
        if antes:
            ritmo = round((len(ultimos) / 30) / (len(antes) / 60), 2)

        notas = [int(c["csat"]) for c in recentes if str(c.get("csat") or "").isdigit()]
        detratores = sum(1 for n in notas if n <= 2)

        servicos = Counter(c["servico"] for c in recentes if c.get("servico"))
        reincidente = servicos.most_common(1)[0] if servicos else None

        desempenho = sum(1 for c in recentes if c.get("servico")
                         and re.search(r"lentid|performance", plano(c["servico"])))
        escalados = sum(1 for c in recentes if escalado(c))

        # pontuacao so para ordenar quem merece leitura de texto primeiro.
        # nao e o alerta: o alerta sai da etapa seguinte.
        pontos = 0
        if desempenho:
            pontos += 4 * desempenho
        if ritmo and ritmo >= 1.5:
            pontos += 3
        if detratores:
            pontos += 3 * detratores
        if reincidente and reincidente[1] >= 4:
            pontos += 2
        if escalados == 0 and len(recentes) >= 8:
            pontos += 1
        pontos += min(len(recentes) / 10, 3)

        candidatos.append({
            "empresa_id": eid,
            "chamados_90d": len(recentes),
            "chamados_30d": len(ultimos),
            "ritmo": ritmo,
            "csat_notas": len(notas),
            "detratores": detratores,
            "servico_reincidente": list(reincidente) if reincidente else None,
            "chamados_desempenho": desempenho,
            "escalados": escalados,
            "pontos": round(pontos, 1),
            # so as mais recentes, que sao as que descrevem a situacao atual
            "ids": [c["id"] for c in sorted(recentes, key=lambda x: x["data"],
                                            reverse=True)[:MAX_CONVERSAS_LIDAS]],
        })

    candidatos.sort(key=lambda x: -x["pontos"])
    return candidatos


# ------------------------------------------------------- confirmacao no texto
def confirmar(candidato: dict, conversas_por_id: dict, analises: dict,
              discriminantes: set[str]) -> dict:
    """Le o texto do candidato e mede o tema de risco, do jeito validado."""
    ocorrencias: dict[str, list[dict]] = defaultdict(list)
    lidas = 0
    for cid in candidato["ids"]:
        registro = analises.get(cid)
        if not registro:
            continue
        analise = analise_guardada(registro)
        if analise["mensagens_cliente"] == 0:
            continue
        lidas += 1
        conversa = conversas_por_id.get(str(cid), {})
        for chave, trechos in analise["temas"].items():
            ocorrencias[chave].append({
                "conversa": cid,
                "link": link_conversa(cid),
                "data": (para_data(conversa.get("criada")) or "").isoformat()
                        if para_data(conversa.get("criada")) else None,
                "csat": conversa.get("csat"),
                "servico": conversa.get("servico"),
                "escalado": escalado(conversa),
                "trecho": trechos[0],
            })

    risco = {k: v for k, v in ocorrencias.items() if k in discriminantes}
    dominante = max(risco, key=lambda k: len(risco[k])) if risco else None

    alerta = None
    if dominante:
        casos = sorted(risco[dominante], key=lambda x: x["data"] or "")
        datas = [date.fromisoformat(c["data"]) for c in casos if c["data"]]
        intervalo = (max(datas) - min(datas)).days if len(datas) > 1 else 0
        escalonados = sum(1 for c in casos if c["escalado"])
        bateu, quando = janela_deslizante(datas, REPETICAO_QUE_VIRA_CASO,
                                          JANELA_REPETICAO_DIAS)
        alerta = {
            "tema": dominante,
            "rotulo": TEMAS[dominante]["rotulo"],
            "chamados": len(casos),
            "intervalo_dias": intervalo,
            "escalados": escalonados,
            "bate_regra": bateu,
            "bateu_em": quando.isoformat() if quando else None,
            "ultimo": max((c["data"] for c in casos if c["data"]), default=None),
            "evidencias": sorted(casos, key=lambda x: x["data"] or "",
                                 reverse=True)[:4],
        }

    return {"conversas_lidas": lidas, "alerta": alerta,
            "temas": {k: len(v) for k, v in ocorrencias.items()}}


def classificar(candidato: dict) -> tuple[str, str, str]:
    """Nivel, o porque e o que fazer. As regras estao todas visiveis aqui."""
    a = candidato.get("alerta")
    if a and a["bate_regra"] and a["escalados"] == 0:
        return (
            "critico",
            f"{a['chamados']} chamados de {a['rotulo'].lower()} em "
            f"{a['intervalo_dias']} dias, nenhum escalado. É o mesmo padrão dos "
            "clientes que cancelaram.",
            "Abrir caso de produto com dono e prazo, e avisar o cliente de que o "
            "assunto virou caso. Foi o passo que faltou nos quatro cancelamentos "
            "com esse padrão.",
        )
    if a and a["bate_regra"]:
        return (
            "atencao",
            f"{a['chamados']} chamados de {a['rotulo'].lower()} em "
            f"{a['intervalo_dias']} dias, {a['escalados']} escalado(s).",
            "O caso já existe internamente. Confirmar prazo e dar retorno ao "
            "cliente, que é onde os cancelamentos desse grupo escaparam.",
        )
    lidas = candidato.get("conversas_lidas", 0)
    total = candidato.get("chamados_90d", 0)
    ressalva = ("" if lidas >= total
                else f" Foram lidos {lidas} dos {total} chamados, então pode haver mais.")
    if a:
        return (
            "observar",
            f"{a['chamados']} chamado(s) de {a['rotulo'].lower()}, "
            f"sem repetição no que foi lido.{ressalva}",
            "Só manter no radar. Se o assunto voltar, vira caso.",
        )
    if candidato.get("conversas_lidas", 0) == 0:
        return (
            "observar",
            f"{candidato['chamados_90d']} chamados em {JANELA_ALERTA} dias. "
            "O texto deste cliente ainda não foi lido.",
            "Rodar a leitura de texto para saber se há tema de risco aqui. "
            "Sem isso, não dá para afirmar nada sobre este cliente.",
        )
    if candidato.get("detratores"):
        return (
            "observar",
            f"{candidato['detratores']} chamado(s) com nota 1 ou 2 nos últimos "
            f"{JANELA_ALERTA} dias.",
            "Ouvir o cliente sobre o atendimento mal avaliado. Não é o padrão de "
            "churn que medimos, mas é insatisfação declarada.",
        )
    return (
        "observar",
        f"{candidato['chamados_90d']} chamados em {JANELA_ALERTA} dias, "
        f"{lidas} lidos, sem tema de risco no que foi lido.{ressalva}",
        "Volume alto sozinho não prevê saída. Nenhuma ação necessária por este painel.",
    )
