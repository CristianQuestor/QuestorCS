"""Cliente da API do Chatwoot com cache em disco, retry e limite de requisicoes."""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv

RAIZ = Path(__file__).resolve().parent.parent
load_dotenv(RAIZ / ".env")

URL = os.getenv("CHATWOOT_URL", "").rstrip("/")
TOKEN = os.getenv("CHATWOOT_TOKEN", "")
CONTA = os.getenv("CHATWOOT_ACCOUNT", "3")
CACHE = RAIZ / "dados" / "cache"

INTERVALO = 0.12   # segundos entre chamadas, para nao pressionar a instancia
TENTATIVAS = 4
TIMEOUT = 90


class ChatwootErro(RuntimeError):
    pass


class Chatwoot:
    def __init__(self, usar_cache: bool = True) -> None:
        if not URL or not TOKEN:
            raise ChatwootErro("Defina CHATWOOT_URL e CHATWOOT_TOKEN no arquivo .env")
        self.base = f"{URL}/api/v1/accounts/{CONTA}"
        self.usar_cache = usar_cache
        self.sessao = requests.Session()
        self.sessao.headers.update({"api_access_token": TOKEN})
        self.chamadas = 0
        self.acertos_cache = 0
        self._ultima = 0.0
        # o mesmo cliente e usado por varias threads na extracao de mensagens,
        # entao o espacamento entre chamadas precisa ser protegido por trava
        self._trava = threading.Lock()
        CACHE.mkdir(parents=True, exist_ok=True)

    def _aguardar_vez(self) -> None:
        """Garante o intervalo minimo entre chamadas, mesmo com varias threads."""
        with self._trava:
            espera = time.monotonic() - self._ultima
            if espera < INTERVALO:
                time.sleep(INTERVALO - espera)
            self._ultima = time.monotonic()

    # ------------------------------------------------------------------ cache
    def _arquivo_cache(self, caminho: str) -> Path:
        chave = hashlib.sha1(caminho.encode("utf-8")).hexdigest()[:20]
        return CACHE / f"{chave}.json"

    # ------------------------------------------------------------------- http
    def get(self, caminho: str, cachear: bool = True) -> Any:
        """GET em caminho relativo a /accounts/{id}. Devolve o JSON cru."""
        arq = self._arquivo_cache(caminho)
        if self.usar_cache and cachear and arq.exists():
            self.acertos_cache += 1
            return json.loads(arq.read_text(encoding="utf-8"))

        erro: Exception | None = None
        for tentativa in range(TENTATIVAS):
            try:
                self._aguardar_vez()
                resp = self.sessao.get(self.base + caminho, timeout=TIMEOUT)
                self.chamadas += 1
                if resp.status_code == 429:
                    time.sleep(2 ** tentativa)
                    continue
                resp.raise_for_status()
                dados = resp.json()
                if cachear:
                    arq.write_text(
                        json.dumps(dados, ensure_ascii=False), encoding="utf-8"
                    )
                return dados
            except Exception as exc:  # rede instavel, 5xx, json invalido
                erro = exc
                time.sleep(1.5 * (tentativa + 1))
        raise ChatwootErro(f"Falha em {caminho} apos {TENTATIVAS} tentativas: {erro}")

    # -------------------------------------------------------------- endpoints
    def buscar_empresa(self, termo: str) -> list[dict]:
        return self.get(f"/companies/search?q={termo}").get("payload", [])

    def empresa(self, id_empresa: int) -> dict:
        return self.get(f"/companies/{id_empresa}").get("payload", {})

    def conversas_do_contato(self, id_contato: int) -> list[dict]:
        dados = self.get(f"/contacts/{id_contato}/conversations")
        if isinstance(dados, list):
            return dados
        return dados.get("payload", [])

    def mensagens(self, id_conversa: int) -> list[dict]:
        dados = self.get(f"/conversations/{id_conversa}/messages")
        if isinstance(dados, list):
            return dados
        return dados.get("payload", [])

    def resumo(self) -> str:
        return f"{self.chamadas} chamadas a API, {self.acertos_cache} servidas do cache"


def link_conversa(id_conversa: int) -> str:
    return f"{URL}/app/accounts/{CONTA}/conversations/{id_conversa}"
