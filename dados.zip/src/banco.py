"""Acesso ao banco restaurado do Chatwoot.

O dump de 09/09/2026 traz a conta 3 inteira: 78 mil conversas, 4,4 milhoes de
mensagens e 39 mil respostas de CSAT, sendo 14 mil com comentario escrito pelo
cliente. Isso substitui a extracao pela API, que levava horas e so alcancava
uma amostra.

As funcoes devolvem exatamente as mesmas formas que o pipeline ja consumia dos
arquivos JSON, de proposito: assim a analise continua a mesma e a troca de
origem nao muda numero nenhum sem querer.

A API continua servindo para o delta, do dia do dump em diante.
"""
from __future__ import annotations

import json
import os
from contextlib import contextmanager
from datetime import date, datetime
from pathlib import Path

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

RAIZ = Path(__file__).resolve().parent.parent
load_dotenv(RAIZ / ".env")

CONTA = int(os.getenv("CHATWOOT_ACCOUNT", "3"))
LIGACAO = {
    "host": os.getenv("PG_HOST", "localhost"),
    "port": int(os.getenv("PG_PORT", "5432")),
    "dbname": os.getenv("PG_DB", "questor_cs"),
    "user": os.getenv("PG_USER", "postgres"),
    "password": os.getenv("PG_PASSWORD", ""),
}

# data do dump: daqui para a frente so a API tem os dados
DATA_DUMP = os.getenv("PG_DATA_DUMP", "2026-09-09")


def abrir():
    """Conexao solta, para quem precisa guardar a referencia.

    Chamar conexao().__enter__() parecia equivalente e nao e: o gerador do
    contextmanager fica sem referencia, o coletor de lixo o finaliza e o finally
    fecha a conexao antes do primeiro uso.
    """
    return psycopg2.connect(**LIGACAO)


@contextmanager
def conexao():
    con = psycopg2.connect(**LIGACAO)
    try:
        yield con
    finally:
        con.close()


def _epoch(valor) -> int | None:
    return int(valor.timestamp()) if isinstance(valor, datetime) else None


def _etiquetas(texto) -> list[str]:
    """cached_label_list guarda as etiquetas separadas por virgula."""
    if not texto:
        return []
    return [t.strip() for t in str(texto).split(",") if t.strip()]


# ------------------------------------------------------------------ consultas
SELECT_CONVERSA = """
    select c.id,
           c.contact_id,
           ct.company_id,
           c.created_at,
           c.status,
           c.cached_label_list,
           c.custom_attributes,
           c.first_reply_created_at,
           c.last_activity_at,
           s.name  as servico,
           r.rating as csat
      from conversations c
      join contacts ct on ct.id = c.contact_id
 left join services s  on s.id = c.service_id
 left join lateral (
            select rating from csat_survey_responses
             where conversation_id = c.id order by id desc limit 1
          ) r on true
     where c.account_id = %(conta)s
"""

ESTADOS = {0: "open", 1: "resolved", 2: "pending", 3: "snoozed"}


def _linha_para_conversa(r) -> dict:
    atributos = r["custom_attributes"] or {}
    return {
        "id": r["id"],
        "contato_id": r["contact_id"],
        "empresa_id": r["company_id"],
        "created_at": _epoch(r["created_at"]),
        "status": ESTADOS.get(r["status"], str(r["status"])),
        "labels": _etiquetas(r["cached_label_list"]),
        "csat_rating": r["csat"],
        "servico": r["servico"],
        "atributo_produto": atributos.get("produto"),
        "atributo_status": atributos.get("Status"),
        "first_reply_created_at": _epoch(r["first_reply_created_at"]),
        "ultima_atividade": _epoch(r["last_activity_at"]),
    }


def conversas_por_empresa(con, empresas: list[int], ate: date | None = None) -> dict:
    """Conversas agrupadas por empresa, no formato de dados/conversas.json."""
    if not empresas:
        return {}
    sql = SELECT_CONVERSA + " and ct.company_id = any(%(empresas)s)"
    if ate:
        sql += " and c.created_at::date <= %(ate)s"
    with con.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, {"conta": CONTA, "empresas": list(empresas), "ate": ate})
        saida: dict[str, list[dict]] = {}
        for r in cur:
            saida.setdefault(str(r["company_id"]), []).append(_linha_para_conversa(r))
    return saida


def conversas_no_periodo(con, inicio: date, fim: date,
                         excluir: set[int] | None = None) -> dict:
    """Conversas de todas as empresas numa faixa de datas."""
    sql = SELECT_CONVERSA + """
        and ct.company_id is not null
        and c.created_at::date between %(inicio)s and %(fim)s
    """
    if excluir:
        sql += " and not (ct.company_id = any(%(excluir)s))"
    with con.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, {"conta": CONTA, "inicio": inicio, "fim": fim,
                          "excluir": list(excluir or [])})
        saida: dict[str, list[dict]] = {}
        for r in cur:
            saida.setdefault(str(r["company_id"]), []).append(_linha_para_conversa(r))
    return saida


def mensagens_de(con, ids_conversa: list[int]) -> dict:
    """Mensagens uteis por conversa, no formato de dados/mensagens.json.

    Tipo 2 e atividade do sistema e mensagem privada e nota interna entre
    agentes: nenhuma das duas e fala do cliente nem do atendente para ele.
    """
    if not ids_conversa:
        return {}
    with con.cursor() as cur:
        cur.execute("""
            select conversation_id, id, message_type, sender_type, created_at, content
              from messages
             where conversation_id = any(%s)
               and coalesce(private, false) = false
               and message_type <> 2
               and coalesce(trim(content), '') <> ''
             order by conversation_id, id
        """, (list(ids_conversa),))
        saida: dict[str, list[dict]] = {}
        for cid, mid, tipo, remetente, criada, texto in cur:
            saida.setdefault(str(cid), []).append({
                "id": mid,
                "quem": "cliente" if (tipo == 0 or remetente == "Contact") else "agente",
                "em": _epoch(criada),
                "texto": " ".join(str(texto).split())[:4000],
            })
    return saida


def empresas_por_documento(con, documentos: list[str]) -> dict:
    """Empresas pelo CNPJ sem pontuacao, que e a chave que casa com o CSV."""
    with con.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            select e.id, e.name, e.registration_number, e.custom_attributes,
                   e.contacts_count, g.name as tier
              from companies e
         left join group_companies g on g.id = e.group_company_id
             where e.account_id = %(conta)s
               and regexp_replace(coalesce(e.registration_number,''), '\\D', '', 'g')
                   = any(%(docs)s)
        """, {"conta": CONTA, "docs": list(documentos)})
        saida = {}
        for r in cur:
            doc = "".join(ch for ch in (r["registration_number"] or "") if ch.isdigit())
            saida[doc] = {
                "id": r["id"], "name": r["name"],
                "registration_number": r["registration_number"],
                "contacts_count": r["contacts_count"],
                "group_company": {"name": r["tier"]},
                "custom_attributes": r["custom_attributes"] or {},
            }
    return saida


def feedback_csat(con, so_com_texto: bool = True) -> list[dict]:
    """Comentarios que o cliente escreveu junto com a nota.

    E a melhor fonte de sentimento desta base: o proprio cliente dizendo por que
    deu a nota, e nao uma inferencia a partir do texto do chamado.
    """
    sql = """
        select r.conversation_id, r.rating, r.feedback_message, r.created_at,
               ct.company_id
          from csat_survey_responses r
     left join conversations c on c.id = r.conversation_id
     left join contacts ct on ct.id = c.contact_id
         where r.account_id = %(conta)s
    """
    if so_com_texto:
        sql += " and coalesce(trim(r.feedback_message), '') <> ''"
    with con.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, {"conta": CONTA})
        return [{
            "conversa": r["conversation_id"],
            "empresa_id": r["company_id"],
            "nota": r["rating"],
            "texto": " ".join(str(r["feedback_message"]).split()),
            "data": r["created_at"].date().isoformat() if r["created_at"] else None,
        } for r in cur]


def resumo(con) -> dict:
    with con.cursor() as cur:
        cur.execute("""
            select (select count(*) from conversations where account_id=%(c)s),
                   (select min(created_at)::date from conversations where account_id=%(c)s),
                   (select max(created_at)::date from conversations where account_id=%(c)s),
                   (select count(*) from messages where account_id=%(c)s),
                   (select count(*) from csat_survey_responses where account_id=%(c)s),
                   (select count(*) from companies where account_id=%(c)s)
        """, {"c": CONTA})
        n_conv, ini, fim, n_msg, n_csat, n_emp = cur.fetchone()
    return {"conversas": n_conv, "primeira": ini.isoformat(), "ultima": fim.isoformat(),
            "mensagens": n_msg, "csat": n_csat, "empresas": n_emp,
            "data_dump": DATA_DUMP}


if __name__ == "__main__":
    with conexao() as con:
        print(json.dumps(resumo(con), ensure_ascii=False, indent=2))
