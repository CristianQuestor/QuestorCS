"""Gera o dashboard como um unico HTML, com os dados embutidos.

Embutir evita o bloqueio de CORS do navegador ao abrir o arquivo direto do
disco. O resultado abre com dois cliques, sem servidor.
"""
from __future__ import annotations

import json
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
MODELO = Path(__file__).resolve().parent / "modelo.html"
DADOS = RAIZ / "dados" / "dashboard.json"
SAIDA = RAIZ / "dashboard" / "index.html"

MARCA = "/*DADOS*/null/*FIM*/"


def gerar() -> Path:
    if not DADOS.exists():
        raise SystemExit("dados/dashboard.json nao existe. Rode metricas.py antes.")

    modelo = MODELO.read_text(encoding="utf-8")
    if MARCA not in modelo:
        raise SystemExit(f"marcador {MARCA} nao encontrado em {MODELO.name}")

    painel = json.loads(DADOS.read_text(encoding="utf-8"))
    # </script> dentro de uma string quebraria o bloco de script da pagina
    bruto = json.dumps(painel, ensure_ascii=False).replace("</", "<\\/")

    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    SAIDA.write_text(modelo.replace(MARCA, bruto), encoding="utf-8")
    return SAIDA


def gerar_para_flask(destino: Path) -> Path:
    """Copia o painel como template Flask, protegido do Jinja.

    A pagina e servida por render_template, que interpreta chaves duplas. O texto
    dos clientes esta embutido no HTML e um dia pode conter '{{' ou '{%', o que
    quebraria a renderizacao ou apagaria trecho de uma citacao. Envolver tudo em
    raw desliga o Jinja para o arquivo inteiro, e a pagina servida fica identica
    ao arquivo que abre direto do disco.
    """
    pagina = SAIDA.read_text(encoding="utf-8")
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text("{% raw %}\n" + pagina + "\n{% endraw %}", encoding="utf-8")
    return destino


if __name__ == "__main__":
    import sys

    destino = gerar()
    print(f"dashboard gerado: {destino}")
    print(f"  {destino.stat().st_size / 1024:.0f} KB, abre direto no navegador")

    if "--flask" in sys.argv:
        alvo = Path(sys.argv[sys.argv.index("--flask") + 1])
        copia = gerar_para_flask(alvo)
        print(f"copia para o Flask: {copia}")
        print(f"  {copia.stat().st_size / 1024:.0f} KB, envolvida em raw")
