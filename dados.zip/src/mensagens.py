"""Extrai o texto das conversas, para a analise de atrito.

Grava incrementalmente em dados/mensagens.json e pula o que ja foi baixado, de
modo que a extracao pode ser interrompida e retomada sem perder trabalho.

As paginas de mensagem nao vao para o cache em disco do cliente: sao milhares de
respostas grandes, e o proprio mensagens.json ja faz o papel de cache.
"""
from __future__ import annotations

import json
import random
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from chatwoot import Chatwoot, ChatwootErro

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"
ARQUIVO = DADOS / "mensagens.json"

LIMITE_PAGINAS = 12      # ate 240 mensagens por conversa
TAMANHO_PAGINA = 20
GRAVAR_A_CADA = 40       # conversas
# a instancia do Chatwoot e de producao. Quatro threads sobre uma latencia de
# ~1,5s dao menos de 3 requisicoes por segundo, o que e educado, e ainda assim
# derruba a extracao de quase duas horas para menos de meia.
TRABALHADORES = 4
AMOSTRA_CONTROLE = 800   # conversas do grupo de controle que recebem leitura de texto
SEMENTE = 20260914


def limpar(texto) -> str:
    if not isinstance(texto, str):
        return ""
    return " ".join(texto.split()).strip()


def baixar_conversa(api: Chatwoot, id_conversa: int) -> list[dict]:
    """Todas as mensagens uteis da conversa, da mais antiga para a mais nova."""
    acumulado: list[dict] = []
    antes = None
    for _ in range(LIMITE_PAGINAS):
        caminho = f"/conversations/{id_conversa}/messages"
        if antes:
            caminho += f"?before={antes}"
        try:
            dados = api.get(caminho, cachear=False)
        except ChatwootErro:
            break
        lote = dados.get("payload", dados) if isinstance(dados, dict) else dados
        if not lote:
            break
        acumulado = list(lote) + acumulado
        if len(lote) < TAMANHO_PAGINA:
            break
        antes = min(m["id"] for m in lote)

    saida = []
    for m in acumulado:
        # tipo 2 e atividade do sistema; privada e nota interna entre agentes
        if m.get("private") or m.get("message_type") == 2:
            continue
        texto = limpar(m.get("content"))
        if not texto:
            continue
        remetente = (m.get("sender") or {}).get("type")
        saida.append({
            "id": m.get("id"),
            "quem": "cliente" if m.get("message_type") == 0 or remetente == "contact"
                    else "agente",
            "em": m.get("created_at"),
            "texto": texto[:4000],
        })
    return saida


def principal() -> int:
    DADOS.mkdir(parents=True, exist_ok=True)
    # quem cancelou entra inteiro; do controle basta uma amostra, porque ele so
    # serve de linha de base e 800 conversas ja dao uma taxa estavel
    caminho = DADOS / "conversas.json"
    conversas = json.loads(caminho.read_text(encoding="utf-8"))
    alvos = {c["id"] for lista in conversas.values() for c in lista}

    caminho = DADOS / "controle-conversas.json"
    if caminho.exists():
        conversas = json.loads(caminho.read_text(encoding="utf-8"))
        do_controle = sorted({c["id"] for lista in conversas.values() for c in lista})
        if len(do_controle) > AMOSTRA_CONTROLE:
            do_controle = random.Random(SEMENTE).sample(do_controle, AMOSTRA_CONTROLE)
            print(f"controle amostrado: {AMOSTRA_CONTROLE} conversas\n")
        alvos |= set(do_controle)

    # a tela de Atencao pede o texto de candidatos que nao estao nos dois
    # grupos acima: sao clientes ativos, peneirados da base inteira
    caminho = DADOS / "atencao-alvos.json"
    if caminho.exists():
        pedido = json.loads(caminho.read_text(encoding="utf-8"))
        novos = set(pedido.get("conversas") or [])
        if novos:
            print(f"atencao: {len(novos)} conversas pedidas pela peneira de risco\n")
        alvos |= novos

    alvos = sorted(alvos)

    ja = {}
    if ARQUIVO.exists():
        ja = json.loads(ARQUIVO.read_text(encoding="utf-8"))
    pendentes = [i for i in alvos if str(i) not in ja]

    print(f"conversas no total....: {len(alvos)}")
    print(f"ja baixadas...........: {len(ja)}")
    print(f"a baixar agora........: {len(pendentes)}\n")
    if not pendentes:
        print("nada a fazer")
        return 0

    api = Chatwoot()
    inicio = time.time()
    trava = threading.Lock()
    feitas = 0

    with ThreadPoolExecutor(max_workers=TRABALHADORES) as piscina:
        futuros = {piscina.submit(baixar_conversa, api, i): i for i in pendentes}
        for futuro in as_completed(futuros):
            id_conversa = futuros[futuro]
            try:
                resultado = futuro.result()
            except Exception as exc:
                print(f"  ERRO na conversa {id_conversa}: {exc}")
                resultado = []
            with trava:
                ja[str(id_conversa)] = resultado
                feitas += 1
                n = feitas
                if n % GRAVAR_A_CADA == 0 or n == len(pendentes):
                    ARQUIVO.write_text(
                        json.dumps(ja, ensure_ascii=False), encoding="utf-8")
                    passado = time.time() - inicio
                    resta = passado / n * (len(pendentes) - n)
                    print(f"  {n:5}/{len(pendentes)}  "
                          f"{sum(len(v) for v in ja.values()):7} mensagens  "
                          f"faltam ~{resta / 60:.0f} min")

    total = sum(len(v) for v in ja.values())
    cliente = sum(1 for v in ja.values() for m in v if m["quem"] == "cliente")
    print(f"\nconcluido em {(time.time() - inicio) / 60:.1f} min")
    print(f"  {total} mensagens, {cliente} do cliente")
    print(f"  {api.resumo()}")
    print(f"  gravado em {ARQUIVO}")
    return 0


if __name__ == "__main__":
    sys.exit(principal())
