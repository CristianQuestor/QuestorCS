"""Analise de atrito e sentimento sobre o texto das conversas.

O metodo e lexical e auditavel de proposito: cada tema e uma lista de expressoes
em portugues, cada contagem aponta para a frase e a conversa de origem, e nada
depende de um modelo fechado que o time de CS nao possa conferir.

Duas cautelas que mudam a leitura do resultado:

1. Frequencia bruta nao e desconforto. Todo chamado de suporte, por definicao,
   e alguem que nao conseguiu fazer algo. Por isso os numeros so ganham sentido
   comparados a um grupo de controle de clientes que ficaram.
2. O lexico e validado contra o CSAT, que e sentimento declarado pelo proprio
   cliente. Se os chamados que o lexico marca como atrito nao tiverem CSAT pior,
   o lexico esta errado e o relatorio diz isso.
"""
from __future__ import annotations

import hashlib
import json
import re
import statistics
import unicodedata
from collections import Counter, defaultdict

import precisao
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

# --------------------------------------------------------------------- lexico
# Cada tema traz expressoes ja sem acento, porque o texto e normalizado antes.
# Peso: quanto a expressao pesa no escore de atrito da conversa.
TEMAS = {
    "erro_falha": {
        "rotulo": "Erro e falha do sistema",
        "peso": 2,
        "termos": [
            r"\bnao (funciona|funcionou|roda|rodou)\b", r"\bnao consigo\b",
            r"\bnao consegui\b", r"\bnao (gera|gerou|geramos)\b",
            r"\bnao (abre|abriu)\b", r"\bnao (salva|salvou)\b",
            r"\bnao (importa|importou)\b", r"\bnao (aceita|aceitou)\b",
            r"\bnao (calcula|calculou)\b", r"\bnao (atualiza|atualizou)\b",
            r"\bnao (aparece|apareceu)\b", r"\bnao (fecha|fechou)\b",
            r"\bnao esta (indo|dando|gerando|funcionando)\b",
            r"\berro\b", r"\berros\b", r"\bfalh(a|as|ou|am|ando)\b",
            r"\bbug\b", r"\binconsistent", r"\bdivergen",
            r"\bcritica", r"\brejeit", r"\bduplicad",
        ],
    },
    "lentidao": {
        "rotulo": "Lentidão e travamento",
        "peso": 3,
        "termos": [
            r"\blent[oa]s?\b", r"\blentidao\b", r"\bdemor(a|ou|ando|ado)\b",
            r"\btrav(a|ou|ando|ado|amento)\b", r"\bcongel",
            r"\bpesad[oa]s?\b", r"\barrastando\b", r"\bnao responde\b",
            r"\bficou parado\b",
            # "muito tempo" pegava "isso tem muito tempo" e "horas para" pegava
            # "em cima da hora para os clientes": os dois exigem contexto
            r"\b(leva|levou|demora|demorou|levando) muito tempo\b",
            r"\bhoras? para (gerar|processar|abrir|carregar|rodar|importar|calcular)\b",
        ],
    },
    "instabilidade": {
        "rotulo": "Instabilidade e indisponibilidade",
        "peso": 4,
        # os verbos genericos exigem sujeito, senao "caiu a internet aqui" e
        # "nao entra nessa reducao de 10%" entram como instabilidade do sistema
        "termos": [
            r"\bfora do ar\b", r"\binstav", r"\binstabilidade",
            r"\bindisponi", r"\bsem acesso\b", r"\boffline\b",
            r"\bca(iu|indo) (o |a )?(sistema|servidor|questor|portal|base|banco)\b",
            r"\bderrub(a|ou|ando) (o |a )?(sistema|conexao|usuario|todos)\b",
            r"\bperdeu (a )?conexao\b", r"\bdesconect", r"\bsaiu do sistema\b",
            r"\bnao (consigo )?entr(o|a|ar) (no|na|em) (sistema|programa|questor|portal|base)\b",
            r"\bnao loga\b", r"\bnao consigo logar\b",
        ],
    },
    "dificuldade_uso": {
        "rotulo": "Dificuldade de uso",
        "peso": 1,
        "termos": [
            r"\bnao sei\b", r"\bcomo (faco|fazer|faz)\b", r"\bcomplicad",
            r"\bdific", r"\bconfus",
            r"\bnao entend", r"\bnao ach(o|ei)\b", r"\bonde (fica|encontro)\b",
            r"\bnao encontr", r"\bqual (o )?caminho\b", r"\bnao localiz",
        ],
    },
    "retrabalho": {
        "rotulo": "Retrabalho e perda de trabalho",
        "peso": 4,
        "termos": [
            r"\brefaz|\brefazer\b", r"\bretrabalho\b", r"\bperd(i|emos|eu) (o|a|os|as|todo)",
            r"\bde novo\b", r"\bnovamente\b", r"\bmanualmente\b", r"\bna mao\b",
            r"\btudo de novo\b", r"\bum por um\b", r"\bdigitar tudo\b",
            r"\bsumiu\b", r"\bsumiram\b", r"\bapagou\b",
        ],
    },
    "urgencia": {
        "rotulo": "Urgência e risco de prazo",
        "peso": 3,
        "termos": [
            r"\burgent", r"\burgencia\b", r"\bprazo\b", r"\bvenc(e|endo|imento)\b",
            r"\bmulta", r"\batras(o|os|ad|and)",
            r"\bparad[oa]s?\b", r"\bpar(ou|amos) (tudo|o trabalho)\b",
            r"\bpreciso hoje\b", r"\bpara ontem\b", r"\bentrega\b",
        ],
    },
    "insatisfacao": {
        "rotulo": "Insatisfação explícita",
        "peso": 6,
        "termos": [
            r"\bpessim", r"\babsurd", r"\binadmissiv", r"\bcansad",
            r"\bdecepcion", r"\bdescaso\b", r"\brevolt", r"\binsatisf",
            r"\bhorriv", r"\blamentav", r"\bvergonh", r"\bridicul",
            r"\bnao da mais\b", r"\btoda hora\b", r"\bsempre da problema\b",
            r"\bja faz (dias|semanas|meses)\b", r"\bninguem (resolve|responde)\b",
            r"\bperdendo (tempo|dinheiro|cliente)\b", r"\bprejuizo\b",
        ],
    },
    "atualizacao": {
        "rotulo": "Atualização e migração",
        "peso": 2,
        "termos": [
            r"\batualiza(cao|r|ndo)\b", r"\bnova versao\b", r"\bmigra(cao|r|ndo)\b",
            r"\breinstal", r"\bformatar\b", r"\bconfigurar de novo\b",
            r"\bdepois da atualizacao\b", r"\bapos atualizar\b",
        ],
    },
    # Os dois temas abaixo entraram depois, ao conferir relatos que o lexico
    # classificava como genericos: "nao conseguiu automatizar", "nao atende as
    # funcionalidades", "muitos problemas com suporte". Eram atrito real sem
    # tema onde cair.
    "funcionalidade": {
        "rotulo": "Funcionalidade ausente",
        "peso": 4,
        "termos": [
            r"\bnao (atende|atendem|contempla|contemplam)\b",
            r"\bnao (tem|possui|existe) (a |o |essa |esse )?"
            r"(opcao|funcao|funcionalidade|recurso|relatorio|campo)\b",
            r"\bfalta (a |o )?(opcao|funcao|funcionalidade|recurso|relatorio)\b",
            r"\bnao (faz|permite|deixa) ",
            r"\bseria possivel (incluir|criar|adicionar)\b",
            r"\bsugestao de melhoria\b", r"\bnao automatiza\b",
            r"\bnao conseguiu? automatizar\b",
        ],
    },
    "atendimento": {
        "rotulo": "Insatisfação com o atendimento",
        "peso": 5,
        "termos": [
            r"\bsem retorno\b", r"\bnenhum retorno\b", r"\bsem resposta\b",
            r"\bproblemas? com (o )?(suporte|atendimento)\b",
            r"\bdemora (do|no|de) (suporte|atendimento|retorno)\b",
            r"\bninguem (me )?(retorna|retornou|respondeu|atende)\b",
            r"\bate hoje (nao|sem)\b", r"\bcontinuo aguardando\b",
        ],
    },
    "ameaca_saida": {
        "rotulo": "Menção a cancelar ou trocar",
        "peso": 10,
        # exige contexto de contrato. Sem isso, "calculo rescisao" (rotina de
        # folha) e "cancelar a nota" (rotina fiscal) viravam ameaca de saida, e
        # o tema aparecia mais em quem FICOU do que em quem saiu.
        "termos": [
            r"\bcancel(ar|amento|ando) (o |a |do |da )?(contrato|sistema|servico|licenca|assinatura)\b",
            r"\brescindir\b", r"\brescisao (do |de )?contrato\b",
            r"\boutro sistema\b", r"\btrocar de sistema\b", r"\bmudar de sistema\b",
            r"\bconcorrent", r"\bvoltar para o (antigo|anterior)\b",
            r"\bnao vamos (mais )?(continuar|renovar)\b", r"\bencerrar o contrato\b",
            r"\bnao vamos renovar\b", r"\bpensando em (sair|trocar|cancelar)\b",
        ],
    },
}

POSITIVOS = [
    r"\bobrigad", r"\bperfeito\b", r"\bdeu certo\b", r"\bfuncionou\b",
    r"\bresolv(ido|eu|emos)\b", r"\bconsegui\b", r"\botimo\b", r"\bexcelente\b",
    r"\bmuito bom\b", r"\bagradec", r"\btop\b", r"\bshow\b", r"\bsucesso\b",
]

# Um regex por tema, com as expressoes unidas por alternancia, em vez de uma
# lista de regex por tema. Sao 11 buscas por mensagem em vez de umas 110, o que
# importa agora que o lexico roda sobre milhoes de mensagens e nao sobre 90 mil.
# O resultado e o mesmo: o tema casa se qualquer expressao casar.
COMPILADOS = {
    chave: re.compile("|".join(f"(?:{t})" for t in dados["termos"]))
    for chave, dados in TEMAS.items()
}
POS_COMPILADOS = re.compile("|".join(f"(?:{t})" for t in POSITIVOS))

# Muda quando o lexico muda. E o que permite guardar a analise de cada conversa
# e so reprocessar o que ficou velho, em vez de reler tudo a cada execucao.
VERSAO_LEXICO = hashlib.sha1(
    json.dumps({k: v["termos"] for k, v in TEMAS.items()}, sort_keys=True).encode()
    + json.dumps(POSITIVOS).encode()
    + json.dumps(precisao.EXCLUSOES, sort_keys=True).encode()
    + json.dumps([s[0] for s in precisao.SUJEITOS]).encode()
    + str(precisao.VERSAO_REGRAS).encode()
).hexdigest()[:12]


def normalizar(texto: str) -> str:
    """Minusculas e sem acento, para o lexico poder ser escrito de um jeito só."""
    t = unicodedata.normalize("NFKD", texto.lower())
    return t.encode("ascii", "ignore").decode()


def analisar_texto(texto: str, contexto: str = "", conversa: str = "") -> dict:
    """Temas encontrados e trechos de evidencia em um texto de cliente."""
    plano = normalizar(texto)
    plano_conversa = normalizar(conversa) if conversa else ""
    achados: dict[str, list[str]] = {}
    sujeitos: dict[str, str] = {}
    origens: dict[str, str] = {}
    for chave, padrao in COMPILADOS.items():
        # percorre as ocorrencias ate achar uma que sobreviva as exclusoes.
        # "perdao pela demora, o sistema esta travando" perde a primeira e
        # mantem a segunda, em vez de perder a mensagem inteira
        for m in padrao.finditer(plano):
            if precisao.excluido(chave, plano, m.start(), m.end()):
                continue
            # devolve o trecho original, com acento, em volta da ocorrencia
            ini = max(0, m.start() - 60)
            fim = min(len(texto), m.end() + 90)
            trecho = texto[ini:fim].strip()
            if ini > 0:
                trecho = "…" + trecho
            if fim < len(texto):
                trecho = trecho + "…"
            achados.setdefault(chave, []).append(trecho)
            suj, origem = precisao.sujeito(plano, m.start(), m.end(),
                                           normalizar(contexto), plano_conversa)
            sujeitos[chave] = suj
            origens[chave] = origem
            break
    positivos = 1 if POS_COMPILADOS.search(plano) else 0
    return {"temas": achados, "sujeitos": sujeitos, "origens": origens,
            "positivos": positivos}


def analise_guardada(registro: dict) -> dict:
    """Converte uma linha de analise_conversa na forma de analisar_conversa.

    O lexico passou a rodar uma vez sobre a base inteira e o resultado fica
    gravado. Os modulos de analise continuam escritos contra a mesma forma, e
    so trocam a origem: em vez de reler as mensagens, leem esta linha.
    """
    temas = registro.get("temas") or {}
    return {
        "sujeitos": registro.get("sujeitos") or {},
        "origens": registro.get("origens") or {},
        "mensagens_cliente": registro.get("mensagens_cliente", 0),
        "palavras_cliente": registro.get("palavras_cliente", 0),
        "temas": {chave: [trecho] for chave, trecho in temas.items()},
        "positivos": registro.get("positivos", 0),
        "escore": registro.get("escore", 0),
        "servico_reincidente": None,
        "primeira_fala": None,
    }


def analisar_conversa(mensagens: list[dict]) -> dict:
    """Perfil de atrito de uma conversa, olhando so o que o cliente escreveu."""
    do_cliente = [m for m in mensagens if m["quem"] == "cliente"]
    temas: dict[str, list[str]] = defaultdict(list)
    positivos = 0
    for m in do_cliente:
        r = analisar_texto(m["texto"])
        for chave, trechos in r["temas"].items():
            temas[chave].extend(trechos)
        positivos += r["positivos"]

    escore = sum(TEMAS[c]["peso"] for c in temas)
    return {
        "mensagens_cliente": len(do_cliente),
        "palavras_cliente": sum(len(m["texto"].split()) for m in do_cliente),
        "temas": {c: trechos[:3] for c, trechos in temas.items()},
        "positivos": positivos,
        "escore": escore,
        "primeira_fala": do_cliente[0]["texto"][:600] if do_cliente else None,
    }


def perfil(conversas_ids: list[int], mensagens: dict) -> dict:
    """Agrega o atrito de um conjunto de conversas."""
    porTema = Counter()
    escores = []
    comTexto = 0
    for cid in conversas_ids:
        msgs = mensagens.get(str(cid))
        if not msgs:
            continue
        a = analisar_conversa(msgs)
        if a["mensagens_cliente"] == 0:
            continue
        comTexto += 1
        escores.append(a["escore"])
        for chave in a["temas"]:
            porTema[chave] += 1
    return {
        "conversas_com_texto": comTexto,
        "por_tema": dict(porTema),
        "escore_medio": round(statistics.fmean(escores), 2) if escores else 0,
        "taxa": {c: round(n / comTexto, 4) for c, n in porTema.items()} if comTexto else {},
    }


def validar_contra_csat(conversas: list[dict], analises: dict) -> dict:
    """O lexico tem de separar CSAT bom de CSAT ruim, senao nao serve.

    Compara o CSAT medio das conversas que o lexico marca com atrito alto contra
    as que marca com atrito baixo. Se nao houver diferenca, o resultado diz isso
    em vez de fingir que o metodo funciona.
    """
    alto, baixo = [], []
    for c in conversas:
        nota = c.get("csat_rating")
        if not str(nota or "").isdigit():
            continue
        registro = analises.get(c["id"])
        if not registro:
            continue
        a = analise_guardada(registro)
        if a["mensagens_cliente"] == 0:
            continue
        (alto if a["escore"] >= 6 else baixo).append(int(nota))
    if len(alto) < 30 or len(baixo) < 30:
        return {"suficiente": False, "n_alto": len(alto), "n_baixo": len(baixo)}

    ma, mb = statistics.fmean(alto), statistics.fmean(baixo)
    diferenca = ma - mb
    # proporcao de notas 1 e 2 separa melhor que a media, porque o CSAT e muito
    # concentrado no 5 e a media se move pouco
    det_alto = sum(1 for n in alto if n <= 2) / len(alto)
    det_baixo = sum(1 for n in baixo if n <= 2) / len(baixo)

    if diferenca <= -0.3 or det_alto >= det_baixo * 1.5:
        veredito = "separa"
    elif diferenca < -0.05:
        veredito = "separa fracamente"
    else:
        veredito = "nao separa"

    return {
        "suficiente": True,
        "n_alto": len(alto), "n_baixo": len(baixo),
        "csat_atrito_alto": round(ma, 2),
        "csat_atrito_baixo": round(mb, 2),
        "diferenca": round(diferenca, 2),
        "detratores_atrito_alto": round(det_alto, 4),
        "detratores_atrito_baixo": round(det_baixo, 4),
        "veredito": veredito,
    }


if __name__ == "__main__":
    mensagens = json.loads((DADOS / "mensagens.json").read_text(encoding="utf-8"))
    conversas = json.loads((DADOS / "conversas.json").read_text(encoding="utf-8"))
    todas = [c for lista in conversas.values() for c in lista]
    ids = [c["id"] for c in todas]

    p = perfil(ids, mensagens)
    print(f"conversas com texto do cliente: {p['conversas_com_texto']}")
    print(f"escore medio de atrito........: {p['escore_medio']}\n")
    print("tema                                 conversas   taxa")
    for chave, n in sorted(p["por_tema"].items(), key=lambda x: -x[1]):
        print(f"  {TEMAS[chave]['rotulo']:34} {n:6}   {p['taxa'][chave] * 100:5.1f}%")

    v = validar_contra_csat(todas, mensagens)
    print("\nvalidacao contra o CSAT declarado pelo cliente:")
    if not v["suficiente"]:
        print(f"  amostra pequena demais (alto={v['n_alto']}, baixo={v['n_baixo']})")
    else:
        print(f"  CSAT com atrito alto : {v['csat_atrito_alto']}  "
              f"detratores {v['detratores_atrito_alto'] * 100:.1f}%  (n={v['n_alto']})")
        print(f"  CSAT com atrito baixo: {v['csat_atrito_baixo']}  "
              f"detratores {v['detratores_atrito_baixo'] * 100:.1f}%  (n={v['n_baixo']})")
        print(f"  diferenca de media: {v['diferenca']}  -> veredito: {v['veredito']}")
