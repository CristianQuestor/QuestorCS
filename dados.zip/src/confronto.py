"""Confronta o relato do cancelamento com o que os chamados mostram.

A pergunta que este modulo responde, cliente a cliente: o motivo registrado na
matriz bate com o que o cliente vinha acionando no suporte? E, quando havia
sinal, o que foi feito dele?

Nada aqui e adivinhacao de causa. O modulo apura fatos verificaveis -- quantos
chamados do mesmo tema, em quanto tempo, se algum foi escalado, se algum foi mal
avaliado -- e aplica regras escritas para nomear o padrao. A conclusao continua
sendo de quem le, e cada fato leva ao chamado de origem.
"""
from __future__ import annotations

import unicodedata
from datetime import date, datetime, timezone

from atrito import TEMAS, analisar_texto, analise_guardada
from chatwoot import link_conversa

# Uma etiqueta de escalonamento significa que o chamado saiu do N1 e virou caso
# de alguem: verificacao interna, transferencia de nivel, espera por produto.
MARCAS_ESCALADA = (
    "verificacao", "verificação", "transferencia", "transferência",
    "aguardando-produto", "levantamento", "validacao", "validação",
)

# Regras de leitura. Mudar um numero aqui muda o veredito de todos os clientes,
# entao os limiares ficam visiveis em vez de escondidos no meio do codigo.
REPETICAO_QUE_VIRA_CASO = 3      # chamados do mesmo tema que deveriam abrir caso
JANELA_REPETICAO_DIAS = 90       # em quanto tempo


def _plano(texto: str) -> str:
    t = unicodedata.normalize("NFKD", (texto or "").lower())
    return t.encode("ascii", "ignore").decode()


def _data(marca):
    """Epoch para data LOCAL.

    A data de cancelamento vem do CSV como data comercial brasileira. Converter
    o chamado em UTC jogava para o dia seguinte tudo que foi aberto depois das
    21h, e o filtro de "antes da saida" descartava esses casos.
    """
    try:
        return datetime.fromtimestamp(int(marca)).date()
    except (TypeError, ValueError, OSError):
        return None


def janela_deslizante(datas: list, quantos: int, dias: int):
    """Houve `quantos` eventos dentro de alguma janela de `dias`?

    A versao ingenua compara a amplitude total (ultimo menos primeiro) com a
    janela, e ai um chamado antigo DESLIGA o alerta: tres chamados em dez dias
    disparam, mas um quarto duzentos dias antes faz a amplitude passar de 90 e o
    alerta some. Aqui a janela desliza, como deveria.

    Devolve (bateu, data_em_que_bateu), sendo a data a do evento que fechou a
    contagem na primeira janela que qualificou.
    """
    ordenadas = sorted(datas)
    for i in range(len(ordenadas)):
        dentro = [d for d in ordenadas[i:] if (d - ordenadas[i]).days <= dias]
        if len(dentro) >= quantos:
            return True, dentro[quantos - 1]
    return False, None


def houve_escalada(conversa: dict) -> bool:
    etiquetas = " ".join(conversa.get("labels") or [])
    return any(m in _plano(etiquetas) for m in MARCAS_ESCALADA)


def confrontar(cliente: dict, conversas: list[dict], analises: dict,
               discriminantes: frozenset = frozenset()) -> dict:
    """Compara o relato com os chamados e apura o que foi feito do sinal."""
    corte = (date.fromisoformat(cliente["data_cancelamento"])
             if cliente.get("data_cancelamento") else None)

    # ---------------------------------------------------- o que foi declarado
    texto_relato = " ".join(filter(None, [cliente.get("relato"),
                                          cliente.get("observacoes")]))
    achados_relato = analisar_texto(texto_relato)["temas"] if texto_relato else {}
    achados_relato.pop("ameaca_saida", None)
    declarado = set(achados_relato)

    # ---------------------------------------------------- o que os chamados mostram
    ocorrencias: dict[str, list[dict]] = {}
    for cv in conversas:
        registro = analises.get(cv["id"])
        if not registro:
            continue
        analise = analise_guardada(registro)
        if analise["mensagens_cliente"] == 0:
            continue
        aberta = _data(cv.get("created_at"))
        for chave, trechos in analise["temas"].items():
            ocorrencias.setdefault(chave, []).append({
                "conversa": cv["id"],
                "sujeito": analise.get("sujeitos", {}).get(chave),
                "origem": analise.get("origens", {}).get(chave),
                "link": link_conversa(cv["id"]),
                "data": aberta.isoformat() if aberta else None,
                "dias_antes": (corte - aberta).days if (corte and aberta) else None,
                "csat": cv.get("csat_rating"),
                "servico": cv.get("servico"),
                "escalado": houve_escalada(cv),
                "trecho": trechos[0],
            })
    observado = set(ocorrencias)

    # ---------------------------------------------------- tema dominante
    # Tema dominante nao pode ser o mais frequente e pronto. "Erro e falha"
    # aparece em 63% dos chamados de todo mundo, inclusive de quem fica: e a
    # taxa de fundo do suporte. O tema so vira sinal se for um dos que separam
    # quem saiu de quem ficou no teste estatistico.
    def escolher(entre):
        return max(entre, key=lambda k: (len(ocorrencias[k]), TEMAS[k]["peso"]))

    candidatos = [k for k in ocorrencias if k in discriminantes]
    dominante = escolher(candidatos) if candidatos else (
        escolher(list(ocorrencias)) if ocorrencias else None)
    discrimina = bool(candidatos)

    # ---------------------------------------------------- o que foi feito do sinal
    sinal = None
    if dominante:
        casos = sorted(ocorrencias[dominante], key=lambda x: x["data"] or "")
        datas = [date.fromisoformat(c["data"]) for c in casos if c["data"]]
        intervalo = (max(datas) - min(datas)).days if len(datas) > 1 else 0
        escalados = sum(1 for c in casos if c["escalado"])
        mal_avaliados = sum(1 for c in casos
                            if str(c["csat"] or "").isdigit() and int(c["csat"]) <= 2)
        ultimo = max((c["dias_antes"] for c in casos
                      if c["dias_antes"] is not None), default=None)
        primeiro = min((c["dias_antes"] for c in casos
                        if c["dias_antes"] is not None), default=None)
        bateu, quando = janela_deslizante(datas, REPETICAO_QUE_VIRA_CASO,
                                          JANELA_REPETICAO_DIAS)
        # dias entre o chamado que fechou a regra e a saida: e essa a data que
        # interessa, nao a do primeiro chamado do tema
        bateu_ha_dias = (corte - quando).days if (bateu and corte and quando) else None
        sinal = {
            "tema": dominante,
            "rotulo": TEMAS[dominante]["rotulo"],
            "discrimina": discrimina,
            "chamados_no_total": len(conversas),
            "chamados": len(casos),
            "intervalo_dias": intervalo,
            "escalados": escalados,
            "mal_avaliados": mal_avaliados,
            "primeiro_ha_dias": ultimo,     # o mais distante da saida
            "ultimo_ha_dias": primeiro,     # o mais proximo da saida
            "repetiu": bateu,
            "bateu_ha_dias": bateu_ha_dias,
        }

    # ---------------------------------------------------- veredito
    if not cliente.get("empresa_id"):
        # sem casamento no Chatwoot nao se pode dizer que nao houve chamado:
        # so nao se sabe onde procurar
        veredito, explicacao = "empresa_nao_encontrada", (
            "Este cliente não foi encontrado no cadastro de empresas do Chatwoot, "
            "então não há onde procurar os chamados dele.")
    elif cliente["metricas"]["cobertura"] == "insuficiente":
        veredito, explicacao = "fora_da_janela", (
            "O cancelamento é anterior ao início da base de atendimentos. "
            "Não existe histórico para confrontar com o relato.")
    elif not conversas:
        veredito, explicacao = "sem_contato", (
            "Nenhum chamado antes da saída, com base suficiente para afirmar isso. "
            "O motivo da saída não passou pelo suporte.")
    elif sinal and sinal["discrimina"] and sinal["repetiu"] and sinal["escalados"] == 0:
        veredito, explicacao = "sinal_ignorado", (
            f"{sinal['chamados']} chamados de {sinal['rotulo'].lower()} em "
            f"{sinal['intervalo_dias']} dias, nenhum escalado. É o tema que separa "
            "quem sai de quem fica, e foi tratado como atendimento avulso.")
    elif sinal and sinal["discrimina"] and sinal["repetiu"]:
        veredito, explicacao = "sinal_tratado", (
            f"{sinal['chamados']} chamados de {sinal['rotulo'].lower()} em "
            f"{sinal['intervalo_dias']} dias, {sinal['escalados']} escalado(s). "
            "O problema foi reconhecido e mesmo assim o cliente saiu.")
    elif sinal and sinal["discrimina"]:
        veredito, explicacao = "sinal_fraco", (
            f"{sinal['chamados']} chamado(s) de {sinal['rotulo'].lower()}, sem repetição "
            "suficiente para disparar alerta. O tema de risco apareceu, mas de leve.")
    elif sinal and sinal["chamados_no_total"] >= 20:
        veredito, explicacao = "volume_alto", (
            f"{sinal['chamados_no_total']} chamados antes da saída, mas nenhum tema que "
            "distinga este cliente de quem ficou. Volume alto não é, sozinho, sinal de risco.")
    elif not declarado and not observado:
        veredito, explicacao = "sem_tema", (
            "Nem o relato nem os chamados trazem um tema identificável. "
            "Não há o que confrontar aqui.")
    elif not declarado:
        veredito, explicacao = "relato_generico", (
            "O relato não descreve nenhum atrito concreto, enquanto os chamados "
            "mostram atrito. O registro da saída não guarda o que aconteceu.")
    elif declarado and not (declarado & observado):
        veredito, explicacao = "relato_sem_lastro", (
            "O que o relato declara não aparece nos chamados deste cliente. "
            "Ou a causa é externa ao produto, ou o cliente nunca reportou.")
    elif observado - declarado:
        veredito, explicacao = "atrito_nao_declarado", (
            "Os chamados mostram atrito que o relato não menciona. "
            "O motivo registrado conta parte da história.")
    else:
        veredito, explicacao = "coerente", (
            "O relato e os chamados apontam para a mesma coisa.")

    # ---------------------------------------------------- o que teria mudado
    acao = None
    if veredito == "sinal_ignorado":
        quando = (f"{sinal['bateu_ha_dias']} dias antes de sair"
                  if sinal.get("bateu_ha_dias") is not None else "antes de sair")
        acao = (f"Regra que teria pegado: {REPETICAO_QUE_VIRA_CASO} chamados do mesmo "
                f"tema em {JANELA_REPETICAO_DIAS} dias abrem caso de produto com dono. "
                f"Este cliente bateu a regra {quando}.")
    elif veredito == "sinal_tratado":
        acao = ("O problema foi reconhecido internamente. O que faltou não foi detecção, "
                "e sim prazo de solução ou retorno ao cliente. Vale checar o desfecho "
                "dos chamados escalados.")
    elif veredito == "relato_sem_lastro":
        acao = ("Confirmar a causa com quem registrou a saída. Se o motivo é preço, "
                "concorrente ou decisão do grupo, o suporte não tinha como antecipar.")
    elif veredito == "atrito_nao_declarado":
        acao = ("Rever o motivo registrado com base nos chamados. A tag atual não "
                "descreve o que o cliente vinha enfrentando.")
    elif veredito == "relato_generico":
        acao = ("Escrever o relato com o que os chamados mostram. Um registro que não "
                "nomeia o atrito impede qualquer leitura de padrão depois.")
    elif veredito == "sem_tema":
        acao = ("Sem tema dos dois lados. Confirmar a causa da saída com quem "
                "registrou, porque o suporte não guarda pista deste caso.")
    elif veredito == "sinal_fraco":
        acao = ("Uma ocorrência isolada do tema de risco não justifica ação. Vale só "
                "manter o cliente no radar e checar se o assunto volta.")
    elif veredito == "volume_alto":
        acao = ("Volume alto de chamados sem tema de risco é sinal de adoção intensa, "
                "não de insatisfação. Investigar o motivo declarado por outro caminho.")
    elif veredito == "empresa_nao_encontrada":
        acao = ("Completar o CNPJ na matriz ou localizar a empresa no Chatwoot. "
                "Sem isso este cancelamento fica fora de qualquer leitura.")
    elif veredito == "sem_contato":
        acao = ("Cliente sem contato com o suporte. Aqui a antecipação depende de "
                "contato ativo do CS, não de sinal de chamado.")

    return {
        "veredito": veredito,
        "explicacao": explicacao,
        "acao": acao,
        "declarado": sorted(declarado),
        "observado": sorted(observado),
        "confirmados": sorted(declarado & observado),
        "so_no_relato": sorted(declarado - observado),
        "so_nos_chamados": sorted(observado - declarado),
        "contagem_observada": {k: len(v) for k, v in ocorrencias.items()},
        "sinal": sinal,
        "evidencias": (sorted(ocorrencias.get(dominante, []),
                              key=lambda x: x["data"] or "", reverse=True)[:5]
                       if dominante else []),
        "trecho_relato": {k: v[0] for k, v in achados_relato.items()},
    }


VEREDITOS = {
    "sinal_ignorado": ("Sinal ignorado", "critico"),
    "sinal_tratado": ("Sinal tratado, saiu mesmo assim", "atencao"),
    "sinal_fraco": ("Tema de risco, sem repetição", "atencao"),
    "volume_alto": ("Volume alto, sem tema de risco", "neutro"),
    "atrito_nao_declarado": ("Atrito não declarado", "atencao"),
    "relato_generico": ("Relato genérico demais", "atencao"),
    "relato_sem_lastro": ("Relato sem lastro nos chamados", "neutro"),
    "sem_tema": ("Sem tema dos dois lados", "neutro"),
    "coerente": ("Relato coerente com os chamados", "bom"),
    "sem_contato": ("Saiu sem falar com o suporte", "neutro"),
    "fora_da_janela": ("Fora da janela de dados", "neutro"),
    "empresa_nao_encontrada": ("Empresa não encontrada no Chatwoot", "neutro"),
}
