"""Varre todas as conversas da conta e agrupa por empresa.

A tela de Atencao precisa olhar a base inteira de clientes ativos, nao uma
amostra. O endpoint de listagem devolve, em cada conversa, a empresa do
remetente com CNPJ e tier, mais CSAT, etiquetas, servico e primeira resposta.
Uma varredura das paginas resolve tudo de uma vez, e sai muito mais barato do
que perguntar contato por contato.

Grava incrementalmente e retoma de onde parou.
"""
from __future__ import annotations

import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from chatwoot import Chatwoot, ChatwootErro

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"
ARQUIVO = DADOS / "base-conversas.json"
EMPRESAS = DADOS / "base-empresas.json"
PROGRESSO = DADOS / "base-progresso.json"

TRABALHADORES = 4
GRAVAR_A_CADA = 120      # paginas


def nome_servico(conversa: dict):
    servico = conversa.get("service")
    if isinstance(servico, dict):
        return servico.get("name")
    return servico if isinstance(servico, str) else None


def enxugar(c: dict) -> dict | None:
    remetente = (c.get("meta") or {}).get("sender") or {}
    empresa = remetente.get("company") or {}
    atributos = c.get("custom_attributes") or {}
    return {
        "id": c.get("id"),
        "empresa_id": empresa.get("id"),
        "criada": c.get("created_at"),
        "status": c.get("status"),
        "labels": c.get("labels") or [],
        "csat": c.get("csat_rating"),
        "servico": nome_servico(c),
        "produto": atributos.get("produto"),
        "situacao": atributos.get("Status"),
        "primeira_resposta": c.get("first_reply_created_at"),
        "contato_id": remetente.get("id"),
    }


def ficha_empresa(c: dict) -> dict | None:
    remetente = (c.get("meta") or {}).get("sender") or {}
    empresa = remetente.get("company")
    if not empresa or not empresa.get("id"):
        return None
    return {
        "id": empresa.get("id"),
        "nome": empresa.get("name"),
        "documento": "".join(ch for ch in (empresa.get("registration_number") or "")
                             if ch.isdigit()),
        "tier": (empresa.get("group_company") or {}).get("name"),
    }


def principal() -> int:
    DADOS.mkdir(parents=True, exist_ok=True)
    api = Chatwoot()

    meta = api.get("/conversations?status=all&page=1", cachear=False)["data"]["meta"]
    total = meta.get("all_count", 0)
    paginas = total // 25 + 2
    print(f"conversas na conta: {total}  ->  {paginas} paginas\n")

    conversas: dict[str, dict] = {}
    empresas: dict[str, dict] = {}
    feitas: set[int] = set()
    if ARQUIVO.exists() and PROGRESSO.exists() and EMPRESAS.exists():
        conversas = json.loads(ARQUIVO.read_text(encoding="utf-8"))
        empresas = json.loads(EMPRESAS.read_text(encoding="utf-8"))
        feitas = set(json.loads(PROGRESSO.read_text(encoding="utf-8"))["paginas"])
        print(f"retomando: {len(conversas)} conversas, {len(feitas)} paginas ja lidas\n")

    pendentes = [p for p in range(1, paginas + 1) if p not in feitas]
    if not pendentes:
        print("nada a fazer")
        return 0

    def puxar(p: int):
        try:
            dados = api.get(f"/conversations?status=all&page={p}", cachear=False)
        except ChatwootErro:
            return p, None          # None = falhou, difere de pagina vazia
        return p, dados.get("data", {}).get("payload", [])

    trava = threading.Lock()
    inicio = time.time()
    lidas = 0
    falhas: list[int] = []

    with ThreadPoolExecutor(max_workers=TRABALHADORES) as piscina:
        futuros = [piscina.submit(puxar, p) for p in pendentes]
        for futuro in as_completed(futuros):
            pagina, lote = futuro.result()
            with trava:
                if lote is None:
                    # nao marca como lida: senao um 5xx passageiro descartaria
                    # 25 conversas para sempre, e a retomada nem tentaria de novo
                    falhas.append(pagina)
                    continue
                for c in lote:
                    magra = enxugar(c)
                    if magra and magra["id"]:
                        conversas[str(magra["id"])] = magra
                    ficha = ficha_empresa(c)
                    if ficha:
                        empresas[str(ficha["id"])] = ficha
                feitas.add(pagina)
                lidas += 1
                if lidas % GRAVAR_A_CADA == 0 or lidas == len(pendentes):
                    ARQUIVO.write_text(json.dumps(conversas, ensure_ascii=False),
                                       encoding="utf-8")
                    EMPRESAS.write_text(json.dumps(empresas, ensure_ascii=False),
                                        encoding="utf-8")
                    PROGRESSO.write_text(
                        json.dumps({"paginas": sorted(feitas)}), encoding="utf-8")
                    passado = time.time() - inicio
                    resta = passado / lidas * (len(pendentes) - lidas)
                    print(f"  {lidas:5}/{len(pendentes)} paginas  "
                          f"{len(conversas):6} conversas  {len(empresas):5} empresas  "
                          f"faltam ~{resta / 60:.0f} min")

    print(f"\nconcluido em {(time.time() - inicio) / 60:.1f} min")
    print(f"  {len(conversas)} conversas de {len(empresas)} empresas")
    print(f"  {api.resumo()}")
    return 0


if __name__ == "__main__":
    sys.exit(principal())
