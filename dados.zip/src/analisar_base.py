"""Roda o lexico sobre a base inteira e guarda o resultado no banco.

Sem isto, cada geracao do painel releria milhoes de mensagens. Com a analise
gravada e carimbada com a versao do lexico, so e reprocessado o que ficou velho:
mudou o lexico, reprocessa; nao mudou, e leitura de tabela.

Uma passada unica sobre as mensagens, em fluxo. O cursor nomeado do psycopg2
mantem o resultado no servidor e traz aos poucos, entao 4,4 milhoes de linhas
nao precisam caber na memoria.
"""
from __future__ import annotations

import json
import sys
import time

import psycopg2.extras

import banco
from atrito import TEMAS, VERSAO_LEXICO, analisar_texto

LOTE_GRAVACAO = 2000        # conversas por insert
LOTE_LEITURA = 20000        # linhas trazidas por vez do servidor

CRIAR_TABELA = """
create table if not exists analise_conversa (
    conversa_id       integer primary key,
    versao_lexico     text    not null,
    mensagens_cliente integer not null,
    palavras_cliente  integer not null,
    escore            integer not null,
    positivos         integer not null,
    temas             jsonb   not null,
    sujeitos          jsonb   not null default '{}'::jsonb,
    origens           jsonb   not null default '{}'::jsonb,
    atualizado_em     timestamp default now()
);
create index if not exists idx_analise_versao on analise_conversa (versao_lexico);
"""


def preparar(con) -> None:
    with con.cursor() as cur:
        cur.execute(CRIAR_TABELA)
        # coluna nova em base ja existente
        cur.execute("alter table analise_conversa add column if not exists "
                    "sujeitos jsonb not null default '{}'::jsonb")
        cur.execute("alter table analise_conversa add column if not exists "
                    "origens jsonb not null default '{}'::jsonb")
    con.commit()


def pendentes(con) -> int:
    """Conversas da conta que ainda nao tem analise na versao atual do lexico."""
    with con.cursor() as cur:
        cur.execute("""
            select count(*) from conversations c
             where c.account_id = %(conta)s
               and not exists (
                   select 1 from analise_conversa a
                    where a.conversa_id = c.id
                      and a.versao_lexico = %(versao)s)
        """, {"conta": banco.CONTA, "versao": VERSAO_LEXICO})
        return cur.fetchone()[0]


# quanto mais perto da frase, mais confiavel: usado para escolher qual
# ocorrencia representa o tema na conversa
FORCA_ORIGEM = {"frase": 4, "mensagem": 3, "conversa": 2, "chamado": 1, "nenhuma": 0}


def _resultado(cid: int, falas: list[str], contexto: str = "") -> tuple:
    temas: dict[str, str] = {}
    sujeitos: dict[str, str] = {}
    origens: dict[str, str] = {}
    positivos = 0
    palavras = 0
    # a conversa inteira serve de contexto para as falas que sozinhas nao dizem
    # de que e a queixa ("esse e bem demorado")
    conversa = " ".join(falas)
    for texto in falas:
        palavras += len(texto.split())
        achado = analisar_texto(texto, contexto, conversa)
        positivos += achado["positivos"]
        for chave, trechos in achado["temas"].items():
            origem = achado["origens"].get(chave, "nenhuma")
            if chave not in temas:
                temas[chave] = trechos[0]
                sujeitos[chave] = achado["sujeitos"].get(chave, "indefinido")
                origens[chave] = origem
            elif FORCA_ORIGEM[origem] > FORCA_ORIGEM.get(origens[chave], 0):
                # a ocorrencia que diz de que e a queixa vale mais que a que
                # so deixa inferir, mesmo aparecendo depois na conversa
                temas[chave] = trechos[0]
                sujeitos[chave] = achado["sujeitos"].get(chave, "indefinido")
                origens[chave] = origem
    escore = sum(TEMAS[c]["peso"] for c in temas)
    return (cid, VERSAO_LEXICO, len(falas), palavras, escore, positivos,
            json.dumps(temas, ensure_ascii=False),
            json.dumps(sujeitos, ensure_ascii=False),
            json.dumps(origens, ensure_ascii=False))


def processar(con, con_escrita) -> int:
    """Le por uma conexao e grava por outra.

    O cursor nomeado vive dentro de uma transacao; se o commit da gravacao
    acontecer na mesma conexao, o cursor de leitura morre no meio do fluxo.
    Duas conexoes resolvem sem precisar de cursor WITH HOLD.
    """
    total = pendentes(con)
    print(f"versao do lexico......: {VERSAO_LEXICO}")
    print(f"conversas a analisar..: {total}")
    if not total:
        print("nada a fazer")
        return 0

    inicio = time.time()
    leitura = con.cursor(name="fluxo_mensagens")
    leitura.itersize = LOTE_LEITURA
    # so a fala do cliente interessa: e sobre ela que o lexico foi escrito
    leitura.execute("""
        select m.conversation_id, m.content,
               coalesce(s.name,'') || ' ' || coalesce(c.custom_attributes->>'produto','')
          from messages m
          join conversations c on c.id = m.conversation_id
     left join services s on s.id = c.service_id
         where m.account_id = %(conta)s
           and coalesce(m.private, false) = false
           and m.message_type = 0
           and coalesce(trim(m.content), '') <> ''
           and not exists (
               select 1 from analise_conversa a
                where a.conversa_id = c.id and a.versao_lexico = %(versao)s)
         order by m.conversation_id, m.id
    """, {"conta": banco.CONTA, "versao": VERSAO_LEXICO})

    escrita = con_escrita.cursor()
    buffer: list[tuple] = []
    atual = None
    falas: list[str] = []
    gravadas = 0
    mensagens = 0

    def descarregar():
        nonlocal buffer, gravadas
        if not buffer:
            return
        psycopg2.extras.execute_values(escrita, """
            insert into analise_conversa
                (conversa_id, versao_lexico, mensagens_cliente, palavras_cliente,
                 escore, positivos, temas, sujeitos, origens)
            values %s
            on conflict (conversa_id) do update set
                versao_lexico = excluded.versao_lexico,
                mensagens_cliente = excluded.mensagens_cliente,
                palavras_cliente = excluded.palavras_cliente,
                escore = excluded.escore,
                positivos = excluded.positivos,
                temas = excluded.temas,
                sujeitos = excluded.sujeitos,
                origens = excluded.origens,
                atualizado_em = now()
        """, buffer)
        con_escrita.commit()
        gravadas += len(buffer)
        buffer = []
        passado = time.time() - inicio
        print(f"  {gravadas:7} conversas  {mensagens:8} mensagens  "
              f"{gravadas / max(passado, 1):.0f}/s")

    contexto = ""
    for cid, texto, ctx in leitura:
        mensagens += 1
        if cid != atual:
            if atual is not None:
                buffer.append(_resultado(atual, falas, contexto))
                if len(buffer) >= LOTE_GRAVACAO:
                    descarregar()
            atual = cid
            falas = []
        contexto = ctx or ""
        falas.append(texto)
    if atual is not None:
        buffer.append(_resultado(atual, falas, contexto))
    descarregar()
    leitura.close()

    # conversas sem nenhuma fala de cliente tambem precisam de registro, senao
    # seriam reprocessadas para sempre
    escrita.execute("""
        insert into analise_conversa
            (conversa_id, versao_lexico, mensagens_cliente, palavras_cliente,
             escore, positivos, temas, sujeitos, origens)
        select c.id, %(versao)s, 0, 0, 0, 0, '{}'::jsonb, '{}'::jsonb, '{}'::jsonb
          from conversations c
         where c.account_id = %(conta)s
           and not exists (select 1 from analise_conversa a
                            where a.conversa_id = c.id
                              and a.versao_lexico = %(versao)s)
        on conflict (conversa_id) do update set
            versao_lexico = excluded.versao_lexico,
            mensagens_cliente = 0, palavras_cliente = 0,
            escore = 0, positivos = 0, temas = '{}'::jsonb,
            sujeitos = '{}'::jsonb, origens = '{}'::jsonb, atualizado_em = now()
    """, {"conta": banco.CONTA, "versao": VERSAO_LEXICO})
    sem_fala = escrita.rowcount
    con_escrita.commit()

    print(f"\nconcluido em {(time.time() - inicio) / 60:.1f} min")
    print(f"  {gravadas} conversas com fala do cliente")
    print(f"  {sem_fala} conversas sem fala do cliente")
    return 0


if __name__ == "__main__":
    with banco.conexao() as con, banco.conexao() as con_escrita:
        preparar(con_escrita)
        sys.exit(processar(con, con_escrita))
