"""Origem dos dados para o painel, lendo do banco restaurado.

Substitui a leitura dos arquivos JSON que vinham da API. Devolve exatamente as
mesmas formas que o pipeline ja consumia, para que a analise nao mude junto com
a origem e seja possivel comparar numero a numero.

Duas diferencas de conteudo, ambas para melhor:

1. A API cortava em 20 conversas por contato, sem avisar. O banco nao corta.
2. O grupo de controle deixa de ser uma amostra de 114 empresas e passa a ser
   todo cliente que nao cancelou, na mesma faixa de datas.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import psycopg2.extras

import banco
from atrito import VERSAO_LEXICO

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"


def cancelamentos_casados(con, registros: list[dict]) -> list[dict]:
    """Casa cada linha do CSV com a empresa, pelo CNPJ, direto no banco."""
    docs = [r["documento"] for r in registros if r["documento"]]
    achadas = banco.empresas_por_documento(con, docs)
    saida = []
    for r in registros:
        empresa = achadas.get(r["documento"]) if r["documento"] else None
        registro = dict(r)
        registro["criterio_casamento"] = "cnpj" if empresa else "nenhum"
        registro["casamento_confiavel"] = bool(empresa)
        if empresa:
            registro.update({
                "empresa_id": empresa["id"],
                "empresa_nome": empresa["name"],
                "tier": (empresa.get("group_company") or {}).get("name"),
                "ambiente": (empresa.get("custom_attributes") or {}).get("ambiente"),
                "contatos_total": empresa.get("contacts_count"),
            })
        else:
            registro.update({"empresa_id": None, "empresa_nome": None, "tier": None,
                             "ambiente": None, "contatos_total": 0})
        saida.append(registro)
    return saida


def analises(con, ids_conversa: list[int]) -> dict[int, dict]:
    """Resultado do lexico por conversa, ja gravado por analisar_base.py."""
    if not ids_conversa:
        return {}
    with con.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            select conversa_id, mensagens_cliente, palavras_cliente,
                   escore, positivos, temas, sujeitos, origens
              from analise_conversa
             where versao_lexico = %s and conversa_id = any(%s)
        """, (VERSAO_LEXICO, list(ids_conversa)))
        return {r["conversa_id"]: dict(r) for r in cur}


def conversas_do_controle(con, inicio: date, fim: date,
                          excluir: set[int]) -> dict[str, list[dict]]:
    """Todo cliente que nao cancelou, na mesma faixa de datas do churn."""
    return banco.conversas_no_periodo(con, inicio, fim, excluir)


def feedback_por_nota(con) -> dict:
    """Comentarios do CSAT agrupados por nota.

    E a melhor fonte de sentimento desta base: o cliente escrevendo o motivo da
    nota que ele mesmo deu, em vez de uma inferencia sobre o texto do chamado.
    """
    linhas = banco.feedback_csat(con, so_com_texto=True)
    por_nota: dict[int, list[dict]] = {}
    for linha in linhas:
        por_nota.setdefault(linha["nota"], []).append(linha)
    return por_nota


def resumo_base(con) -> dict:
    r = banco.resumo(con)
    with con.cursor() as cur:
        cur.execute("select count(*) from analise_conversa where versao_lexico=%s",
                    (VERSAO_LEXICO,))
        r["conversas_analisadas"] = cur.fetchone()[0]
    r["versao_lexico"] = VERSAO_LEXICO
    return r


if __name__ == "__main__":
    import cancelamentos as csvmod
    with banco.conexao() as con:
        print(json.dumps(resumo_base(con), ensure_ascii=False, indent=2))
        registros = csvmod.ler()
        casados = cancelamentos_casados(con, registros)
        achados = sum(1 for c in casados if c["empresa_id"])
        print(f"\ncancelamentos: {len(casados)}, casados por CNPJ: {achados}")
        ids = [c["empresa_id"] for c in casados if c["empresa_id"]]
        conv = banco.conversas_por_empresa(con, ids)
        print(f"conversas dessas empresas: {sum(len(v) for v in conv.values())}")
