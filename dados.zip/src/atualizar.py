"""Roda o processo inteiro: extrai do Chatwoot, calcula e gera o dashboard.

Uso:
    python src/atualizar.py            # aproveita o cache de chamadas ja feitas
    python src/atualizar.py --limpar   # descarta o cache e busca tudo de novo
    python src/atualizar.py --texto    # tambem baixa o texto das conversas
    python src/atualizar.py --controle # tambem monta o grupo de controle

As duas ultimas etapas sao demoradas e so precisam rodar quando ha dados novos.
Sem elas, a aba de atrito usa o que ja estiver em dados/mensagens.json.
"""
from __future__ import annotations

import shutil
import sys
import time
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

import extrair          # noqa: E402
import metricas         # noqa: E402
import painel           # noqa: E402
import json             # noqa: E402


def principal() -> int:
    inicio = time.time()
    if "--limpar" in sys.argv:
        cache = RAIZ / "dados" / "cache"
        if cache.exists():
            shutil.rmtree(cache)
            print("cache descartado\n")

    extrair.principal()

    if "--controle" in sys.argv:
        print("\n== etapa 2b: montando o grupo de controle ==")
        import controle
        controle.principal()

    if "--texto" in sys.argv or "--controle" in sys.argv:
        print("\n== etapa 3b: baixando o texto das conversas ==")
        import mensagens
        mensagens.principal()

    print("\n== etapa 4: calculando metricas ==")
    resultado = metricas.construir()
    destino = RAIZ / "dados" / "dashboard.json"
    destino.write_text(json.dumps(resultado, ensure_ascii=False), encoding="utf-8")
    r = resultado["resumo"]
    print(f"   base de atendimentos comeca em {resultado['inicio_base']}")
    print(f"   {r['analisaveis']} clientes analisaveis, "
          f"{r['fora_da_janela']} fora da janela de dados")
    atrito = resultado.get("atrito") or {}
    if atrito.get("disponivel"):
        fortes = [l for l in atrito["comparacao"] if l.get("confiavel") and (l.get("lift") or 0) > 1]
        print(f"   atrito: {atrito['churn']['conversas_com_texto']} conversas lidas, "
              f"{len(fortes)} tema(s) com diferenca significativa")
        for l in fortes:
            print(f"     - {l['rotulo']}: {l['lift']}x (p={l['teste']['p']})")
    else:
        print("   atrito: sem texto de conversa. Rode com --texto")

    confrontos = {}
    for c in resultado["clientes"]:
        v = (c.get("confronto") or {}).get("veredito")
        if v:
            confrontos[v] = confrontos.get(v, 0) + 1
    if confrontos.get("sinal_ignorado"):
        print(f"   confronto: {confrontos['sinal_ignorado']} cancelamento(s) com sinal "
              "repetido e nenhum escalonamento")

    vig = resultado.get("atencao") or {}
    if vig.get("disponivel"):
        c = vig["contagem"]
        print(f"   atencao: {c['critico']} para acao agora, {c['atencao']} para acompanhar, "
              f"{vig['cobertura']['empresas_ativas']} empresas ativas varridas")
        if vig["cobertura"]["sem_texto"]:
            print(f"     {vig['cobertura']['sem_texto']} candidatos sem texto lido. "
                  "Rode atencao.py --preparar e depois mensagens.py")
    else:
        print(f"   atencao: {vig.get('motivo', 'indisponivel')}")

    print("\n== etapa 5: gerando o dashboard ==")
    arquivo = painel.gerar()
    print(f"   {arquivo}")

    print(f"\n== tudo pronto em {time.time() - inicio:.0f}s ==")
    print(f"   abra: {arquivo}")
    return 0


if __name__ == "__main__":
    sys.exit(principal())
