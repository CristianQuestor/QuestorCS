"""Tela de Atencao: onde a lentidao mais aperta hoje.

Esta tela mudou de proposito depois de ser calibrada, e vale registrar por que.

A intencao era prever churn: lentidao e o unico tema que separa quem cancelou de
quem ficou no nivel da CONVERSA (11,5% contra 7,8%, p = 0,0054). Mas ao testar a
regra no nivel do CLIENTE, ela nao separa nada: "3 ou mais chamados de lentidao
em 90 dias" acontece com 36% de quem cancelou e 35,7% de quem ficou. Lift 1,02.
Com limiares maiores fica pior, abaixo de 1.

O motivo e que lentidao nao e marca de cliente em risco, e sim um problema que
atinge a base inteira. Mais de um terco dos clientes ativos reclama disso.

Entao a tela nao promete prever saida. Ela ordena os clientes por quanto a
lentidao pesa no atendimento deles, o que continua sendo trabalho util de CS e
de produto, sem vender uma previsao que o dado nao sustenta. A calibracao fica
na propria tela, para ninguem reaproveitar a regra achando que ela prediz.
"""
from __future__ import annotations

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path

import psycopg2.extras

import banco
from atrito import TEMAS, VERSAO_LEXICO
from chatwoot import link_conversa
from confronto import (JANELA_REPETICAO_DIAS, MARCAS_ESCALADA,
                       REPETICAO_QUE_VIRA_CASO, janela_deslizante)

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "dados"

JANELA_ALERTA = 90        # dias olhados para tras a partir da referencia
MIN_CHAMADOS = 3          # abaixo disso nao ha padrao para ler

# contas internas, que nao sao cliente
PADRAO_INTERNO = re.compile(
    r"demonstra|questor demo|\bdemo\b|\bteste\b|treinamento|homologa", re.I)

# Faixas por quanto a lentidao ocupa o atendimento do cliente. Sao descricoes do
# presente, nao previsoes: nenhum limiar aqui separa quem sai de quem fica.
NIVEIS = {
    "critico": ("Muito afetado", "critico"),
    "atencao": ("Afetado", "atencao"),
    "observar": ("Pouco afetado", "neutro"),
}
FAIXA_MUITO = 0.20      # lentidao em 20% ou mais dos chamados
FAIXA_MEDIA = 0.10
# proporcao sozinha engana: 3 de 4 chamados da 75% e nao quer dizer nada.
# A faixa de cima exige tambem um numero absoluto de ocorrencias.
MIN_TEMA_FAIXA_ALTA = 5

CONSULTA = """
    select ct.company_id            as empresa_id,
           e.name                   as empresa,
           regexp_replace(coalesce(e.registration_number,''),'\\D','','g') as documento,
           g.name                   as tier,
           c.id                     as conversa,
           c.created_at::date       as dia,
           c.cached_label_list      as etiquetas,
           s.name                   as servico,
           r.rating                 as csat,
           a.temas                  as temas,
           a.sujeitos               as sujeitos,
           a.origens                as origens,
           a.mensagens_cliente      as falas
      from conversations c
      join contacts  ct on ct.id = c.contact_id
      join companies e  on e.id  = ct.company_id
 left join group_companies g on g.id = e.group_company_id
 left join services s on s.id = c.service_id
 left join analise_conversa a on a.conversa_id = c.id and a.versao_lexico = %(versao)s
 left join lateral (select rating from csat_survey_responses
                     where conversation_id = c.id order by id desc limit 1) r on true
     where c.account_id = %(conta)s
       and c.created_at::date between %(inicio)s and %(fim)s
"""


def excluidos(con) -> set[int]:
    """Empresas que ja cancelaram nao entram na tela de quem ainda pode sair."""
    caminho = DADOS / "empresas.json"
    if caminho.exists():
        registros = json.loads(caminho.read_text(encoding="utf-8"))
        return {c["empresa_id"] for c in registros if c.get("empresa_id")}
    import cancelamentos as csvmod
    import fonte
    return {c["empresa_id"] for c in fonte.cancelamentos_casados(con, csvmod.ler())
            if c.get("empresa_id")}


def escalado(etiquetas: str | None) -> bool:
    texto = (etiquetas or "").lower()
    return any(m in texto for m in MARCAS_ESCALADA)


def referencia(con) -> date:
    with con.cursor() as cur:
        cur.execute("select max(created_at)::date from conversations where account_id=%s",
                    (banco.CONTA,))
        return cur.fetchone()[0] or date.today()


def calibracao(con, discriminantes: set[str], inicio_base: date) -> dict:
    """Testa a regra contra a realidade, e publica o resultado do teste.

    Sem isto, alguem olharia a lista e concluiria que aqueles clientes vao sair.
    A tabela mostra que a mesma regra dispara quase igual nos dois grupos, e
    portanto que a lista serve para priorizar trabalho, nao para prever saida.
    """
    caminho = DADOS / "empresas.json"
    if not caminho.exists():
        return {"possivel": False, "motivo": "empresas.json ausente"}
    registros = json.loads(caminho.read_text(encoding="utf-8"))
    pares = {c["empresa_id"]: c["data_cancelamento"] for c in registros
             if c.get("empresa_id") and c.get("data_cancelamento")}
    tema = sorted(discriminantes)[0] if discriminantes else None
    if not tema:
        return {"possivel": False, "motivo": "nenhum tema discriminante"}

    with con.cursor() as cur:
        saiu = []
        for eid, dt in pares.items():
            corte = date.fromisoformat(dt)
            if (corte - inicio_base).days < 30:
                continue
            ini = max(inicio_base, corte - timedelta(days=JANELA_ALERTA))
            cur.execute("""
                select count(*), count(*) filter (where a.temas ? %s)
                  from conversations c
                  join contacts ct on ct.id = c.contact_id
                  join analise_conversa a on a.conversa_id = c.id
                 where c.account_id = %s and ct.company_id = %s
                   and c.created_at::date between %s and %s
                   and a.mensagens_cliente > 0
            """, (tema, banco.CONTA, eid, ini, corte))
            total, com = cur.fetchone()
            if total >= MIN_CHAMADOS:
                saiu.append((total, com))

        fim = referencia(con)
        cur.execute("""
            select ct.company_id, count(*), count(*) filter (where a.temas ? %s)
              from conversations c
              join contacts ct on ct.id = c.contact_id
              join analise_conversa a on a.conversa_id = c.id
             where c.account_id = %s
               and c.created_at::date between %s and %s
               and a.mensagens_cliente > 0 and ct.company_id is not null
             group by 1 having count(*) >= %s
        """, (tema, banco.CONTA, fim - timedelta(days=JANELA_ALERTA), fim, MIN_CHAMADOS))
        ficou = [(t, c) for eid, t, c in cur.fetchall() if eid not in pares]

    if len(saiu) < 5 or len(ficou) < 50:
        return {"possivel": False, "motivo": "amostra pequena demais",
                "n_saiu": len(saiu), "n_ficou": len(ficou)}

    def taxa(grupo, regra):
        return sum(1 for x in grupo if regra(x)) / len(grupo)

    regras = [
        (f"{n} ou mais chamados do tema", (lambda n: (lambda x: x[1] >= n))(n))
        for n in (3, 5, 8)
    ] + [
        (f"tema em {int(f * 100)}% ou mais dos chamados",
         (lambda f: (lambda x: x[0] and x[1] / x[0] >= f))(f))
        for f in (0.20, 0.30)
    ]
    from sintese import teste_duas_proporcoes

    linhas = []
    for rotulo, regra in regras:
        x1 = sum(1 for x in saiu if regra(x))
        x2 = sum(1 for x in ficou if regra(x))
        a, b = x1 / len(saiu), x2 / len(ficou)
        # o mesmo rigor do resto do painel: lift sem teste nao vira conclusao.
        # Com poucos clientes que cancelaram, testar varias regras e escolher a
        # que parece melhor e receita de encontrar padrao onde nao ha.
        teste = teste_duas_proporcoes(x1, len(saiu), x2, len(ficou))
        linhas.append({"regra": rotulo, "n_saiu": x1, "n_ficou": x2,
                       "taxa_saiu": round(a, 4), "taxa_ficou": round(b, 4),
                       "lift": round(a / b, 2) if b else None,
                       "teste": teste,
                       "sustenta": bool(teste and teste.get("significativo")
                                        and a > b)})
    return {"possivel": True, "tema": tema, "rotulo_tema": TEMAS[tema]["rotulo"],
            "n_saiu": len(saiu), "n_ficou": len(ficou), "linhas": linhas,
            "regras_testadas": len(linhas),
            "separa": any(l["sustenta"] for l in linhas)}


def construir(discriminantes: set[str], con=None) -> dict:
    fechar = con is None
    con = con or banco.abrir()
    try:
        return _construir(discriminantes, con)
    finally:
        if fechar:
            con.close()


def _construir(discriminantes: set[str], con) -> dict:
    fim = referencia(con)
    inicio = fim - timedelta(days=JANELA_ALERTA)
    fora = excluidos(con)

    por_empresa: dict[int, list[dict]] = defaultdict(list)
    fichas: dict[int, dict] = {}
    with con.cursor(name="fluxo_atencao",
                    cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.itersize = 20000
        cur.execute(CONSULTA, {"conta": banco.CONTA, "versao": VERSAO_LEXICO,
                               "inicio": inicio, "fim": fim})
        for r in cur:
            eid = r["empresa_id"]
            if eid in fora or PADRAO_INTERNO.search(r["empresa"] or ""):
                continue
            fichas.setdefault(eid, {"nome": r["empresa"], "documento": r["documento"],
                                    "tier": r["tier"]})
            por_empresa[eid].append(r)

    clientes = []
    for eid, linhas in por_empresa.items():
        if len(linhas) < MIN_CHAMADOS:
            continue
        ficha = fichas[eid]

        notas = [int(x["csat"]) for x in linhas if str(x["csat"] or "").isdigit()]
        detratores = sum(1 for n in notas if n <= 2)
        servicos = Counter(x["servico"] for x in linhas if x["servico"])
        reincidente = servicos.most_common(1)[0] if servicos else None

        corte30 = fim - timedelta(days=30)
        ultimos = [x for x in linhas if x["dia"] > corte30]
        antes = [x for x in linhas if x["dia"] <= corte30]
        ritmo = round((len(ultimos) / 30) / (len(antes) / 60), 2) if antes else None

        # ocorrencias do tema de risco, com a frase de origem
        risco: dict[str, list[dict]] = defaultdict(list)
        for x in linhas:
            for chave, trecho in (x["temas"] or {}).items():
                if chave in discriminantes:
                    risco[chave].append({
                        "conversa": x["conversa"], "link": link_conversa(x["conversa"]),
                        "sujeito": (x["sujeitos"] or {}).get(chave),
                        "origem": (x["origens"] or {}).get(chave),
                        "data": x["dia"].isoformat(), "csat": x["csat"],
                        "servico": x["servico"], "escalado": escalado(x["etiquetas"]),
                        "trecho": trecho,
                    })

        alerta = None
        if risco:
            tema = max(risco, key=lambda k: len(risco[k]))
            casos = sorted(risco[tema], key=lambda c: c["data"])
            datas = [date.fromisoformat(c["data"]) for c in casos]
            bateu, quando = janela_deslizante(datas, REPETICAO_QUE_VIRA_CASO,
                                              JANELA_REPETICAO_DIAS)
            alerta = {
                "tema": tema, "rotulo": TEMAS[tema]["rotulo"],
                "chamados": len(casos),
                "intervalo_dias": (max(datas) - min(datas)).days if len(datas) > 1 else 0,
                "escalados": sum(1 for c in casos if c["escalado"]),
                "bate_regra": bateu,
                "bateu_em": quando.isoformat() if quando else None,
                "ultimo": max(c["data"] for c in casos),
                "evidencias": sorted(casos, key=lambda c: c["data"], reverse=True)[:4],
            }

        candidato = {
            "chamados_90d": len(linhas), "chamados_30d": len(ultimos),
            "ritmo": ritmo, "detratores": detratores, "csat_notas": len(notas),
            "escalados": sum(1 for x in linhas if escalado(x["etiquetas"])),
            "servico_reincidente": list(reincidente) if reincidente else None,
            "conversas_lidas": sum(1 for x in linhas if (x["falas"] or 0) > 0),
            "alerta": alerta,
        }
        nivel, porque, acao = classificar(candidato)
        clientes.append({"empresa_id": eid, **ficha, "nivel": nivel,
                         "porque": porque, "acao": acao, **candidato})

    # ordena pela PROPORCAO que a lentidao ocupa, nao pela contagem bruta:
    # 40 chamados de lentidao em 400 pesa menos que 8 em 20
    def peso(x):
        a = x.get("alerta")
        if not a:
            return 0.0
        return a["chamados"] / max(x["chamados_90d"], 1)

    ordem = {"critico": 0, "atencao": 1, "observar": 2}
    clientes.sort(key=lambda x: (ordem[x["nivel"]], -peso(x),
                                 -(x["alerta"]["chamados"] if x["alerta"] else 0)))
    for c in clientes:
        c["parcela_tema"] = round(peso(c), 4)
    contagem = {n: sum(1 for c in clientes if c["nivel"] == n) for n in ordem}

    return {
        "disponivel": True,
        "referencia": fim.isoformat(),
        "janela_dias": JANELA_ALERTA,
        "regra": {"chamados": REPETICAO_QUE_VIRA_CASO, "dias": JANELA_REPETICAO_DIAS,
                  "temas": sorted(discriminantes)},
        "cobertura": {
            "empresas_ativas": len(por_empresa),
            "conversas_varridas": sum(len(v) for v in por_empresa.values()),
            "candidatas": len(clientes),
            "sem_texto": 0,
            "completa": True,
        },
        "calibracao": calibracao(con, discriminantes, date(2026, 5, 5)),
        "faixas": {"muito": FAIXA_MUITO, "media": FAIXA_MEDIA},
        "niveis": {k: v[0] for k, v in NIVEIS.items()},
        "classes": {k: v[1] for k, v in NIVEIS.items()},
        "clientes": clientes[:600],
        "contagem": contagem,
    }


def classificar(c: dict) -> tuple[str, str, str]:
    """Faixa, o porque e o que fazer.

    Sem promessa de previsao: o rotulo descreve quanto a lentidao ocupa o
    atendimento deste cliente hoje.
    """
    a = c.get("alerta")
    total = max(c.get("chamados_90d", 0), 1)
    if a:
        parcela = a["chamados"] / total
        quanto = f"{a['chamados']} de {total} chamados ({parcela * 100:.0f}%)"
        pendura = ("" if a["escalados"] else " Nenhum deles virou caso interno.")
        if parcela >= FAIXA_MUITO and a["chamados"] >= MIN_TEMA_FAIXA_ALTA:
            return ("critico",
                    f"{quanto} tocam {a['rotulo'].lower()}, em "
                    f"{a['intervalo_dias']} dias.{pendura}",
                    "Falar com o cliente sobre desempenho e levar o caso para produto "
                    "com os chamados em anexo. É onde a queixa está mais concentrada.")
        if parcela >= FAIXA_MEDIA:
            return ("atencao",
                    f"{quanto} tocam {a['rotulo'].lower()}.{pendura}",
                    "Vale uma conversa sobre desempenho no próximo contato de rotina.")
        return ("observar",
                f"{quanto} tocam {a['rotulo'].lower()}.",
                "Nada a fazer por este painel. A queixa existe, mas é pontual.")
    if c.get("detratores"):
        return ("observar",
                f"{c['detratores']} chamado(s) com nota 1 ou 2 nos últimos "
                f"{JANELA_ALERTA} dias, sem queixa de lentidão.",
                "Ouvir o cliente sobre o atendimento mal avaliado.")
    return ("observar",
            f"{c['chamados_90d']} chamados em {JANELA_ALERTA} dias, sem queixa de lentidão.",
            "Nenhuma ação necessária por este painel.")


if __name__ == "__main__":
    with banco.conexao() as con:
        painel = _construir({"lentidao"}, con)
    print(f"referencia: {painel['referencia']}  janela: {painel['janela_dias']} dias")
    print(f"cobertura.: {painel['cobertura']}")
    print(f"contagem..: {painel['contagem']}\n")
    for c in painel["clientes"][:12]:
        print(f"  [{c['nivel']:8}] {(c['nome'] or '?')[:44]:44} {c['porque'][:66]}")
