# Issue MCP `desk-questor` — Tool `listar_chamados` com filtro de data retroativa

**Prioridade:** P0 (bloqueia análises gerenciais do dia a dia)
**Repositório:** `D:\WorkSpace\desk-questor-mcp\`
**Solicitante:** Fabio Puhl — Diretoria de Tecnologia
**Data:** 21/04/2026

---

## 1. Problema

Hoje o MCP só tem `listar_chamados_ativos_hoje`, que filtra implicitamente por `DataCriacao = hoje_BRT`. Não há forma de consultar chamados de dias anteriores, nem combinar filtros de data com operador/grupo/status.

Isso bloqueia **qualquer análise retrospectiva** — mesmo a pergunta mais básica que um gestor de suporte faz todo dia de manhã: "o que ficou pendente de ontem?".

### Evidência do custo atual

Hoje (21/04, feriado) perguntei quantos chamados de ontem (20/04) ficaram sem resposta. Como a tool não existe, fui obrigado a:

1. Usar um snapshot antigo de `listar_chamados_ativos_hoje` salvo em arquivo (apenas coincidência — se não tivesse salvo, seria impossível).
2. Escolher uma amostra estratificada de 8 chamados.
3. Fazer 8 chamadas individuais a `obter_chamado` para verificar `DataFinalizacao`.
4. Extrapolar para os 251 totais com faixa de erro larga (resposta: "entre 193 e 219 ficaram sem resposta").

**Com a tool que estamos pedindo, a mesma pergunta seria respondida em uma chamada, com número exato.**

---

## 2. Tool a ser criada

### 2.1 Nome

`listar_chamados`

Nota: NÃO é `listar_chamados_ativos`, porque o parâmetro `apenas_ativos` passa a ser opcional — queremos também poder listar finalizados. A tool atual `listar_chamados_ativos_hoje` fica **como alias** (ver seção 5).

### 2.2 Assinatura proposta (Pydantic)

```python
class ListarChamadosInput(BaseModel):
    # Filtros de data — aceitam "YYYY-MM-DD" (timezone BRT implícito)
    data_criacao_de: Optional[str] = None
    data_criacao_ate: Optional[str] = None
    data_alteracao_de: Optional[str] = None
    data_alteracao_ate: Optional[str] = None
    data_finalizacao_de: Optional[str] = None
    data_finalizacao_ate: Optional[str] = None

    # Filtros de dimensão — todos opcionais, combinam com AND
    grupo: Optional[str] = None          # nome exato da fila
    operador: Optional[str] = None       # match parcial por nome
    operador_chave: Optional[int] = None # match exato por chave
    status: Optional[List[str]] = None   # lista de nomes de status
    sla_expirado: Optional[bool] = None  # True = SLA1 OU SLA2 expirado
    sem_operador: Optional[bool] = None  # True = CodOperador vazio

    # Controles do resultado
    apenas_ativos: bool = True           # default mantém comportamento atual
    limite: int = 100                    # teto 2000
    ordem: str = "tempo_aberto_desc"     # mesmas opções de hoje + data_finalizacao_desc
```

### 2.3 Schema de retorno

Mesmo dos chamados já enriquecidos em `listar_chamados_ativos_hoje`, acrescentando **3 campos novos** relevantes para análise retrospectiva:

```python
{
    # ... todos os campos atuais (chave, codigo, assunto, grupo, operador, etc.)

    # NOVOS CAMPOS
    "data_finalizacao": "2026-04-20",           # None se não finalizado
    "hora_finalizacao": "17:12:45",             # None se não finalizado
    "horas_ate_finalizacao_uteis": 7.98,        # None se não finalizado; descontando seg-sex + feriados
    "finalizado_no_mesmo_dia": True,            # útil para KPI "fechou no dia que abriu?"
}
```

### 2.4 Validações

- `data_*_de` ≤ `data_*_ate` em cada par; erro claro se violado.
- Formato de data rigoroso `YYYY-MM-DD`; erro claro se inválido.
- Se `apenas_ativos=True` E `data_finalizacao_*` for passado → warning (combinação sem sentido).
- Janela máxima permitida: 90 dias. Janelas maiores → erro sugerindo usar `export` via Metabase para análises históricas.

---

## 3. Casos de uso que precisam funcionar

Estes são os **smoke tests obrigatórios**. Se qualquer um falhar, a entrega não está completa.

### Caso 1 — "O que ficou sem resposta de ontem?"

```python
listar_chamados(
    data_criacao_de="2026-04-20",
    data_criacao_ate="2026-04-20",
    apenas_ativos=True,
    sem_operador=True,
    limite=500,
)
# Esperado: retorna chamados de 20/04 que ainda estão abertos E nunca foram atribuídos.
```

### Caso 2 — "Quantos de ontem foram resolvidos?"

```python
listar_chamados(
    data_criacao_de="2026-04-20",
    data_criacao_ate="2026-04-20",
    apenas_ativos=False,
    status=["Resolvido", "Finalizado"],
    limite=1000,
)
# Esperado: todos os chamados abertos em 20/04 que já foram fechados.
```

### Caso 3 — "Passivo da fila Folha nos últimos 7 dias"

```python
listar_chamados(
    data_criacao_de="2026-04-14",
    data_criacao_ate="2026-04-20",
    grupo="Suporte - Folha de Pagamento",
    apenas_ativos=True,
    limite=2000,
)
```

### Caso 4 — "O que a Jessica finalizou ontem?"

```python
listar_chamados(
    data_finalizacao_de="2026-04-20",
    data_finalizacao_ate="2026-04-20",
    operador="Jessica",
    apenas_ativos=False,
    limite=500,
)
```

### Caso 5 — Retrocompatibilidade

```python
listar_chamados_ativos_hoje(limite=50)
# Deve continuar funcionando exatamente como antes, sem nenhuma alteração de contrato.
```

---

## 4. Notas de implementação

### 4.1 Onde vai o trabalho

O endpoint do Desk Manager que hoje atende `listar_chamados_ativos_hoje` provavelmente é `POST https://api.desk.ms/ChamadosFiltros/lista` (ou variação — confirmar no wrapper atual).

**Hipótese principal:** esse mesmo endpoint já aceita filtros de data no payload. Basta generalizar a construção do body para repassar os parâmetros recebidos em vez de hardcoding `DataCriacao = hoje`.

### 4.2 Checar primeiro

Antes de codar, verificar no Desk Web (F12 → Network) quais são os nomes exatos dos filtros aceitos pelo endpoint. Exemplos prováveis:

- `Filtros[DataCriacaoDe]` / `Filtros[DataCriacaoAte]`
- `Filtros[DataAlteracaoDe]` / `Filtros[DataAlteracaoAte]`
- `Filtros[DataFinalizacaoDe]` / `Filtros[DataFinalizacaoAte]`
- `Filtros[Ativo]` (S/N)

Se o endpoint não aceitar algum dos filtros de data nativamente, implementar filtragem em memória **após** o fetch — menos eficiente, mas aceitável.

### 4.3 Paginação

A API do Desk tende a limitar retornos a ~500 por request. Implementar paginação interna transparente:

```python
def _fetch_paginado(filtros, limite_final):
    resultado = []
    pagina = 1
    while len(resultado) < limite_final:
        batch = _call_desk(filtros, pagina=pagina, por_pagina=500)
        if not batch: break
        resultado.extend(batch)
        if len(batch) < 500: break
        pagina += 1
    return resultado[:limite_final]
```

### 4.4 Campo `horas_ate_finalizacao_uteis`

Usar a mesma função que calcula `horas_uteis_aberto` hoje (que já desconta sábado/domingo), mas aplicada ao par `(DataCriacao + HoraCriacao, DataFinalizacao + HoraFinalizacao)`.

**Observação separada:** essa função ainda não desconta feriados nacionais — ver issue paralela `issue_mcp_desk_questor_feriados.md`. Até essa segunda issue ser resolvida, `horas_ate_finalizacao_uteis` terá o mesmo gap (contará feriados como dia útil). Não é bloqueante para esta entrega.

### 4.5 Enriquecimento do operador

Já funciona em `listar_chamados_ativos_hoje`. Reusar **exatamente** a mesma função de enriquecimento — não duplicar código.

### 4.6 Performance

Meta: retorno de até **2000 chamados em ≤ 15s** (rede local Questor → Desk).

Se a consulta for muito pesada, adicionar log de tempo em cada etapa (call HTTP, parsing, enriquecimento, filtragem) para facilitar tuning futuro.

---

## 5. Refactor da tool atual

`listar_chamados_ativos_hoje` continua existindo, mas vira um alias:

```python
@mcp.tool()
async def listar_chamados_ativos_hoje(params: ListarAtivosInput):
    hoje = datetime.now(ZoneInfo("America/Sao_Paulo")).date().isoformat()
    return await listar_chamados(
        ListarChamadosInput(
            data_criacao_de=hoje,
            data_criacao_ate=hoje,
            apenas_ativos=True,
            grupo=params.grupo,
            sla_expirado=params.sla_expirado,
            limite=params.limite,
            ordem=params.ordem,
        )
    )
```

Nenhum dos consumidores atuais (skills, agentes, analises) pode quebrar.

---

## 6. Critérios de aceitação (checklist)

- [ ] Nova tool `listar_chamados` registrada no MCP e aparecendo em `tool_search`.
- [ ] Todos os filtros da seção 2.2 implementados e testados.
- [ ] Validações da seção 2.4 emitindo erros claros em português.
- [ ] Schema de retorno contém os 3 campos novos (`data_finalizacao`, `hora_finalizacao`, `horas_ate_finalizacao_uteis`, `finalizado_no_mesmo_dia`).
- [ ] Os 5 casos da seção 3 executam e retornam o esperado.
- [ ] `listar_chamados_ativos_hoje` refatorada como alias, sem mudança de contrato.
- [ ] Performance: 2000 chamados em ≤ 15s.
- [ ] Paginação transparente funcionando (verificar com consulta que exceda 500 resultados).
- [ ] Documentação da tool (docstring + README do MCP) atualizada.

---

## 7. Smoke test de validação final

Após a implementação, rodar no Claude Desktop conectado ao MCP:

```
Prompt: "Quantos chamados de 20/04/2026 ficaram sem resposta?
        Me dê o número exato, divisão por fila, e os 10 mais antigos."
```

**Resposta esperada:** um único `listar_chamados` retornando a lista completa, seguido de análise. Sem amostragem, sem estimativa, sem extrapolação.

**Resposta hoje (sem a tool):** ver seção 1.

Se o smoke test passar, a entrega está aceita.

---

## 8. Fora de escopo desta issue

Itens que aparecem nas análises mas **não** devem ser tocados aqui:

- **Desconto de feriados nacionais em `horas_uteis_aberto`.** Issue separada (P1).
- **Autenticação do endpoint de histórico.** Já resolvido em iteração anterior.
- **Bugs laterais de `obter_chamado`.** Já resolvidos.
- **Métricas agregadas de produtividade por operador.** Vão ser construídas *em cima* desta tool no futuro; não fazem parte da tool em si.

---

## 9. Referências

- `investigacao_endpoint_historico_desk_v3.md` — histórico técnico do trabalho no MCP.
- `issue_mcp_desk_questor_filtro_data_feriados.md` — versão abrangente anterior (esta issue é a parte 1 dela, isolada e detalhada).
- Conversa técnica completa com exemplos reais de amostragem: sessão Claude de 20-21/04/2026 com Fabio Puhl.
