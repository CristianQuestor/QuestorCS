# Melhorias Técnicas — MCP `desk-questor` (v2)

**Autor:** Fabio Puhl — Diretoria de Tecnologia
**Data:** 20/04/2026 (revisão após atualização do MCP)
**Versão anterior:** `melhorias_mcp_desk_questor.md` (mesma data, manhã)
**Repositório:** integração MCP `desk-questor` (servidor local + API Desk Manager em `api.desk.ms`)

---

## 1. O que mudou desde a v1

Após a primeira rodada de análise, o time atualizou o wrapper MCP. A mudança trouxe evolução real de **diagnóstico**, mas a causa raiz da lacuna #1 se deslocou:

| Aspecto | v1 (manhã) | v2 (atualizado) |
|---|---|---|
| Endpoints testados para histórico | 3 (`Acoes`, `ChamadosHistorico`, `HistoricoChamado`) | **8 variações** (incluindo `ChamadoHistoricos`, `Historico`, variações de filtro `ChaveChamado` vs `Chave`) |
| Mensagem de erro | Genérica | Detalhada: lista todos endpoints tentados + último HTTP error + trecho da resposta |
| Resultado efetivo | Histórico não retorna | Histórico **ainda** não retorna — agora com **HTTP 404** confirmado em `https://api.desk.ms/ChamadosHistoricos/lista` |
| Diagnóstico possível | "Algo falhou" | "Nenhuma das rotas de histórico existe neste tenant do Desk Manager" |

**Conclusão principal:** a lacuna #1 **não é mais do wrapper MCP**. O wrapper está fazendo o correto — o endpoint de histórico simplesmente não existe nos caminhos testados da API pública do Desk Manager neste tenant.

---

## 2. Observação operacional (memória de contexto)

A equipe de Suporte Questor opera **apenas de segunda a sexta-feira**. Qualquer análise derivada do MCP que envolva horas abertas, SLA ou backlog deve descontar fim de semana. Isso afeta diretamente:

- Campos `horas_aberto` e `horas_sem_resposta` no retorno de `listar_chamados_ativos_hoje` — são relógio corrido, não horário comercial.
- Interpretação de SLA expirado — o Desk provavelmente já respeita calendário comercial internamente, mas qualquer cálculo agregado feito em cima do MCP precisa replicar essa regra.

**Sugestão de melhoria transversal:** adicionar ao retorno dos chamados um campo `horas_uteis_aberto` (já descontando sábado/domingo e, idealmente, horário comercial) calculado no wrapper.

---

## 3. Lacunas atualizadas

### Lacuna #1 — Endpoint de histórico inexistente no Desk Manager (reclassificada)

**Status:** wrapper OK, problema é no fornecedor da plataforma.

**Evidência:**

Em 20/04/2026, `listar_historico_chamado` testado em chaves `1624098` e `1624241`. Retorno idêntico em ambos:

```
Nenhum endpoint de histórico respondeu para este tenant
(tentado: ChamadoHistoricos(Filtros[ChaveChamado]),
          ChamadosHistoricos(Filtros[ChaveChamado]),
          ChamadosHistorico(Filtros[ChaveChamado]),
          HistoricoChamado(Filtros[ChaveChamado]),
          Historico(Filtros[ChaveChamado]),
          Acoes(Filtros[ChaveChamado]),
          ChamadoHistoricos(Filtros[Chave]),
          ChamadosHistoricos(Filtros[Chave]))
Último erro: HTTP 404 em https://api.desk.ms/ChamadosHistoricos/lista
```

**Caminhos de investigação (por ordem de custo):**

1. **Inspeção de rede no Desk Web** (menor esforço, maior chance): abrir um chamado na interface web, F12 → Network, ver qual URL o frontend chama ao carregar o histórico/interações. O nome do endpoint real aparece ali.
2. **Consulta à documentação oficial da API Desk Manager**: verificar se `api.desk.ms` expõe histórico de fato. É possível que o recurso exista só na camada interna e não seja público.
3. **Contato com o fornecedor** (Milvus / Move Desk / responsável pelo `desk.ms`): perguntar explicitamente qual é a rota REST de histórico de ações e qual permissão é necessária no token.
4. **Fallback se não houver endpoint**: avaliar integração por outro meio — webhook de ações, exportação periódica ou consulta ao banco se o ambiente permitir.

**Critério de aceitação (quando destravar):**

- [ ] `listar_historico_chamado(chave=X)` retorna `{total, acoes}` com `sequencia, data_hora, operador, tipo, publico, texto, anexos`.
- [ ] Distingue claramente ação pública (resposta ao cliente) de comentário interno e de mudança de status.
- [ ] `obter_chamado(chave=X, incluir_historico=true)` embute o mesmo payload.

---

### Lacuna #2 — Listagem limitada a chamados criados hoje (sem mudança)

**Status:** sem evolução. Pendente.

A tool `listar_chamados_ativos_hoje` continua filtrando por `DataCriacao = hoje`. Isso torna invisível todo o passivo de dias anteriores — problema citado em detalhe na v1.

**Número concreto que ilustra o impacto** (coleta de 20/04 13:17 BRT):
- 178 operadores cadastrados ativos no Desk.
- 44 com chamado em andamento **criado hoje**.
- 134 operadores sem chamado visível na query — provavelmente tratando passivo antigo, invisível para o MCP.

**Proposta (mantida):** nova tool `listar_chamados_ativos(...)` com filtros de `data_criacao_de`, `data_criacao_ate`, `data_alteracao_de`, `operador`, `grupo`, `status`, `sla_expirado`, preservando `listar_chamados_ativos_hoje` como alias.

**Prioridade:** **P0** — agora é a lacuna com maior impacto analítico imediato, porque (ao contrário da #1) não depende do fornecedor externo.

**Critério de aceitação:**

- [ ] Nova tool aceita os filtros listados.
- [ ] Retorno tem o mesmo schema enriquecido da tool atual (`cliente_nome_completo`, `urgencia`, `horas_aberto`, etc.).
- [ ] Retorno inclui `horas_uteis_aberto` (descontando fim de semana — ver seção 2).
- [ ] Consulta de até 1000 chamados responde em tempo útil.
- [ ] `listar_chamados_ativos_hoje` continua funcionando sem alteração de contrato.

---

### Lacuna #3 — Presença do operador não exposta no chamado (sem mudança)

**Status:** sem evolução. Pendente.

`listar_operadores` devolve `OnOff` ("S"/"N") mas `listar_chamados_ativos_hoje` e `obter_chamado` não cruzam esse dado. Toda análise precisa refazer o join.

**Evidência reforçada:** dos 100 chamados "em andamento" coletados hoje, ao menos **15 tinham operador offline** — incluindo casos de mais de 5 horas sem resposta. Nenhum sinal automático é emitido hoje.

**Proposta (mantida):** enriquecer retorno com `operador_online`, `operador_grupo_principal`, `operador_chave`. Cache in-process de 60s sobre `listar_operadores`.

**Prioridade:** **P1** — é correção barata (o dado já existe), destrava alerta automático de "chamado atribuído a operador fora do ar".

---

## 4. Priorização revisada

| Prioridade | Lacuna | Dono da ação | Justificativa |
|---|---|---|---|
| **P0** | #2 — Filtro de data nos ativos | Time MCP (interno) | Maior impacto analítico; independe de fornecedor externo; destrava dimensionamento e passivo |
| **P1** | #3 — Presença do operador | Time MCP (interno) | Custo baixo, ganho de alerta imediato, reusa dado existente |
| **P1** | #2b — Novo campo `horas_uteis_aberto` | Time MCP (interno) | Pode sair junto com a #2, reflete calendário comercial (seg–sex) |
| **P2 / bloqueado** | #1 — Histórico de ações | Depende de inspeção de rede do Desk Web e/ou fornecedor externo | Até descobrir a rota real, nenhuma codificação do wrapper resolve |

---

## 5. Validação pós-entrega (roteiro)

```text
1. listar_chamados_ativos_hoje(limite=5)
   → funciona como antes (compat.)

2. listar_chamados_ativos(
       data_criacao_de="2026-04-01",
       data_criacao_ate="2026-04-15",
       status=["Andamento","Aguardando Atendimento"])
   → retorna chamados do período

3. Qualquer retorno de chamado
   → contém operador_online, operador_chave, operador_grupo_principal
   → contém horas_uteis_aberto

4. listar_historico_chamado(chave=<qualquer>)
   → quando lacuna #1 for destravada: retorna {total, acoes[]} válido
   → até lá: erro verboso atual já é aceitável para debug
```

---

## 6. Histórico de evolução do documento

| Data/hora | Versão | O que mudou |
|---|---|---|
| 20/04/2026 manhã | v1 | Primeira análise; 3 lacunas; #1 classificada como "endpoint quebrado no wrapper" |
| 20/04/2026 tarde | **v2 (este doc)** | MCP atualizado com 8 endpoints + diagnóstico verboso; #1 reclassificada como bloqueio externo; #2 passa a ser P0; adicionada observação de calendário seg–sex |

---

## 7. Próximos passos sugeridos

1. **Abrir issue no Redmine** do projeto MCP apontando este documento (foco em P0 #2 e P1 #3).
2. **Task paralela de investigação** da rota de histórico: alguém do time faz inspeção do Desk Web e/ou contato com fornecedor; resultado alimenta lacuna #1.
3. **Validar regras de calendário** (seg–sex + horário comercial) com Joana Pompermaier antes de codar `horas_uteis_aberto`, para evitar retrabalho.
