# desk-questor-mcp

MCP Server que expõe as operações do Desk Manager (desk.ms) da Questor para agents Claude.
Permite monitorar e apoiar atendimentos em tempo real com contexto completo, integrando-se
ao loop de N3 junto com Redmine, Metabase e outros MCPs Questor.

## Stack

- Python 3.10+
- [FastMCP](https://modelcontextprotocol.io) (pacote `mcp`)
- `httpx` (HTTP async)
- `pydantic` (validação)
- `python-dotenv` (configuração)

## Instalação

```powershell
cd D:\WorkSpace\desk-questor-mcp
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
# Preencha as credenciais no .env
```

### Credenciais (.env)

| Variável | Descrição |
|---|---|
| `DESK_AUTH_HEADER` | Header `Authorization` usado APENAS em `/Login/autenticar` |
| `DESK_PUBLIC_KEY`  | Enviado no body do login (`PublicKey=...`) |
| `DESK_BACKREQTOKEN`| Credencial DIFERENTE usada em `api.desk.ms/*` |
| `DESK_LOGIN_URL`   | Default: `https://questor.desk.ms/Login/autenticar` |
| `DESK_API_URL`     | Default: `https://api.desk.ms` |
| `DESK_QUESTOR_FERIADOS_EXTRAS` | Opcional. Lista `YYYY-MM-DD,YYYY-MM-DD` de feriados municipais/estaduais extras (além dos nacionais). Default vazio |

Valores nominais podem ser copiados do n8n:
- Cred `8dQInvpOE6nTU2zf` — "Header Auth account desk full direito" → `DESK_AUTH_HEADER`
- Cred `16` — "Header Auth account Desk MS BackReqToken" → `DESK_BACKREQTOKEN`

## Registro no Claude Desktop

Edite `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "desk-questor": {
      "command": "python",
      "args": ["-m", "src.server"],
      "cwd": "D:\\WorkSpace\\desk-questor-mcp",
      "env": {
        "PYTHONPATH": "D:\\WorkSpace\\desk-questor-mcp"
      }
    }
  }
}
```

As demais variáveis são lidas do `.env` automaticamente.

## Tools expostas

| Tool | Descrição |
|---|---|
| `listar_chamados` | **[análise principal]** Tool mais ampla — filtros de `data_criacao`, `data_alteracao`, `data_finalizacao`, `grupo`, `operador` (parcial), `operador_chave` (exato), `status[]`, `sla_expirado`, `sem_operador`, `apenas_ativos` (default true). Janela máx 90d. Paginação interna até 2000. Campos finalização: `data_finalizacao`, `hora_finalizacao`, `horas_ate_finalizacao_uteis`, `finalizado_no_mesmo_dia` |
| `listar_chamados_ativos_hoje` | Alias de `listar_chamados` com `data_criacao=hoje` |
| `listar_chamados_ativos` | Alias de `listar_chamados` mantido por compatibilidade |
| `obter_chamado` | Detalhe completo de um chamado + histórico |
| `listar_historico_chamado` | Todas as interações/ações cronológicas |
| `buscar_chamados_similares` | Busca por `Assunto` em chamados já resolvidos |
| `comentar_chamado` | Posta comentário (default interno) |
| `atualizar_status_chamado` | Muda status, opcionalmente com comentário |
| `listar_grupos` | Grupos/filas de atendimento |
| `listar_operadores` | Operadores (default: apenas ativos) |
| `dashboard_n3` | Agregados: total ativos, por grupo, SLA expirando, sem atribuição, top sem resposta |
| `cache_stats` | Diagnóstico do cache SQLite (contagens, TTL, path) |

### Campos retornados por chamado enriquecido

| Campo | Tipo | Descrição |
|---|---|---|
| `chave` | int | Chave única (`Chave` na API) |
| `codigo` | str | `CodChamado` |
| `assunto`, `status`, `grupo` | str | |
| `cliente_nome_completo` | str | `NomeUsuario + SobrenomeUsuario` |
| `operador` | str | `NomeOperador` (null se não atribuído) |
| `data_criacao`, `hora_criacao` | str | Originais da API |
| `ativo` | bool | False se `DataFinalizacao != "0000-00-00"` |
| `data_finalizacao`, `hora_finalizacao` | str | Populados quando `ativo=false` |
| `horas_aberto` | float | Horas corridas desde criação (BRT) |
| `horas_uteis_aberto` | float | Desconta sáb/dom **e feriados nacionais BR** (+ extras via env) |
| `horas_ate_finalizacao_uteis` | float | Horas úteis entre criação e finalização (só finalizados) |
| `finalizado_no_mesmo_dia` | bool | `True` se criado e fechado no mesmo dia (KPI) |
| `horas_sem_resposta` | float | Horas corridas desde `DataAlteracao` |
| `sla1_expirado`, `sla2_expirado` | bool | Parse de `"S"/"N"` |
| `tempo_restante_sla1`, `sla2` | str | `HH:MM:SS` (pode ser negativo) |
| `urgencia` | str | `alto` / `medio` / `baixo` |

### Regra de urgência

- **alto**: qualquer SLA expirado · SLA1 restante ≤ 30 min · > 24h sem resposta
- **medio**: SLA1 restante ≤ 2h · > 8h sem resposta
- **baixo**: demais

## Exemplos de prompts

- "Liste os chamados ativos de hoje do grupo Suporte - Web ordenados por urgência."
- "Quantos chamados de 20/04/2026 ficaram sem primeira resposta?"  *(usa `listar_chamados_ativos` com `data_criacao_de/ate=2026-04-20` + `sem_operador=true`)*
- "Passivo dos últimos 7 dias da fila Folha de Pagamento."  *(janela `data_criacao_de/ate`)*
- "Backlog do operador Jessica hoje."  *(`operador="Jessica"`, `apenas_ativos=true`)*
- "Mostre o detalhe do chamado 1623378 com histórico."
- "Busque chamados resolvidos parecidos com: 'erro ao importar XML de NFS-e'."
- "Monte o dashboard N3 para agora."
- "Comente internamente no chamado 1623378: 'Verificar se é o bug #12345 do Redmine'."

## Execução

```powershell
python -m src.server
# ou
.\scripts\start.ps1
```

## Testes

```powershell
pip install -e ".[dev]"
pytest
```

## Regras operacionais (implementadas)

- **Cache SQLite persistente** de chamados e históricos em `cache/desk.sqlite`
  (Fase 2, v0.5.0). Finalizados com TTL longo (30 dias); ativos com TTL curto
  (5 min) e invalidação por `DataAlteracao`. Cache hit <1ms vs ~25s de API.
  Parâmetro `ignorar_cache=true` força refresh. Ver `DESK_CACHE_*` no `.env`.
- **Cache de token** em memória, renovação 30s antes do TTL (`DESK_TOKEN_TTL`).
- **Cache de operadores** em memória (TTL `DESK_OPERADORES_CACHE_TTL`).
- **Retry** exponencial em 5xx/timeout (3 tentativas, backoff até 10s).
- **Auth retry** em 401/403: invalida token e refaz 1 vez.
- **Rate limit** de `DESK_RATE_LIMIT_MS` entre chamadas (default 200ms).
- **Timeout** 600s para `/lista`, 30s para chamadas pontuais.
- **BRT** (`America/Sao_Paulo`, UTC-03:00) em todos os cálculos de tempo.
- **Logs estruturados**; token nunca aparece em mensagens de erro.

## Referências

- Workflow n8n (chamador): `https://n8n.questor.com.br/workflow/0WeyIO5BkLThSC7m`
- Workflow n8n (executor): `https://n8n.questor.com.br/workflow/jiAHz6rY13e91RbU`
- Fallback datalake: tabelas `desk_chamadossuporte_dados`, `desk_chamadohistoricos_dados`
  (ver skill `datalake-metabase`)
