"""Enriquecimento de chamados: cálculo de tempo decorrido e urgência em BRT."""

from __future__ import annotations

import logging
import os
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
from typing import Any

import holidays

from .models import ChamadoEnriquecido, ChamadoRaw

logger = logging.getLogger("desk-questor-mcp.enrichment")

# America/Sao_Paulo = UTC-03:00 (sem horário de verão desde 2019).
BRT = timezone(timedelta(hours=-3))

_DATA_ZERADA = {"0000-00-00", "", None}

_FERIADOS_RANGE = range(2020, 2036)


@lru_cache(maxsize=1)
def _feriados_br() -> set[date]:
    """Feriados nacionais brasileiros + datas extras configuradas via env.

    `DESK_QUESTOR_FERIADOS_EXTRAS` aceita lista separada por vírgula de datas
    `YYYY-MM-DD` (ex.: feriados municipais de Chapecó/SC).
    """
    base = set(holidays.country_holidays("BR", years=_FERIADOS_RANGE).keys())
    extras = os.environ.get("DESK_QUESTOR_FERIADOS_EXTRAS", "")
    for item in extras.split(","):
        s = item.strip()
        if not s:
            continue
        try:
            base.add(date.fromisoformat(s))
        except ValueError:
            logger.warning(
                "DESK_QUESTOR_FERIADOS_EXTRAS ignorando entrada inválida: %r", s
            )
    return base


def _eh_dia_util(dt: datetime) -> bool:
    """Seg–sex, excluindo feriados nacionais BR e extras configurados."""
    if dt.weekday() >= 5:
        return False
    if dt.date() in _feriados_br():
        return False
    return True


def _agora_brt() -> datetime:
    return datetime.now(BRT)


def _parse_desk_datetime(data: str | None, hora: str | None) -> datetime | None:
    """Combina DataCriacao (YYYY-MM-DD) + HoraCriacao (HH:MM:SS) em datetime BRT.

    Retorna None se a data estiver zerada ou malformada.
    """
    if data in _DATA_ZERADA:
        return None
    try:
        partes_data = data.split("-")  # type: ignore[union-attr]
        if len(partes_data) != 3:
            return None
        ano, mes, dia = (int(x) for x in partes_data)
        if ano < 1900 or mes == 0 or dia == 0:
            return None

        hh = mm = ss = 0
        if hora and hora.strip():
            partes = hora.split(":")
            hh = int(partes[0]) if len(partes) > 0 else 0
            mm = int(partes[1]) if len(partes) > 1 else 0
            ss = int(partes[2]) if len(partes) > 2 else 0
        return datetime(ano, mes, dia, hh, mm, ss, tzinfo=BRT)
    except (ValueError, AttributeError):
        return None


def _horas_entre(dt_inicio: datetime | None, dt_fim: datetime | None) -> float | None:
    if dt_inicio is None or dt_fim is None:
        return None
    delta = dt_fim - dt_inicio
    return round(delta.total_seconds() / 3600, 2)


def _horas_uteis_entre(
    dt_inicio: datetime | None, dt_fim: datetime | None
) -> float | None:
    """Horas corridas descontando sábado, domingo e feriados nacionais BR.

    Feriados municipais podem ser adicionados via `DESK_QUESTOR_FERIADOS_EXTRAS`.
    Não aplicamos horário comercial — período de 24h em dia útil conta integral.
    """
    if dt_inicio is None or dt_fim is None:
        return None
    if dt_fim <= dt_inicio:
        return 0.0

    total = timedelta(0)
    cursor = dt_inicio
    # Avança dia-a-dia, somando só segmentos em dias úteis.
    while cursor.date() < dt_fim.date():
        proximo_dia = datetime.combine(
            cursor.date() + timedelta(days=1), datetime.min.time(), tzinfo=cursor.tzinfo
        )
        if _eh_dia_util(cursor):
            total += proximo_dia - cursor
        cursor = proximo_dia
    if _eh_dia_util(cursor):
        total += dt_fim - cursor
    return round(total.total_seconds() / 3600, 2)


def _parse_sn(valor: str | None) -> bool | None:
    if valor is None:
        return None
    v = valor.strip().upper()
    if v == "S":
        return True
    if v == "N":
        return False
    return None


def _parse_tempo_restante(valor: str | None) -> timedelta | None:
    """Converte 'HH:MM:SS' em timedelta. Pode ser negativo (ex.: '-01:30:00')."""
    if not valor:
        return None
    s = valor.strip()
    if not s or s == "00:00:00":
        return timedelta(0)
    sinal = 1
    if s.startswith("-"):
        sinal = -1
        s = s[1:]
    try:
        partes = s.split(":")
        hh = int(partes[0]) if len(partes) > 0 else 0
        mm = int(partes[1]) if len(partes) > 1 else 0
        ss = int(partes[2]) if len(partes) > 2 else 0
        return sinal * timedelta(hours=hh, minutes=mm, seconds=ss)
    except ValueError:
        return None


def calcular_urgencia(
    *,
    sla1_expirado: bool | None,
    sla2_expirado: bool | None,
    horas_sem_resposta: float | None,
    tempo_restante_sla1: timedelta | None,
) -> str:
    """Heurística simples — alto > medio > baixo.

    - alto: qualquer SLA expirado, OU SLA1 restante <= 30 min,
            OU > 24h sem resposta.
    - medio: SLA1 restante <= 2h, OU > 8h sem resposta.
    - baixo: demais casos.
    """
    if sla1_expirado or sla2_expirado:
        return "alto"
    if tempo_restante_sla1 is not None and tempo_restante_sla1 <= timedelta(minutes=30):
        return "alto"
    if horas_sem_resposta is not None and horas_sem_resposta > 24:
        return "alto"
    if tempo_restante_sla1 is not None and tempo_restante_sla1 <= timedelta(hours=2):
        return "medio"
    if horas_sem_resposta is not None and horas_sem_resposta > 8:
        return "medio"
    return "baixo"


def enriquecer_chamado(raw: dict[str, Any]) -> ChamadoEnriquecido:
    """Converte dict bruto da API Desk em ChamadoEnriquecido."""
    c = ChamadoRaw(**raw)

    dt_criacao = _parse_desk_datetime(c.DataCriacao, c.HoraCriacao)
    dt_alteracao = _parse_desk_datetime(c.DataAlteracao, c.HoraAlteracao)
    dt_finalizacao = _parse_desk_datetime(c.DataFinalizacao, c.HoraFinalizacao)

    agora = _agora_brt()
    horas_aberto = _horas_entre(dt_criacao, dt_finalizacao or agora)
    horas_uteis_aberto = _horas_uteis_entre(dt_criacao, dt_finalizacao or agora)
    horas_sem_resposta = _horas_entre(dt_alteracao, agora)

    # Campos específicos de finalização (Fase 3 — listar_chamados retroativo).
    horas_ate_finalizacao_uteis: float | None = None
    finalizado_no_mesmo_dia: bool | None = None
    if dt_finalizacao is not None:
        horas_ate_finalizacao_uteis = _horas_uteis_entre(dt_criacao, dt_finalizacao)
        if dt_criacao is not None:
            finalizado_no_mesmo_dia = dt_criacao.date() == dt_finalizacao.date()

    sla1 = _parse_sn(c.Sla1Expirado)
    sla2 = _parse_sn(c.Sla2Expirado)
    resta_sla1 = _parse_tempo_restante(c.TempoRestantePrimeiroAtendimento)

    cliente = " ".join(
        parte for parte in (c.NomeUsuario, c.SobrenomeUsuario) if parte and parte.strip()
    ).strip() or None

    urgencia = calcular_urgencia(
        sla1_expirado=sla1,
        sla2_expirado=sla2,
        horas_sem_resposta=horas_sem_resposta,
        tempo_restante_sla1=resta_sla1,
    )

    return ChamadoEnriquecido(
        chave=c.Chave,
        codigo=c.CodChamado,
        assunto=c.Assunto,
        status=c.NomeStatus,
        grupo=c.NomeGrupo,
        cliente_nome_completo=cliente,
        operador=c.NomeOperador,
        operador_chave=c.ChaveOperador,
        data_criacao=c.DataCriacao,
        hora_criacao=c.HoraCriacao,
        data_alteracao=c.DataAlteracao,
        hora_alteracao=c.HoraAlteracao,
        data_finalizacao=c.DataFinalizacao if dt_finalizacao else None,
        hora_finalizacao=c.HoraFinalizacao if dt_finalizacao else None,
        ativo=dt_finalizacao is None,
        horas_aberto=horas_aberto,
        horas_uteis_aberto=horas_uteis_aberto,
        horas_sem_resposta=horas_sem_resposta,
        horas_ate_finalizacao_uteis=horas_ate_finalizacao_uteis,
        finalizado_no_mesmo_dia=finalizado_no_mesmo_dia,
        qt_acoes=c.QtAcoes,
        total_anexos=c.TotalAnexos,
        sla1_expirado=sla1,
        sla2_expirado=sla2,
        tempo_restante_sla1=c.TempoRestantePrimeiroAtendimento,
        tempo_restante_sla2=c.TempoRestanteSegundoAtendimento,
        urgencia=urgencia,
        raw=raw,
    )


def ordenar_chamados(
    chamados: list[ChamadoEnriquecido], ordem: str
) -> list[ChamadoEnriquecido]:
    """Ordena por chave conhecida. Default: tempo_aberto_desc."""
    key_funcs = {
        "tempo_aberto_desc": lambda c: -(c.horas_aberto or 0),
        "tempo_aberto_asc": lambda c: (c.horas_aberto or 0),
        "sem_resposta_desc": lambda c: -(c.horas_sem_resposta or 0),
        "urgencia": lambda c: {"alto": 0, "medio": 1, "baixo": 2}.get(c.urgencia, 3),
        "data_criacao_desc": lambda c: (c.data_criacao or "", c.hora_criacao or ""),
        "data_finalizacao_desc": lambda c: (c.data_finalizacao or "", c.hora_finalizacao or ""),
    }
    func = key_funcs.get(ordem, key_funcs["tempo_aberto_desc"])
    if ordem in ("data_criacao_desc", "data_finalizacao_desc"):
        return sorted(chamados, key=func, reverse=True)  # type: ignore[arg-type]
    return sorted(chamados, key=func)
