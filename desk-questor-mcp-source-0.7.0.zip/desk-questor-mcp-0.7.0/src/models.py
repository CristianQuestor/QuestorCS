"""Modelos Pydantic para dados do Desk Manager.

São intencionalmente permissivos (extra="allow") porque a API devolve muitos
campos e os payloads variam por tenant/configuração. Os campos declarados
são os que o MCP usa — o resto fica acessível via .model_extra.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ChamadoRaw(BaseModel):
    """Chamado como vem da API (campos principais; demais preservados)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    Chave: int | None = None
    CodChamado: str | None = None
    Assunto: str | None = None
    Descricao: str | None = None

    DataCriacao: str | None = None
    HoraCriacao: str | None = None
    DataAlteracao: str | None = None
    HoraAlteracao: str | None = None
    DataFinalizacao: str | None = None
    HoraFinalizacao: str | None = None

    NomeStatus: str | None = None
    ChaveStatus: int | None = None

    ChaveUsuario: int | None = None
    NomeUsuario: str | None = None
    SobrenomeUsuario: str | None = None

    ChaveOperador: int | None = None
    NomeOperador: str | None = None

    SequenciaGrupo: str | None = None
    NomeGrupo: str | None = None

    QtAcoes: int | None = None
    TotalAnexos: int | None = None

    TempoRestantePrimeiroAtendimento: str | None = None
    TempoRestanteSegundoAtendimento: str | None = None
    Sla1Expirado: str | None = None
    Sla2Expirado: str | None = None


class ChamadoEnriquecido(BaseModel):
    """Chamado + campos calculados pelo módulo de enrichment."""

    model_config = ConfigDict(extra="allow")

    chave: int | None = None
    codigo: str | None = None
    assunto: str | None = None
    status: str | None = None
    grupo: str | None = None

    cliente_nome_completo: str | None = None
    operador: str | None = None
    operador_chave: int | None = None
    operador_online: bool | None = None
    operador_grupo_principal: str | None = None

    data_criacao: str | None = None
    hora_criacao: str | None = None
    data_alteracao: str | None = None
    hora_alteracao: str | None = None
    data_finalizacao: str | None = None
    hora_finalizacao: str | None = None

    ativo: bool = True
    horas_aberto: float | None = None
    horas_uteis_aberto: float | None = None
    horas_sem_resposta: float | None = None
    horas_ate_finalizacao_uteis: float | None = None
    finalizado_no_mesmo_dia: bool | None = None

    qt_acoes: int | None = None
    total_anexos: int | None = None

    sla1_expirado: bool | None = None
    sla2_expirado: bool | None = None
    tempo_restante_sla1: str | None = None
    tempo_restante_sla2: str | None = None

    urgencia: str = "baixo"  # alto | medio | baixo

    raw: dict[str, Any] = Field(default_factory=dict)


class HistoricoItem(BaseModel):
    model_config = ConfigDict(extra="allow")

    Chave: int | None = None
    ChaveChamado: int | None = None
    Data: str | None = None
    Hora: str | None = None
    Tipo: str | None = None
    Descricao: str | None = None
    NomeOperador: str | None = None
    NomeUsuario: str | None = None
    Publico: str | None = None


class DashboardN3(BaseModel):
    model_config = ConfigDict(extra="allow")

    total_ativos: int
    por_grupo: dict[str, int]
    sla1_expirando_2h: int
    sem_atribuicao: int
    top_sem_resposta: list[ChamadoEnriquecido]
    gerado_em: str
