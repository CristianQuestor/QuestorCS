"""Cache em memória da tabela de operadores do Desk.

Usado para enriquecer chamados com presença (OnOff), chave e grupo principal
do operador atribuído. TTL configurável (default 60s) conforme especificado
no documento de melhorias.

Chaves de lookup:
- por nome (case-insensitive, espaços normalizados)
- por `ChaveOperador` numérico

O cache é carregado lazy — primeira chamada aciona o fetch; chamadas
concorrentes compartilham a mesma coroutine (lock) para evitar thundering
herd contra a API Desk.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from .desk_client import DeskClient

logger = logging.getLogger("desk-questor-mcp.operadores_cache")


def _normalizar_nome(nome: str | None) -> str:
    if not nome:
        return ""
    return " ".join(nome.split()).strip().lower()


class OperadoresCache:
    """Cache de operadores com refresh em background.

    Uso:
        cache = OperadoresCache(client, ttl_segundos=60)
        info = await cache.info_por_nome("Agata Barreto")
        # {"chave": 615, "online": False, "grupo_principal": "...", "nome": "..."}
    """

    def __init__(self, client: DeskClient, *, ttl_segundos: int = 60):
        self._client = client
        self._ttl = ttl_segundos
        self._por_nome: dict[str, dict[str, Any]] = {}
        self._por_chave: dict[int, dict[str, Any]] = {}
        self._atualizado_em: float = 0.0
        self._lock = asyncio.Lock()

    async def _refresh(self) -> None:
        body = {"Tatual": 0, "Quantidade": 3000}
        try:
            resposta = await self._client.listar("Operadores", body)
        except Exception as e:
            logger.warning("Falha ao atualizar cache de operadores: %s", e)
            return
        registros = resposta.get("root") or []

        por_nome: dict[str, dict[str, Any]] = {}
        por_chave: dict[int, dict[str, Any]] = {}
        for op in registros:
            nome_raw = op.get("NomeOperador") or op.get("Nome") or ""
            nome_norm = _normalizar_nome(nome_raw)
            onoff = str(op.get("OnOff", "")).strip().upper()
            chave_raw = op.get("ChaveOperador") or op.get("Chave")
            try:
                chave = int(chave_raw) if chave_raw is not None else None
            except (TypeError, ValueError):
                chave = None
            grupo_principal = (
                op.get("NomeGrupoPrincipal")
                or op.get("NomeGrupo")
                or op.get("GrupoPrincipal")
                or None
            )
            ativo = str(op.get("Ativo", "S")).strip().upper() == "S"

            info = {
                "nome": nome_raw or None,
                "chave": chave,
                "online": True if onoff == "S" else (False if onoff == "N" else None),
                "grupo_principal": grupo_principal,
                "ativo": ativo,
            }
            if nome_norm:
                por_nome[nome_norm] = info
            if chave is not None:
                por_chave[chave] = info

        self._por_nome = por_nome
        self._por_chave = por_chave
        self._atualizado_em = time.monotonic()
        logger.debug(
            "Cache de operadores atualizado: %d entradas", len(por_nome)
        )

    async def _ensure_fresh(self) -> None:
        if self._atualizado_em and (time.monotonic() - self._atualizado_em) < self._ttl:
            return
        async with self._lock:
            if self._atualizado_em and (time.monotonic() - self._atualizado_em) < self._ttl:
                return
            await self._refresh()

    async def info_por_nome(self, nome: str | None) -> dict[str, Any] | None:
        if not nome:
            return None
        await self._ensure_fresh()
        return self._por_nome.get(_normalizar_nome(nome))

    async def info_por_chave(self, chave: int | None) -> dict[str, Any] | None:
        if chave is None:
            return None
        await self._ensure_fresh()
        try:
            return self._por_chave.get(int(chave))
        except (TypeError, ValueError):
            return None

    async def resolver(
        self, *, nome: str | None = None, chave: int | None = None
    ) -> dict[str, Any] | None:
        """Tenta por chave primeiro (mais confiável), cai para nome."""
        info = await self.info_por_chave(chave)
        if info is not None:
            return info
        return await self.info_por_nome(nome)

    async def snapshot(self) -> list[dict[str, Any]]:
        """Retorna cópia da tabela de operadores (usado em tools de catálogo)."""
        await self._ensure_fresh()
        vistos: set[int] = set()
        resultado: list[dict[str, Any]] = []
        for info in self._por_nome.values():
            chave = info.get("chave")
            if isinstance(chave, int):
                if chave in vistos:
                    continue
                vistos.add(chave)
            resultado.append(dict(info))
        return resultado
