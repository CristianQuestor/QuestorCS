"""Cache SQLite persistente para chamados e históricos do Desk Manager.

Estratégia de invalidação (guiada pela `DataAlteracao` da API):

- **Chamado finalizado** (`DataFinalizacao != "0000-00-00"`): cache efetivamente
  eterno (TTL em dias configurável; padrão 30). Dado imutável após fechamento.
- **Chamado ativo**: cache curto (TTL em segundos; padrão 300). Se a
  `DataAlteracao` do registro mudar (detectado na próxima listagem), o cache é
  invalidado imediatamente, independente do TTL.
- **Histórico**: atrelado à `DataAlteracao` do chamado. Se ela mudou, o histórico
  mudou — invalida. Finalizados também seguem TTL longo.

Acesso assíncrono via `asyncio.to_thread` — SQLite em modo `check_same_thread=False`
com WAL para permitir leituras concorrentes.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger("desk-questor-mcp.cache")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS chamados (
    chave INTEGER PRIMARY KEY,
    data_alteracao TEXT,
    hora_alteracao TEXT,
    finalizado INTEGER NOT NULL DEFAULT 0,
    payload_json TEXT NOT NULL,
    fetched_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS historicos (
    chave INTEGER PRIMARY KEY,
    data_alteracao_chamado TEXT,
    hora_alteracao_chamado TEXT,
    finalizado INTEGER NOT NULL DEFAULT 0,
    payload_json TEXT NOT NULL,
    fetched_at REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chamados_fetched ON chamados(fetched_at);
CREATE INDEX IF NOT EXISTS idx_historicos_fetched ON historicos(fetched_at);
"""


class DeskCache:
    """Cache SQLite persistente, thread-safe, async-friendly.

    Instância única por processo — a mesma conexão é reutilizada. SQLite garante
    serialização interna de writes; reads são concorrentes graças ao WAL.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        ttl_ativo_segundos: int = 300,
        ttl_finalizado_dias: int = 30,
        enabled: bool = True,
    ):
        self.enabled = enabled
        self.ttl_ativo = max(0, int(ttl_ativo_segundos))
        self.ttl_finalizado = max(0, int(ttl_finalizado_dias)) * 86400
        self._path = Path(path)
        self._lock = asyncio.Lock()
        self._conn: sqlite3.Connection | None = None
        if self.enabled:
            self._init_db()

    @classmethod
    def from_env(cls, *, default_path: Path | None = None) -> "DeskCache":
        enabled = os.environ.get("DESK_CACHE_ENABLED", "true").strip().lower() not in (
            "0", "false", "no", "off"
        )
        path_env = os.environ.get("DESK_CACHE_PATH")
        if path_env:
            path = Path(path_env)
        else:
            base = default_path or Path(__file__).resolve().parent.parent / "cache"
            path = base / "desk.sqlite"
        ttl_ativo = int(os.environ.get("DESK_CACHE_TTL_ATIVO_SEGUNDOS", "300"))
        ttl_final = int(os.environ.get("DESK_CACHE_TTL_FINALIZADO_DIAS", "30"))
        return cls(
            path,
            ttl_ativo_segundos=ttl_ativo,
            ttl_finalizado_dias=ttl_final,
            enabled=enabled,
        )

    def _init_db(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(self._path), check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(_SCHEMA)
        logger.info("Cache SQLite em %s (ativo=%ss, finalizado=%sd)",
                    self._path, self.ttl_ativo, self.ttl_finalizado // 86400)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # -------------------------------------------------------------------------
    # Helpers de validade
    # -------------------------------------------------------------------------

    def _ttl_expirado(self, fetched_at: float, finalizado: bool) -> bool:
        ttl = self.ttl_finalizado if finalizado else self.ttl_ativo
        if ttl <= 0:
            return True
        return (time.time() - fetched_at) > ttl

    def _foi_alterado(
        self,
        cache_data: str | None,
        cache_hora: str | None,
        atual_data: str | None,
        atual_hora: str | None,
    ) -> bool:
        """True se o chamado mudou depois do cache (comparando Data+Hora)."""
        if atual_data is None and atual_hora is None:
            return False  # sem info nova — confia no cache
        cache_key = f"{cache_data or ''} {cache_hora or ''}"
        atual_key = f"{atual_data or ''} {atual_hora or ''}"
        return atual_key > cache_key

    # -------------------------------------------------------------------------
    # Chamados
    # -------------------------------------------------------------------------

    async def get_chamado(
        self,
        chave: int,
        *,
        data_alteracao_atual: str | None = None,
        hora_alteracao_atual: str | None = None,
    ) -> dict[str, Any] | None:
        """Retorna payload cacheado se ainda válido, senão None.

        Passe `data_alteracao_atual`/`hora_alteracao_atual` (da listagem recente)
        para invalidar automaticamente se o chamado mudou.
        """
        if not self.enabled or self._conn is None:
            return None
        row = await asyncio.to_thread(self._get_chamado_row, chave)
        if row is None:
            return None
        data_cache, hora_cache, final, payload, fetched = row
        if self._ttl_expirado(fetched, bool(final)):
            return None
        if self._foi_alterado(data_cache, hora_cache, data_alteracao_atual, hora_alteracao_atual):
            return None
        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            logger.warning("Cache de chamado %s corrompido — ignorando", chave)
            return None

    def _get_chamado_row(self, chave: int):
        cur = self._conn.execute(  # type: ignore[union-attr]
            "SELECT data_alteracao, hora_alteracao, finalizado, payload_json, fetched_at "
            "FROM chamados WHERE chave = ?",
            (chave,),
        )
        return cur.fetchone()

    async def set_chamado(
        self,
        chave: int,
        payload: dict[str, Any],
        *,
        data_alteracao: str | None,
        hora_alteracao: str | None,
        finalizado: bool,
    ) -> None:
        if not self.enabled or self._conn is None:
            return
        async with self._lock:
            await asyncio.to_thread(
                self._upsert_chamado,
                chave, payload, data_alteracao, hora_alteracao, finalizado,
            )

    def _upsert_chamado(
        self,
        chave: int,
        payload: dict[str, Any],
        data_alteracao: str | None,
        hora_alteracao: str | None,
        finalizado: bool,
    ) -> None:
        self._conn.execute(  # type: ignore[union-attr]
            "INSERT INTO chamados (chave, data_alteracao, hora_alteracao, finalizado, "
            "payload_json, fetched_at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(chave) DO UPDATE SET "
            "data_alteracao=excluded.data_alteracao, "
            "hora_alteracao=excluded.hora_alteracao, "
            "finalizado=excluded.finalizado, "
            "payload_json=excluded.payload_json, "
            "fetched_at=excluded.fetched_at",
            (
                chave,
                data_alteracao,
                hora_alteracao,
                1 if finalizado else 0,
                json.dumps(payload, ensure_ascii=False),
                time.time(),
            ),
        )

    # -------------------------------------------------------------------------
    # Históricos
    # -------------------------------------------------------------------------

    async def get_historico(
        self,
        chave: int,
        *,
        data_alteracao_atual: str | None = None,
        hora_alteracao_atual: str | None = None,
    ) -> dict[str, Any] | None:
        if not self.enabled or self._conn is None:
            return None
        row = await asyncio.to_thread(self._get_historico_row, chave)
        if row is None:
            return None
        data_cache, hora_cache, final, payload, fetched = row
        if self._ttl_expirado(fetched, bool(final)):
            return None
        if self._foi_alterado(data_cache, hora_cache, data_alteracao_atual, hora_alteracao_atual):
            return None
        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            logger.warning("Cache de histórico %s corrompido — ignorando", chave)
            return None

    async def historico_esta_fresh(self, chave: int, *, janela_segundos: int = 60) -> bool:
        """True se existe entrada cacheada fresquíssima (< janela_segundos).

        Usado para pular a chamada de snapshot (que valida invalidação) quando
        o cache foi preenchido segundos atrás — otimização de latência.
        """
        if not self.enabled or self._conn is None:
            return False
        row = await asyncio.to_thread(self._get_historico_row, chave)
        if row is None:
            return False
        *_, fetched = row
        return (time.time() - fetched) < janela_segundos

    def _get_historico_row(self, chave: int):
        cur = self._conn.execute(  # type: ignore[union-attr]
            "SELECT data_alteracao_chamado, hora_alteracao_chamado, finalizado, "
            "payload_json, fetched_at FROM historicos WHERE chave = ?",
            (chave,),
        )
        return cur.fetchone()

    async def set_historico(
        self,
        chave: int,
        payload: dict[str, Any],
        *,
        data_alteracao_chamado: str | None,
        hora_alteracao_chamado: str | None,
        finalizado: bool,
    ) -> None:
        if not self.enabled or self._conn is None:
            return
        async with self._lock:
            await asyncio.to_thread(
                self._upsert_historico,
                chave, payload, data_alteracao_chamado, hora_alteracao_chamado,
                finalizado,
            )

    def _upsert_historico(
        self,
        chave: int,
        payload: dict[str, Any],
        data_alteracao: str | None,
        hora_alteracao: str | None,
        finalizado: bool,
    ) -> None:
        self._conn.execute(  # type: ignore[union-attr]
            "INSERT INTO historicos (chave, data_alteracao_chamado, "
            "hora_alteracao_chamado, finalizado, payload_json, fetched_at) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(chave) DO UPDATE SET "
            "data_alteracao_chamado=excluded.data_alteracao_chamado, "
            "hora_alteracao_chamado=excluded.hora_alteracao_chamado, "
            "finalizado=excluded.finalizado, "
            "payload_json=excluded.payload_json, "
            "fetched_at=excluded.fetched_at",
            (
                chave,
                data_alteracao,
                hora_alteracao,
                1 if finalizado else 0,
                json.dumps(payload, ensure_ascii=False),
                time.time(),
            ),
        )

    # -------------------------------------------------------------------------
    # Estatísticas
    # -------------------------------------------------------------------------

    async def stats(self) -> dict[str, Any]:
        if not self.enabled or self._conn is None:
            return {"enabled": False}
        return await asyncio.to_thread(self._stats_sync)

    def _stats_sync(self) -> dict[str, Any]:
        c = self._conn.execute("SELECT COUNT(*), SUM(finalizado) FROM chamados").fetchone()  # type: ignore[union-attr]
        h = self._conn.execute("SELECT COUNT(*), SUM(finalizado) FROM historicos").fetchone()  # type: ignore[union-attr]
        return {
            "enabled": True,
            "path": str(self._path),
            "ttl_ativo_segundos": self.ttl_ativo,
            "ttl_finalizado_dias": self.ttl_finalizado // 86400,
            "chamados_total": c[0] or 0,
            "chamados_finalizados": c[1] or 0,
            "historicos_total": h[0] or 0,
            "historicos_finalizados": h[1] or 0,
        }
