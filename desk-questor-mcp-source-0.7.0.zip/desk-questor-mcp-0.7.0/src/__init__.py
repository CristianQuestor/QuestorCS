"""desk-questor-mcp: MCP server para Desk Manager (desk.ms)."""

__version__ = "0.1.0"
