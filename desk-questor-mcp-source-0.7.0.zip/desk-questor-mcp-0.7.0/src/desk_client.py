"""Cliente HTTP para o Desk Manager (desk.ms).

Gerencia o fluxo de autenticação em dois passos:
1. POST em DESK_LOGIN_URL com header DESK_AUTH_HEADER e body PublicKey=DESK_PUBLIC_KEY
   Response em texto puro contendo o token.
2. POST em DESK_API_URL/{entidade}/lista com header Authorization=DESK_BACKREQTOKEN
   (credencial DIFERENTE da de login).

Recursos:
- Cache de token em memória com renovação antes de expirar.
- Retry com backoff exponencial em 5xx/timeout.
- Rate limiting entre chamadas (batchInterval).
- Timeouts distintos para /lista (grande) e chamadas pontuais.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass
from typing import Any, Optional

import httpx

logger = logging.getLogger("desk-questor-mcp.client")


class DeskAuthError(RuntimeError):
    """Falha ao autenticar ou renovar token no Desk Manager."""


class DeskAPIError(RuntimeError):
    """Erro retornado pela API Desk depois dos retries."""

    def __init__(self, message: str, status_code: int | None = None, payload: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


@dataclass
class DeskConfig:
    """Configuração do cliente Desk.

    Autenticação em dois passos:
    1. POST em `login_url` com header `Authorization=auth_header` e body JSON
       `{"PublicKey": public_key}` → retorna token como string JSON.
    2. Demais chamadas em `api_url/...` usam `Authorization=<token>` +
       `PublicKey=<public_key>`. O `back_req_token` é OPCIONAL; alguns
       tenants aceitam como fallback, mas na prática o token do login basta.
    """

    auth_header: str
    public_key: str
    login_url: str
    login_body_format: str  # "form" (api.desk.ms, workflow 9zwhoKQ6kEsBw0xb) ou "json" (legado)
    api_url: str
    lista_timeout: float
    call_timeout: float
    rate_limit_ms: int
    token_refresh_margin: int
    token_ttl: int
    back_req_token: str | None = None

    @classmethod
    def from_env(cls) -> "DeskConfig":
        def req(key: str) -> str:
            v = os.environ.get(key, "").strip()
            if not v:
                raise DeskAuthError(
                    f"Variável de ambiente {key} não definida. Consulte .env.example."
                )
            return v

        # Default: caminho do workflow ATIVO 9zwhoKQ6kEsBw0xb — api.desk.ms + form.
        # Esse é o login que, em produção, gera token aceito por ChamadoHistoricos
        # (o caminho antigo questor.desk.ms + JSON gera token que retorna HTTP 500
        # no endpoint de histórico, apesar de funcionar em ChamadosSuporte).
        login_url = os.environ.get(
            "DESK_LOGIN_URL", "https://api.desk.ms/Login/autenticar"
        )
        login_body_format = os.environ.get("DESK_LOGIN_BODY_FORMAT", "").strip().lower()
        if not login_body_format:
            login_body_format = "form" if "api.desk.ms" in login_url else "json"
        if login_body_format not in ("form", "json"):
            raise DeskAuthError(
                f"DESK_LOGIN_BODY_FORMAT inválido: {login_body_format!r}. Use 'form' ou 'json'."
            )
        return cls(
            auth_header=req("DESK_AUTH_HEADER"),
            public_key=req("DESK_PUBLIC_KEY"),
            back_req_token=(os.environ.get("DESK_BACKREQTOKEN") or None),
            login_url=login_url,
            login_body_format=login_body_format,
            api_url=os.environ.get("DESK_API_URL", "https://api.desk.ms").rstrip("/"),
            lista_timeout=float(os.environ.get("DESK_LISTA_TIMEOUT", "600")),
            call_timeout=float(os.environ.get("DESK_CALL_TIMEOUT", "30")),
            rate_limit_ms=int(os.environ.get("DESK_RATE_LIMIT_MS", "200")),
            token_refresh_margin=int(os.environ.get("DESK_TOKEN_REFRESH_MARGIN", "30")),
            token_ttl=int(os.environ.get("DESK_TOKEN_TTL", "1800")),
        )


class DeskClient:
    """Cliente assíncrono para a API do Desk Manager.

    Uso típico:
        async with DeskClient.from_env() as client:
            dados = await client.listar("ChamadosSuporte", {"Tatual": 0, "Quantidade": 50})
    """

    def __init__(self, config: DeskConfig, *, http: httpx.AsyncClient | None = None):
        self.config = config
        self._http = http or httpx.AsyncClient()
        self._owns_http = http is None
        self._token: Optional[str] = None
        self._token_expires_at: float = 0.0
        self._token_lock = asyncio.Lock()
        self._rate_lock = asyncio.Lock()
        self._last_call_at: float = 0.0

    @classmethod
    def from_env(cls) -> "DeskClient":
        return cls(DeskConfig.from_env())

    async def __aenter__(self) -> "DeskClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    # -------------------------------------------------------------------------
    # Autenticação
    # -------------------------------------------------------------------------

    async def _fetch_token(self) -> str:
        """Faz login e retorna o token.

        Dois caminhos aceitos pela API desk.ms:
          1. `api.desk.ms/Login/autenticar` + body **form** (`PublicKey=...`) —
             caminho do workflow ativo 9zwhoKQ6kEsBw0xb, token aceito por
             todos os endpoints (inclusive ChamadoHistoricos).
          2. `questor.desk.ms/Login/autenticar` + body **JSON**
             (`{"PublicKey": "..."}`) — caminho legado; token retorna HTTP 500
             em ChamadoHistoricos.

        O formato é definido por `config.login_body_format`.
        Resposta: string JSON com aspas (ex.: `"cXVlc3Rvcg#..."`).
        """
        body_form = self.config.login_body_format == "form"
        headers = {
            "Authorization": self.config.auth_header,
            "Accept": "application/json, text/plain, */*",
            "Content-Type": (
                "application/x-www-form-urlencoded"
                if body_form
                else "application/json"
            ),
        }
        logger.info(
            "Desk login (%s) em %s", self.config.login_body_format, self.config.login_url
        )
        try:
            if body_form:
                resp = await self._http.post(
                    self.config.login_url,
                    headers=headers,
                    data={"PublicKey": self.config.public_key},
                    timeout=self.config.call_timeout,
                )
            else:
                resp = await self._http.post(
                    self.config.login_url,
                    headers=headers,
                    json={"PublicKey": self.config.public_key},
                    timeout=self.config.call_timeout,
                )
        except httpx.HTTPError as e:
            raise DeskAuthError(f"Falha de rede ao autenticar: {e}") from e

        if resp.status_code != 200:
            raise DeskAuthError(
                f"Login falhou: HTTP {resp.status_code} — {_safe_snippet(resp.text)}"
            )

        # Alguns endpoints devolvem JSON string ("token"), outros texto puro.
        try:
            parsed = resp.json()
            token = parsed if isinstance(parsed, str) else str(parsed)
        except ValueError:
            token = resp.text.strip().strip('"')

        token = token.strip().strip('"')
        # Mensagens de erro também vêm como string JSON; rejeitar
        if not token or len(token) < 8 or token.lower().startswith("está faltando"):
            raise DeskAuthError(
                f"Token inválido retornado pelo Desk: {_safe_snippet(resp.text)}"
            )
        return token

    async def _get_token(self) -> str:
        """Retorna token válido, renovando se faltarem <= refresh_margin segundos."""
        now = time.monotonic()
        margin = self.config.token_refresh_margin
        if self._token and now < (self._token_expires_at - margin):
            return self._token

        async with self._token_lock:
            now = time.monotonic()
            if self._token and now < (self._token_expires_at - margin):
                return self._token
            token = await self._fetch_token()
            self._token = token
            self._token_expires_at = now + self.config.token_ttl
            logger.debug(
                "Token renovado; válido por ~%ss", self.config.token_ttl
            )
            return token

    async def invalidate_token(self) -> None:
        async with self._token_lock:
            self._token = None
            self._token_expires_at = 0.0

    # -------------------------------------------------------------------------
    # Rate limiting
    # -------------------------------------------------------------------------

    async def _respect_rate_limit(self) -> None:
        if self.config.rate_limit_ms <= 0:
            return
        async with self._rate_lock:
            now = time.monotonic()
            delta_ms = (now - self._last_call_at) * 1000
            wait = (self.config.rate_limit_ms - delta_ms) / 1000
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_call_at = time.monotonic()

    # -------------------------------------------------------------------------
    # HTTP com retry
    # -------------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        url: str,
        *,
        json_body: Any | None = None,
        form_body: dict[str, Any] | None = None,
        timeout: float,
        auth_retry: bool = True,
        auth_mode: str = "login",
    ) -> Any:
        """POST/GET com retry exponencial. Retorna JSON parseado.

        auth_mode:
          - "login"   → Authorization = token obtido em /Login/autenticar.
          - "backreq" → Authorization = DESK_BACKREQTOKEN (cred #16 do n8n).
                         Necessário para endpoints específicos do Desk
                         Manager como /ChamadoHistoricos/lista.

        form_body: se fornecido, o corpo vai como application/x-www-form-urlencoded
        em vez de JSON (padrão usado pelos workflows n8n para o endpoint de
        histórico). Mutuamente exclusivo com json_body.

        Em 401/403 OU `{"erro": "Token expirado..."}` (a API devolve 200 com
        erro no body) o token é invalidado uma vez e a chamada é refeita.
        """
        if json_body is not None and form_body is not None:
            raise ValueError("Use apenas json_body OU form_body, não os dois")

        if auth_mode == "backreq":
            if not self.config.back_req_token:
                raise DeskAuthError(
                    "DESK_BACKREQTOKEN não configurado — endpoint exige o BackReqToken "
                    "(credencial #16 do n8n)."
                )
            auth_value = self.config.back_req_token
        else:
            auth_value = await self._get_token()

        content_type = (
            "application/x-www-form-urlencoded"
            if form_body is not None
            else "application/json"
        )
        headers = {
            "Authorization": auth_value,
            "PublicKey": self.config.public_key,
            "Content-Type": content_type,
            "Accept": "application/json",
        }

        last_exc: Exception | None = None
        for attempt in range(1, 4):
            await self._respect_rate_limit()
            start = time.monotonic()
            try:
                if form_body is not None:
                    resp = await self._http.request(
                        method,
                        url,
                        headers=headers,
                        data=form_body,
                        timeout=timeout,
                    )
                else:
                    resp = await self._http.request(
                        method,
                        url,
                        headers=headers,
                        json=json_body,
                        timeout=timeout,
                    )
            except (httpx.TimeoutException, httpx.TransportError) as e:
                last_exc = e
                logger.warning(
                    "Desk %s %s tentativa %d falhou: %s",
                    method, url, attempt, e,
                )
                await asyncio.sleep(min(2 ** attempt, 10))
                continue

            elapsed = int((time.monotonic() - start) * 1000)

            # Auth expirada: invalida e tenta 1x (só para auth_mode=login).
            # BackReqToken é estático — 401 nele significa credencial errada.
            if resp.status_code in (401, 403) and auth_retry and auth_mode == "login":
                logger.info(
                    "Desk %s %s HTTP %s — renovando token e refazendo",
                    method, url, resp.status_code,
                )
                await self.invalidate_token()
                return await self._request(
                    method, url,
                    json_body=json_body,
                    form_body=form_body,
                    timeout=timeout,
                    auth_retry=False,
                    auth_mode=auth_mode,
                )

            if 500 <= resp.status_code < 600:
                logger.warning(
                    "Desk %s %s HTTP %s (tentativa %d) em %dms",
                    method, url, resp.status_code, attempt, elapsed,
                )
                last_exc = DeskAPIError(
                    f"HTTP {resp.status_code}",
                    status_code=resp.status_code,
                    payload=_safe_snippet(resp.text),
                )
                await asyncio.sleep(min(2 ** attempt, 10))
                continue

            if resp.status_code >= 400:
                raise DeskAPIError(
                    f"HTTP {resp.status_code} em {url}: {_safe_snippet(resp.text)}",
                    status_code=resp.status_code,
                    payload=_safe_snippet(resp.text),
                )

            logger.debug("Desk %s %s OK em %dms", method, url, elapsed)
            try:
                data = resp.json()
            except ValueError:
                return resp.text

            # A API devolve 200 com {"erro": "..."} em vez de 4xx.
            if isinstance(data, dict) and "erro" in data and len(data) == 1:
                erro = str(data["erro"])
                if (
                    auth_retry
                    and auth_mode == "login"
                    and ("expirado" in erro.lower() or "token" in erro.lower())
                ):
                    logger.info(
                        "Desk %s %s erro de token no body (%s) — renovando",
                        method, url, erro,
                    )
                    await self.invalidate_token()
                    return await self._request(
                        method, url,
                        json_body=json_body,
                        form_body=form_body,
                        timeout=timeout,
                        auth_retry=False,
                        auth_mode=auth_mode,
                    )
                raise DeskAPIError(f"Erro retornado pela API: {erro}", status_code=200)

            return data

        raise DeskAPIError(
            f"Falha após 3 tentativas: {last_exc}",
            payload=str(last_exc) if last_exc else None,
        )

    # -------------------------------------------------------------------------
    # Operações públicas
    # -------------------------------------------------------------------------

    async def listar(
        self,
        entidade: str,
        body: dict[str, Any] | None = None,
        *,
        auth_mode: str = "login",
    ) -> dict[str, Any]:
        """POST /{entidade}/lista. Retorna {root: [...], total: N}."""
        url = f"{self.config.api_url}/{entidade}/lista"
        payload = dict(body or {})
        payload.setdefault("Tatual", 0)
        payload.setdefault("Quantidade", 200)
        result = await self._request(
            "POST",
            url,
            json_body=payload,
            timeout=self.config.lista_timeout,
            auth_mode=auth_mode,
        )
        if not isinstance(result, dict):
            raise DeskAPIError(f"Response inesperado de {entidade}/lista: não é objeto")
        return result

    async def listar_form(
        self,
        entidade: str,
        body: dict[str, Any],
        *,
        auth_mode: str = "login",
    ) -> dict[str, Any]:
        """POST /{entidade}/lista com body form-urlencoded.

        Usado em endpoints que só aceitam form (ex.: ChamadoHistoricos),
        espelhando o padrão observado nos workflows n8n oficiais. Default
        usa o token do login — o mesmo que autoriza os demais endpoints;
        os workflows n8n rotacionam a "BackReqToken" com esse valor.
        """
        url = f"{self.config.api_url}/{entidade}/lista"
        result = await self._request(
            "POST",
            url,
            form_body=body,
            timeout=self.config.lista_timeout,
            auth_mode=auth_mode,
        )
        if isinstance(result, dict):
            return result
        raise DeskAPIError(
            f"Response inesperado de {entidade}/lista (form): não é objeto"
        )

    async def listar_paginado(
        self,
        entidade: str,
        body: dict[str, Any] | None = None,
        *,
        limite_total: int | None = None,
    ) -> list[dict[str, Any]]:
        """Pagina automaticamente usando Tatual. Retorna lista achatada de root."""
        registros: list[dict[str, Any]] = []
        base = dict(body or {})
        por_pagina = int(base.get("Quantidade", 3000))
        tatual = int(base.get("Tatual", 0))
        total_esperado: int | None = None

        while True:
            page_body = {**base, "Tatual": tatual, "Quantidade": por_pagina}
            page = await self.listar(entidade, page_body)
            lote = page.get("root") or []
            registros.extend(lote)
            if total_esperado is None and "total" in page:
                try:
                    total_esperado = int(page["total"])
                except (TypeError, ValueError):
                    total_esperado = None

            if not lote or len(lote) < por_pagina:
                break
            tatual += len(lote)
            if total_esperado is not None and tatual >= total_esperado:
                break
            if limite_total is not None and len(registros) >= limite_total:
                registros = registros[:limite_total]
                break
        return registros

    async def obter(
        self,
        entidade: str,
        chave: int,
        *,
        campo_chave: str = "Chave",
        body_extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """POST /{entidade} com Chave no body. Usado para detalhes pontuais."""
        url = f"{self.config.api_url}/{entidade}"
        payload: dict[str, Any] = {campo_chave: chave}
        if body_extra:
            payload.update(body_extra)
        result = await self._request(
            "POST", url, json_body=payload, timeout=self.config.call_timeout
        )
        if isinstance(result, dict):
            # Alguns endpoints devolvem {root: [ {...} ]}, outros o objeto direto.
            root = result.get("root")
            if isinstance(root, list) and root:
                return root[0]
            return result
        raise DeskAPIError(f"Response inesperado ao obter {entidade} {chave}")

    async def listar_historico_chamado(self, chave: int) -> dict[str, Any]:
        """POST /ChamadoHistoricos/listaCustom — endpoint real usado pela UI do Desk.

        Descoberto via inspeção de rede do portal logado (questor.desk.ms).
        Chamado por `ChamadosSuporte.editarChamado` ao abrir a tela de detalhe.

        Diferenças para o endpoint anterior (`/lista`):
        - Body é form-urlencoded `Dados=<json>&App=Ticket` (UI usa assim)
        - Filtro via `Filtros: {CodChamado: [<chave_int>, "equal"]}`
          (CodChamado aqui é a Chave interna do chamado, não o texto humano)
        - Resposta em formato flat: `NomeOperador: "Caciano"` em vez de
          `Operador: [{id, text}]` — parser fica mais simples
        - Cobre as mesmas ações do /lista **e** materializa sessões de Chat
          ao vivo mais cedo em alguns cenários
        """
        url = f"{self.config.api_url}/ChamadoHistoricos/listaCustom"
        dados = {
            "Ajax": "true",
            "Filtros": {"CodChamado": [str(chave), "equal"]},
            "Colunas": {
                "Chave": "on",
                "CodChamado": "on",
                "Descricao": "on",
                "DescricaoAbrev": "on",
                "DataAcao": "on",
                "HoraAcaoInicio": "on",
                "HoraAcaoFim": "on",
                "NomeOperador": "on",
                "CodOperador": "on",
                "NomeStatus": "on",
                "CodStatus": "on",
                "NomeFormaAtendimento": "on",
                "CodFormaAtendimento": "on",
                "NomeCausa": "on",
                "TotalHoras": "on",
            },
        }
        form_body = {"Dados": json.dumps(dados), "App": "Ticket"}
        result = await self._request(
            "POST",
            url,
            form_body=form_body,
            timeout=self.config.lista_timeout,
        )
        if isinstance(result, dict):
            return result
        if isinstance(result, list):
            return {"root": result, "total": str(len(result))}
        return {"root": [], "total": "0"}

    async def post(
        self,
        entidade: str,
        body: dict[str, Any],
        *,
        acao: str | None = None,
    ) -> Any:
        """POST livre em api.desk.ms/{entidade}[/acao]. Usado para ações de escrita."""
        url = f"{self.config.api_url}/{entidade}"
        if acao:
            url = f"{url}/{acao}"
        return await self._request(
            "POST", url, json_body=body, timeout=self.config.call_timeout
        )


def _safe_snippet(text: str | None, *, limit: int = 300) -> str:
    if not text:
        return ""
    s = text.replace("\n", " ").strip()
    if len(s) > limit:
        return s[:limit] + "…"
    return s
