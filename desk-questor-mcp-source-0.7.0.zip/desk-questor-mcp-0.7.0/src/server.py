"""FastMCP entrypoint do desk-questor-mcp.

Registra as tools usando o padrão dos outros MCPs Questor (quiara, redmine-questor):
- Pydantic BaseModel para inputs
- Lifespan para inicializar o DeskClient com cache de token
- Logs estruturados
- Mensagens de erro em português, nunca expondo credenciais
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from mcp.server.fastmcp import Context, FastMCP
from pydantic import BaseModel, ConfigDict, Field

from .desk_cache import DeskCache
from .desk_client import DeskAPIError, DeskAuthError, DeskClient
from .operadores_cache import OperadoresCache
from .tools import catalogos as tool_catalogos
from .tools import chamados as tool_chamados
from .tools import chat as tool_chat
from .tools import dashboard as tool_dashboard
from .tools import interacoes as tool_interacoes

SERVER_NAME = "desk-questor-mcp"
SERVER_VERSION = "0.7.0"

# Carrega .env da raiz do repositório (src/..) para funcionar mesmo quando o
# servidor é iniciado a partir de outro diretório (ex.: Claude Code sem cwd).
_REPO_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(dotenv_path=_REPO_ROOT / ".env", override=False)
load_dotenv(override=False)  # fallback: .env do cwd atual

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(SERVER_NAME)


@asynccontextmanager
async def app_lifespan(app):
    logger.info("Inicializando %s v%s", SERVER_NAME, SERVER_VERSION)
    try:
        client = DeskClient.from_env()
    except DeskAuthError as e:
        logger.error("Erro de configuração: %s", e)
        raise
    ttl_operadores = int(os.environ.get("DESK_OPERADORES_CACHE_TTL", "60"))
    operadores_cache = OperadoresCache(client, ttl_segundos=ttl_operadores)
    desk_cache = DeskCache.from_env()
    try:
        yield {
            "desk": client,
            "operadores": operadores_cache,
            "cache": desk_cache,
        }
    finally:
        desk_cache.close()
        await client.aclose()
        logger.info("%s encerrado", SERVER_NAME)


mcp = FastMCP(SERVER_NAME, lifespan=app_lifespan)


def _client(ctx: Context) -> DeskClient:
    return ctx.request_context.lifespan_context["desk"]


def _operadores(ctx: Context) -> OperadoresCache:
    return ctx.request_context.lifespan_context["operadores"]


def _cache(ctx: Context) -> DeskCache:
    return ctx.request_context.lifespan_context["cache"]


def _format_err(e: Exception) -> str:
    if isinstance(e, DeskAuthError):
        return f"Falha de autenticação no Desk: {e}"
    if isinstance(e, DeskAPIError):
        if e.status_code:
            return f"Erro da API Desk (HTTP {e.status_code}): {e}"
        return f"Erro da API Desk: {e}"
    return f"Erro inesperado ({type(e).__name__}): {e}"


# =============================================================================
# 1. listar_chamados_ativos_hoje
# =============================================================================

class ListarAtivosInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    grupo: Optional[str] = Field(
        None,
        description="Filtrar por fila/grupo (ex.: 'Suporte - Web'). Use listar_grupos para descobrir valores válidos.",
    )
    sla_expirado: Optional[bool] = Field(
        None,
        description="Se true, só retorna chamados com SLA 1 ou 2 expirado. Se false, só sem SLA expirado. Omita para todos.",
    )
    ordem: str = Field(
        "tempo_aberto_desc",
        description="Ordenação: tempo_aberto_desc | tempo_aberto_asc | sem_resposta_desc | urgencia | data_criacao_desc",
    )
    limite: int = Field(50, ge=1, le=500, description="Máximo de chamados a retornar (1–500).")


@mcp.tool(
    name="listar_chamados_ativos_hoje",
    annotations={
        "title": "Listar chamados ativos abertos hoje",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def listar_chamados_ativos_hoje(params: ListarAtivosInput, ctx: Context) -> dict[str, Any]:
    """Lista chamados criados hoje que ainda não foram finalizados.

    Retorna cada chamado enriquecido com campos calculados em BRT:
    - horas_aberto, horas_sem_resposta
    - cliente_nome_completo (NomeUsuario + SobrenomeUsuario)
    - urgencia (alto/medio/baixo) baseada em SLA e tempo sem resposta

    Use para o loop de monitoramento do agent N3. Combine com `obter_chamado`
    para detalhes antes de tomar qualquer ação.
    """
    try:
        chamados = await tool_chamados.listar_chamados_ativos_hoje(
            _client(ctx),
            grupo=params.grupo,
            sla_expirado=params.sla_expirado,
            ordem=params.ordem,
            limite=params.limite,
            operadores=_operadores(ctx),
        )
        return {
            "total": len(chamados),
            "chamados": [c.model_dump(exclude={"raw"}) for c in chamados],
        }
    except Exception as e:
        logger.exception("Erro em listar_chamados_ativos_hoje")
        return {"erro": _format_err(e)}


# =============================================================================
# 1b. listar_chamados_ativos (filtros genéricos de data)
# =============================================================================

class ListarAtivosGenericoInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    data_criacao_de: Optional[str] = Field(
        None,
        description="Data de criação mínima no formato YYYY-MM-DD (inclusive). Omita para não limitar.",
    )
    data_criacao_ate: Optional[str] = Field(
        None,
        description="Data de criação máxima YYYY-MM-DD (inclusive). Omita para não limitar.",
    )
    data_alteracao_de: Optional[str] = Field(
        None,
        description="Data de última alteração mínima YYYY-MM-DD. Útil para ver o que foi trabalhado num período.",
    )
    data_alteracao_ate: Optional[str] = Field(
        None,
        description="Data de última alteração máxima YYYY-MM-DD.",
    )
    operador: Optional[str] = Field(
        None,
        description="Filtrar pelo NomeOperador exato (use listar_operadores para descobrir).",
    )
    grupo: Optional[str] = Field(
        None, description="Filtrar por fila/grupo (ex.: 'Suporte - Web')."
    )
    status: Optional[list[str]] = Field(
        None,
        description="Lista de NomeStatus aceitos (ex.: ['Em Andamento','Aguardando Atendimento']).",
    )
    sla_expirado: Optional[bool] = Field(
        None,
        description="Se true, só SLA expirado; false, só sem SLA expirado; omita para ambos.",
    )
    sem_operador: Optional[bool] = Field(
        None,
        description="Se true, só chamados SEM operador atribuído (backlog puro); false, só os atribuídos; omita para ambos.",
    )
    apenas_ativos: bool = Field(
        True,
        description="Default true: ignora chamados finalizados. Passe false para incluir resolvidos.",
    )
    ordem: str = Field(
        "tempo_aberto_desc",
        description="Ordenação: tempo_aberto_desc | tempo_aberto_asc | sem_resposta_desc | urgencia | data_criacao_desc",
    )
    limite: int = Field(
        500, ge=1, le=2000, description="Máximo de chamados a retornar (1–2000). Default 500."
    )


@mcp.tool(
    name="listar_chamados_ativos",
    annotations={
        "title": "Listar chamados ativos (com filtros de data, operador, grupo, status)",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def listar_chamados_ativos(
    params: ListarAtivosGenericoInput, ctx: Context
) -> dict[str, Any]:
    """Tool genérica para análise de passivo e capacidade.

    Casos de uso:
    - Passivo total: omita filtros de data.
    - Trabalhado hoje mas aberto antes: data_alteracao_de=hoje, data_criacao_ate=ontem.
    - Backlog de um operador: operador=<nome>, apenas_ativos=true.
    - Chamados antigos ainda abertos: data_criacao_ate=hoje-7.

    Cada chamado vem enriquecido com presença do operador
    (operador_online / operador_chave / operador_grupo_principal).
    """
    try:
        chamados = await tool_chamados.listar_chamados_ativos(
            _client(ctx),
            data_criacao_de=params.data_criacao_de,
            data_criacao_ate=params.data_criacao_ate,
            data_alteracao_de=params.data_alteracao_de,
            data_alteracao_ate=params.data_alteracao_ate,
            operador=params.operador,
            grupo=params.grupo,
            status=params.status,
            sla_expirado=params.sla_expirado,
            sem_operador=params.sem_operador,
            apenas_ativos=params.apenas_ativos,
            ordem=params.ordem,
            limite=params.limite,
            operadores=_operadores(ctx),
        )
        return {
            "total": len(chamados),
            "chamados": [c.model_dump(exclude={"raw"}) for c in chamados],
        }
    except Exception as e:
        logger.exception("Erro em listar_chamados_ativos")
        return {"erro": _format_err(e)}


# =============================================================================
# 1c. listar_chamados (tool principal — análise retrospectiva + finalização)
# =============================================================================

class ListarChamadosInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    data_criacao_de: Optional[str] = Field(
        None, description="Data de criação mínima YYYY-MM-DD (inclusive)."
    )
    data_criacao_ate: Optional[str] = Field(
        None, description="Data de criação máxima YYYY-MM-DD (inclusive)."
    )
    data_alteracao_de: Optional[str] = Field(
        None, description="Data de última alteração mínima YYYY-MM-DD."
    )
    data_alteracao_ate: Optional[str] = Field(
        None, description="Data de última alteração máxima YYYY-MM-DD."
    )
    data_finalizacao_de: Optional[str] = Field(
        None,
        description="Data de finalização mínima YYYY-MM-DD. Requer apenas_ativos=false.",
    )
    data_finalizacao_ate: Optional[str] = Field(
        None,
        description="Data de finalização máxima YYYY-MM-DD. Requer apenas_ativos=false.",
    )
    operador: Optional[str] = Field(
        None,
        description="Match PARCIAL case-insensitive no NomeOperador (ex.: 'jessica' acha 'Jessica Lopes').",
    )
    operador_chave: Optional[int] = Field(
        None, description="Match EXATO pela ChaveOperador (inteiro)."
    )
    grupo: Optional[str] = Field(
        None, description="NomeGrupo exato (ex.: 'Suporte - Folha de Pagamento')."
    )
    status: Optional[list[str]] = Field(
        None,
        description="Lista de NomeStatus aceitos (ex.: ['Resolvido','Finalizado']).",
    )
    sla_expirado: Optional[bool] = Field(
        None, description="Se true, só SLA expirado; false, só sem SLA expirado."
    )
    sem_operador: Optional[bool] = Field(
        None, description="Se true, só chamados sem atribuição."
    )
    apenas_ativos: bool = Field(
        True,
        description="Default true. Passe false para incluir finalizados (necessário para filtros data_finalizacao_*).",
    )
    ordem: str = Field(
        "tempo_aberto_desc",
        description="tempo_aberto_desc | tempo_aberto_asc | sem_resposta_desc | urgencia | data_criacao_desc | data_finalizacao_desc",
    )
    limite: int = Field(
        100, ge=1, le=2000, description="Máximo a retornar (1–2000). Default 100."
    )


@mcp.tool(
    name="listar_chamados",
    annotations={
        "title": "Listar chamados — análise retrospectiva (ativos + finalizados, até 90d)",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def listar_chamados(
    params: ListarChamadosInput, ctx: Context
) -> dict[str, Any]:
    """Tool principal para análise retrospectiva e backlog.

    Diferencia-se de `listar_chamados_ativos` por:
    - Suporta `data_finalizacao_de/ate` (quem fechou o quê)
    - `operador` faz match parcial (não exato)
    - `operador_chave` para match exato por ID
    - Janela máx 90 dias — use datalake-metabase para análises maiores
    - Paginação interna até 2000 registros

    Cada chamado traz campos novos quando finalizado:
    data_finalizacao, hora_finalizacao, horas_ate_finalizacao_uteis,
    finalizado_no_mesmo_dia.
    """
    try:
        chamados = await tool_chamados.listar_chamados(
            _client(ctx),
            data_criacao_de=params.data_criacao_de,
            data_criacao_ate=params.data_criacao_ate,
            data_alteracao_de=params.data_alteracao_de,
            data_alteracao_ate=params.data_alteracao_ate,
            data_finalizacao_de=params.data_finalizacao_de,
            data_finalizacao_ate=params.data_finalizacao_ate,
            operador=params.operador,
            operador_chave=params.operador_chave,
            grupo=params.grupo,
            status=params.status,
            sla_expirado=params.sla_expirado,
            sem_operador=params.sem_operador,
            apenas_ativos=params.apenas_ativos,
            ordem=params.ordem,
            limite=params.limite,
            operadores=_operadores(ctx),
        )
        return {
            "total": len(chamados),
            "chamados": [c.model_dump(exclude={"raw"}) for c in chamados],
        }
    except Exception as e:
        logger.exception("Erro em listar_chamados")
        return {"erro": _format_err(e)}


# =============================================================================
# 2. obter_chamado
# =============================================================================

class ObterChamadoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    chave: int = Field(..., description="Chave numérica do chamado (campo 'Chave' na lista).")
    incluir_historico: bool = Field(True, description="Incluir lista de interações/ações.")
    incluir_anexos: bool = Field(False, description="Incluir metadados de anexos.")
    ignorar_cache: bool = Field(
        False,
        description="Se true, ignora o cache SQLite e força refetch da API.",
    )


@mcp.tool(
    name="obter_chamado",
    annotations={
        "title": "Obter detalhe completo de um chamado",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def obter_chamado(params: ObterChamadoInput, ctx: Context) -> dict[str, Any]:
    """Retorna detalhes de um chamado específico + histórico (por padrão).

    Antes de comentar ou mudar status, chame esta tool para confirmar o contexto atual.
    """
    try:
        return await tool_chamados.obter_chamado(
            _client(ctx),
            chave=params.chave,
            incluir_historico=params.incluir_historico,
            incluir_anexos=params.incluir_anexos,
            operadores=_operadores(ctx),
            cache=_cache(ctx),
            ignorar_cache=params.ignorar_cache,
        )
    except Exception as e:
        logger.exception("Erro em obter_chamado")
        return {"erro": _format_err(e)}


# =============================================================================
# 3. listar_historico_chamado
# =============================================================================

class HistoricoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    chave: Optional[int] = Field(
        None,
        description="Chave numérica do chamado. Se omitida, informe 'codigo'.",
    )
    codigo: Optional[str] = Field(
        None,
        description="CodChamado string (ex.: '0426-011564'). A Chave será resolvida internamente.",
    )
    limite_texto: Optional[int] = Field(
        None,
        ge=0,
        description=(
            "Limite de caracteres por ação. Textos maiores vão para arquivo e "
            "o response traz só um preview + 'texto_arquivo' com o caminho. "
            "Default 2000. Passe 0 para nunca truncar."
        ),
    )
    incluir_raw: bool = Field(
        False,
        description="Se true, mantém o objeto 'raw' original da API em cada ação (consome muito contexto).",
    )
    ignorar_cache: bool = Field(
        False,
        description="Se true, ignora o cache SQLite e força refetch da API.",
    )


@mcp.tool(
    name="listar_historico_chamado",
    annotations={
        "title": "Listar histórico/interações de um chamado",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def listar_historico_chamado(params: HistoricoInput, ctx: Context) -> dict[str, Any]:
    """Retorna todas as ações/interações registradas no chamado, em ordem cronológica.

    Cada ação traz: sequencia, data_hora, operador, tipo (ex.: 'Resposta Pública'
    vs 'Comentário Interno'), publico (bool), texto, anexos.
    Para chamados sem ações, retorna `{"total": 0, "acoes": []}` (nunca erro).
    """
    if params.chave is None and not params.codigo:
        return {"erro": "Informe 'chave' (int) ou 'codigo' (string)."}
    try:
        return await tool_chamados.listar_historico_chamado(
            _client(ctx),
            chave=params.chave,
            codigo=params.codigo,
            limite_texto=params.limite_texto,
            incluir_raw=params.incluir_raw,
            cache=_cache(ctx),
            ignorar_cache=params.ignorar_cache,
        )
    except Exception as e:
        logger.exception("Erro em listar_historico_chamado")
        return {"erro": _format_err(e)}


# =============================================================================
# 4. buscar_chamados_similares
# =============================================================================

class BuscarSimilaresInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    texto_busca: str = Field(..., min_length=3, max_length=500, description="Texto a buscar no Assunto.")
    apenas_resolvidos: bool = Field(True, description="Se true, ignora chamados ainda ativos.")
    limite: int = Field(10, ge=1, le=100)
    periodo_dias: int = Field(180, ge=1, le=3650, description="Janela em dias para a busca.")


@mcp.tool(
    name="buscar_chamados_similares",
    annotations={
        "title": "Buscar chamados similares já resolvidos",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def buscar_chamados_similares(params: BuscarSimilaresInput, ctx: Context) -> dict[str, Any]:
    """Busca chamados cujo assunto contém o texto — ideal para achar soluções anteriores."""
    try:
        resultados = await tool_chamados.buscar_chamados_similares(
            _client(ctx),
            texto_busca=params.texto_busca,
            apenas_resolvidos=params.apenas_resolvidos,
            limite=params.limite,
            periodo_dias=params.periodo_dias,
            operadores=_operadores(ctx),
        )
        return {
            "total": len(resultados),
            "chamados": [c.model_dump(exclude={"raw"}) for c in resultados],
        }
    except Exception as e:
        logger.exception("Erro em buscar_chamados_similares")
        return {"erro": _format_err(e)}


# =============================================================================
# 5. comentar_chamado
# =============================================================================

class ComentarInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    chave: int = Field(..., description="Chave do chamado.")
    texto: str = Field(..., min_length=1, max_length=10000, description="Conteúdo do comentário.")
    publico: bool = Field(
        False,
        description="Se true, visível para o cliente. Default false (interno). Use com cuidado.",
    )


@mcp.tool(
    name="comentar_chamado",
    annotations={
        "title": "Postar comentário em um chamado",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def comentar_chamado(params: ComentarInput, ctx: Context) -> dict[str, Any]:
    """Adiciona comentário/ação ao chamado. Default é INTERNO."""
    try:
        return await tool_interacoes.comentar_chamado(
            _client(ctx),
            chave=params.chave,
            texto=params.texto,
            publico=params.publico,
        )
    except Exception as e:
        logger.exception("Erro em comentar_chamado")
        return {"erro": _format_err(e)}


# =============================================================================
# 6. atualizar_status_chamado
# =============================================================================

class AtualizarStatusInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    chave: int = Field(..., description="Chave do chamado.")
    novo_status: str = Field(..., min_length=1, max_length=200, description="Nome do novo status (veja listar_status).")
    comentario: Optional[str] = Field(None, max_length=10000, description="Comentário opcional associado à mudança.")


@mcp.tool(
    name="atualizar_status_chamado",
    annotations={
        "title": "Atualizar status do chamado",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def atualizar_status_chamado(params: AtualizarStatusInput, ctx: Context) -> dict[str, Any]:
    """Muda o status do chamado; opcionalmente registra um comentário junto."""
    try:
        return await tool_interacoes.atualizar_status_chamado(
            _client(ctx),
            chave=params.chave,
            novo_status=params.novo_status,
            comentario=params.comentario,
        )
    except Exception as e:
        logger.exception("Erro em atualizar_status_chamado")
        return {"erro": _format_err(e)}


# =============================================================================
# 7. listar_grupos
# =============================================================================

class ListarGruposInput(BaseModel):
    model_config = ConfigDict(extra="forbid")


@mcp.tool(
    name="listar_grupos",
    annotations={
        "title": "Listar grupos/filas de atendimento",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def listar_grupos(params: ListarGruposInput, ctx: Context) -> dict[str, Any]:
    """Lista os grupos (filas) configurados no Desk — use para filtrar chamados por fila."""
    try:
        grupos = await tool_catalogos.listar_grupos(_client(ctx))
        return {"total": len(grupos), "grupos": grupos}
    except Exception as e:
        logger.exception("Erro em listar_grupos")
        return {"erro": _format_err(e)}


# =============================================================================
# 8. listar_operadores
# =============================================================================

class ListarOperadoresInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    apenas_ativos: bool = Field(True, description="Se true, filtra operadores ativos.")


@mcp.tool(
    name="listar_operadores",
    annotations={
        "title": "Listar operadores",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def listar_operadores(params: ListarOperadoresInput, ctx: Context) -> dict[str, Any]:
    """Lista operadores do Desk. Default: apenas ativos."""
    try:
        operadores = await tool_catalogos.listar_operadores(
            _client(ctx),
            apenas_ativos=params.apenas_ativos,
            cache=_operadores(ctx),
        )
        return {"total": len(operadores), "operadores": operadores}
    except Exception as e:
        logger.exception("Erro em listar_operadores")
        return {"erro": _format_err(e)}


# =============================================================================
# 9. dashboard_n3
# =============================================================================

class DashboardInput(BaseModel):
    model_config = ConfigDict(extra="forbid")


@mcp.tool(
    name="dashboard_n3",
    annotations={
        "title": "Dashboard consolidado para N3",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def dashboard_n3(params: DashboardInput, ctx: Context) -> dict[str, Any]:
    """Retorna agregados úteis para decidir onde focar: totais, distribuição
    por grupo, SLA 1 expirando nas próximas 2h, chamados sem atribuição e top 10
    mais tempo sem resposta.
    """
    try:
        dash = await tool_dashboard.dashboard_n3(_client(ctx), _operadores(ctx))
        data = dash.model_dump()
        data["top_sem_resposta"] = [
            c if isinstance(c, dict) else c.model_dump(exclude={"raw"})
            for c in data.get("top_sem_resposta", [])
        ]
        return data
    except Exception as e:
        logger.exception("Erro em dashboard_n3")
        return {"erro": _format_err(e)}


# =============================================================================
# 10. cache_stats — diagnóstico do cache SQLite
# =============================================================================


class _CacheStatsInput(BaseModel):
    model_config = ConfigDict(extra="forbid")


@mcp.tool(
    name="cache_stats",
    annotations={
        "title": "Estatísticas do cache SQLite (desk_cache)",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def cache_stats(params: _CacheStatsInput, ctx: Context) -> dict[str, Any]:
    """Retorna contagem de chamados/históricos cacheados e configuração atual."""
    try:
        return await _cache(ctx).stats()
    except Exception as e:
        logger.exception("Erro em cache_stats")
        return {"erro": _format_err(e)}


# =============================================================================
# 11. escutar_chat_chamado — captura chat ao vivo via Ably
# =============================================================================


class EscutarChatChamadoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    chave: int = Field(..., description="Chave numérica do chamado cujo chat se quer acompanhar.")
    duracao_segundos: float = Field(
        30,
        ge=1,
        le=600,
        description="Quanto tempo escutar o Ably antes de retornar (1–600s). Default 30s.",
    )
    incluir_typing: bool = Field(
        False,
        description="Se true, inclui eventos de 'digitando' (Ocultar) — geralmente ruído.",
    )


@mcp.tool(
    name="escutar_chat_chamado",
    annotations={
        "title": "Escutar chat ao vivo de um chamado via Ably (tempo real)",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def escutar_chat_chamado(
    params: EscutarChatChamadoInput, ctx: Context
) -> dict[str, Any]:
    """Bloqueia por `duracao_segundos` e devolve as mensagens de chat do chamado.

    Útil para acompanhar uma conversa **em andamento** (sessão ainda não
    encerrada) — essas mensagens NÃO aparecem em listar_historico_chamado
    até a sessão fechar. Por baixo assina o canal Ably do tenant e filtra
    pelo par (ChaveUsuario, ChaveOperador) do chamado.

    Notas operacionais:
    - A chamada bloqueia durante a duração pedida — use valores curtos
      (15–60s) pra não monopolizar o agente.
    - Se o chat estiver silencioso no período, retorna lista vazia.
    - Se o chamado não tem operador atribuído, filtra só por cliente.
    """
    try:
        return await tool_chat.escutar_chat_chamado(
            _client(ctx),
            chave=params.chave,
            duracao_segundos=params.duracao_segundos,
            incluir_typing=params.incluir_typing,
        )
    except Exception as e:
        logger.exception("Erro em escutar_chat_chamado")
        return {"erro": _format_err(e)}


# =============================================================================
# 12. escutar_chat_global — debug/dashboard do canal Ably
# =============================================================================


class EscutarChatGlobalInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    duracao_segundos: float = Field(
        15, ge=1, le=120,
        description="Quanto tempo escutar (1–120s). Default 15s.",
    )
    cod_usuario: Optional[int] = Field(
        None,
        description="Opcional. Filtra mensagens do cliente (ChaveUsuario) indicado.",
    )
    chave_operador: Optional[int] = Field(
        None,
        description="Opcional. Filtra mensagens do operador (ChaveOperador) indicado.",
    )
    incluir_typing: bool = Field(
        False, description="Se true, inclui eventos de 'digitando'."
    )


@mcp.tool(
    name="escutar_chat_global",
    annotations={
        "title": "Escutar canal Ably do tenant (firehose de chat)",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def escutar_chat_global(
    params: EscutarChatGlobalInput, ctx: Context
) -> dict[str, Any]:
    """Escuta o canal Ably do tenant por `duracao_segundos` e devolve as msgs.

    Canal único `questor` recebe TODOS os chats da empresa em tempo real
    (centenas por minuto em horário comercial). Use filtros ou duração curta.

    Cenários:
    - Debug: sem filtros por 10s pra ver amostra.
    - Operador X trabalhando agora: chave_operador=X pra ver com que clientes.
    - Cliente Y tentando falar: cod_usuario=Y pra ver se está ativo no chat.
    """
    try:
        return await tool_chat.escutar_chat_global(
            duracao_segundos=params.duracao_segundos,
            cod_usuario=params.cod_usuario,
            chave_operador=params.chave_operador,
            incluir_typing=params.incluir_typing,
        )
    except Exception as e:
        logger.exception("Erro em escutar_chat_global")
        return {"erro": _format_err(e)}


def main() -> None:
    """Entrypoint para `python -m src.server` ou o script `desk-questor-mcp`."""
    mcp.run()


if __name__ == "__main__":
    main()
