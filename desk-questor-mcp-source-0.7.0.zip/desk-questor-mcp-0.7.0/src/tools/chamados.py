"""Tools de leitura de chamados."""

from __future__ import annotations

import logging
import re
from datetime import date
from typing import Any, Iterable

from .. import enrichment
from ..desk_cache import DeskCache
from ..desk_client import DeskClient
from ..enrichment import enriquecer_chamado, ordenar_chamados
from ..historico import listar_historico as _listar_historico_normalizado
from ..models import ChamadoEnriquecido
from ..operadores_cache import OperadoresCache

logger = logging.getLogger("desk-questor-mcp.tools.chamados")


_STATUS_ATIVO_DEFAULT = {
    "Aguardando Atendimento",
    "Em Andamento",
    "Andamento",
    "Aguardando Cliente",
    "Aguardando Usuário",
    "Aguardando Retorno",
    "Aguardando",
    "Em Análise",
    "Reaberto",
}


async def _aplicar_presenca(
    chamados: Iterable[ChamadoEnriquecido],
    operadores: OperadoresCache | None,
) -> list[ChamadoEnriquecido]:
    """Enriquece cada chamado com operador_online/chave/grupo_principal."""
    lista = list(chamados)
    if operadores is None:
        return lista
    for c in lista:
        try:
            chave_op = c.raw.get("ChaveOperador") if isinstance(c.raw, dict) else None
        except AttributeError:
            chave_op = None
        info = await operadores.resolver(nome=c.operador, chave=chave_op)
        if not info:
            if c.operador:
                c.operador_online = None
            continue
        c.operador_chave = info.get("chave")
        c.operador_online = info.get("online")
        c.operador_grupo_principal = info.get("grupo_principal")
    return lista


async def listar_chamados_ativos_hoje(
    client: DeskClient,
    *,
    grupo: str | None = None,
    sla_expirado: bool | None = None,
    ordem: str = "tempo_aberto_desc",
    limite: int = 50,
    operadores: OperadoresCache | None = None,
) -> list[ChamadoEnriquecido]:
    """Alias retrocompatível: chamados criados hoje e ainda ativos."""
    hoje = enrichment._agora_brt().date().isoformat()
    return await listar_chamados(
        client,
        data_criacao_de=hoje,
        data_criacao_ate=hoje,
        grupo=grupo,
        sla_expirado=sla_expirado,
        ordem=ordem,
        limite=limite,
        operadores=operadores,
    )


async def listar_chamados_ativos(
    client: DeskClient,
    *,
    data_criacao_de: str | None = None,
    data_criacao_ate: str | None = None,
    data_alteracao_de: str | None = None,
    data_alteracao_ate: str | None = None,
    operador: str | None = None,
    grupo: str | None = None,
    status: list[str] | None = None,
    sla_expirado: bool | None = None,
    sem_operador: bool | None = None,
    apenas_ativos: bool = True,
    limite: int = 500,
    ordem: str = "tempo_aberto_desc",
    operadores: OperadoresCache | None = None,
) -> list[ChamadoEnriquecido]:
    """Alias retrocompatível para `listar_chamados`. Mesmo contrato anterior."""
    return await listar_chamados(
        client,
        data_criacao_de=data_criacao_de,
        data_criacao_ate=data_criacao_ate,
        data_alteracao_de=data_alteracao_de,
        data_alteracao_ate=data_alteracao_ate,
        operador=operador,
        grupo=grupo,
        status=status,
        sla_expirado=sla_expirado,
        sem_operador=sem_operador,
        apenas_ativos=apenas_ativos,
        limite=limite,
        ordem=ordem,
        operadores=operadores,
    )


_DATA_ISO_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_JANELA_MAX_DIAS = 90
_PAGINA_SIZE = 500
_LIMITE_TETO = 2000


def _validar_data(valor: str | None, nome_campo: str) -> None:
    if valor is None:
        return
    if not _DATA_ISO_RE.match(valor):
        raise ValueError(
            f"{nome_campo}='{valor}' inválido — formato esperado YYYY-MM-DD"
        )
    try:
        date.fromisoformat(valor)
    except ValueError as e:
        raise ValueError(f"{nome_campo}='{valor}' não é uma data real: {e}") from e


def _validar_intervalo(de: str | None, ate: str | None, rotulo: str) -> None:
    if de and ate and de > ate:
        raise ValueError(
            f"Intervalo {rotulo} inválido: {de} > {ate} (data inicial maior que a final)"
        )


def _validar_janela_90d(de: str | None, ate: str | None, rotulo: str) -> None:
    if not (de and ate):
        return
    try:
        delta = (date.fromisoformat(ate) - date.fromisoformat(de)).days
    except ValueError:
        return
    if delta > _JANELA_MAX_DIAS:
        raise ValueError(
            f"Janela {rotulo} = {delta} dias excede o máximo de {_JANELA_MAX_DIAS} dias. "
            "Para análises históricas mais longas, use a skill datalake-metabase "
            "(tabela desk_chamadossuporte_dados)."
        )


async def listar_chamados(
    client: DeskClient,
    *,
    data_criacao_de: str | None = None,
    data_criacao_ate: str | None = None,
    data_alteracao_de: str | None = None,
    data_alteracao_ate: str | None = None,
    data_finalizacao_de: str | None = None,
    data_finalizacao_ate: str | None = None,
    operador: str | None = None,
    operador_chave: int | None = None,
    grupo: str | None = None,
    status: list[str] | None = None,
    sla_expirado: bool | None = None,
    sem_operador: bool | None = None,
    apenas_ativos: bool = True,
    limite: int = 100,
    ordem: str = "tempo_aberto_desc",
    operadores: OperadoresCache | None = None,
) -> list[ChamadoEnriquecido]:
    """Lista chamados com filtros amplos de data, operador, grupo e status.

    Suporta análises retrospectivas (via `data_finalizacao_*`) e busca por
    operador (parcial por nome ou exato por chave). Janela máxima de 90 dias
    em cada par de datas — use datalake-metabase para intervalos maiores.

    - `operador` faz match parcial case-insensitive no nome.
    - `operador_chave` faz match exato na ChaveOperador.
    - `sem_operador=True` força chamados sem atribuição.
    - Paginação interna transparente (batches de 500), teto de 2000.
    """
    _validar_data(data_criacao_de, "data_criacao_de")
    _validar_data(data_criacao_ate, "data_criacao_ate")
    _validar_data(data_alteracao_de, "data_alteracao_de")
    _validar_data(data_alteracao_ate, "data_alteracao_ate")
    _validar_data(data_finalizacao_de, "data_finalizacao_de")
    _validar_data(data_finalizacao_ate, "data_finalizacao_ate")
    _validar_intervalo(data_criacao_de, data_criacao_ate, "data_criacao")
    _validar_intervalo(data_alteracao_de, data_alteracao_ate, "data_alteracao")
    _validar_intervalo(data_finalizacao_de, data_finalizacao_ate, "data_finalizacao")
    _validar_janela_90d(data_criacao_de, data_criacao_ate, "data_criacao")
    _validar_janela_90d(data_alteracao_de, data_alteracao_ate, "data_alteracao")
    _validar_janela_90d(data_finalizacao_de, data_finalizacao_ate, "data_finalizacao")

    if apenas_ativos and (data_finalizacao_de or data_finalizacao_ate):
        logger.warning(
            "apenas_ativos=True combinado com filtro data_finalizacao — "
            "chamados ativos não têm DataFinalizacao. Considere apenas_ativos=False."
        )

    limite_efetivo = max(1, min(limite, _LIMITE_TETO))

    filtros = _montar_filtros(
        data_criacao_de=data_criacao_de,
        data_criacao_ate=data_criacao_ate,
        data_alteracao_de=data_alteracao_de,
        data_alteracao_ate=data_alteracao_ate,
        data_finalizacao_de=data_finalizacao_de,
        data_finalizacao_ate=data_finalizacao_ate,
        operador=operador,
        operador_chave=operador_chave,
        grupo=grupo,
        status=status,
        sla_expirado=sla_expirado,
        apenas_ativos=apenas_ativos,
    )

    registros = await _fetch_paginado(client, filtros, limite_efetivo)

    enriquecidos: list[ChamadoEnriquecido] = []
    for raw in registros:
        c = enriquecer_chamado(raw)
        if not _passa_filtros(
            c,
            data_criacao_de=data_criacao_de,
            data_criacao_ate=data_criacao_ate,
            data_alteracao_de=data_alteracao_de,
            data_alteracao_ate=data_alteracao_ate,
            data_finalizacao_de=data_finalizacao_de,
            data_finalizacao_ate=data_finalizacao_ate,
            operador=operador,
            operador_chave=operador_chave,
            grupo=grupo,
            status=status,
            sla_expirado=sla_expirado,
            sem_operador=sem_operador,
            apenas_ativos=apenas_ativos,
        ):
            continue
        enriquecidos.append(c)

    ordenados = ordenar_chamados(enriquecidos, ordem)[:limite_efetivo]
    return await _aplicar_presenca(ordenados, operadores)


async def _fetch_paginado(
    client: DeskClient,
    filtros: list[dict[str, Any]],
    limite_final: int,
) -> list[dict[str, Any]]:
    """Pagina transparentemente em batches de 500. Fallback sem filtros se API recusar."""
    resultado: list[dict[str, Any]] = []
    tatual = 0
    while len(resultado) < limite_final:
        body = {
            "Tatual": tatual,
            "Quantidade": _PAGINA_SIZE,
            "Filtros": filtros,
            "Ordenacao": [{"Campo": "DataCriacao", "Ordem": "DESC"}],
        }
        try:
            resposta = await client.listar("ChamadosSuporte", body)
        except Exception as e:
            logger.warning(
                "Filtros rejeitados pela API Desk — refazendo sem filtros: %s", e
            )
            resposta = await client.listar(
                "ChamadosSuporte",
                {
                    "Tatual": tatual,
                    "Quantidade": _PAGINA_SIZE,
                    "Ordenacao": [{"Campo": "DataCriacao", "Ordem": "DESC"}],
                },
            )
        lote = resposta.get("root") or []
        if not lote:
            break
        resultado.extend(lote)
        if len(lote) < _PAGINA_SIZE:
            break
        tatual += len(lote)
    return resultado


def _montar_filtros(
    *,
    data_criacao_de: str | None,
    data_criacao_ate: str | None,
    data_alteracao_de: str | None,
    data_alteracao_ate: str | None,
    data_finalizacao_de: str | None = None,
    data_finalizacao_ate: str | None = None,
    operador: str | None,
    operador_chave: int | None = None,
    grupo: str | None,
    status: list[str] | None,
    sla_expirado: bool | None,
    apenas_ativos: bool,
) -> list[dict[str, Any]]:
    filtros: list[dict[str, Any]] = []
    if apenas_ativos:
        filtros.append(
            {"Campo": "DataFinalizacao", "Valor": "0000-00-00", "Operador": "="}
        )
    if data_criacao_de:
        filtros.append(
            {"Campo": "DataCriacao", "Valor": data_criacao_de, "Operador": ">="}
        )
    if data_criacao_ate:
        filtros.append(
            {"Campo": "DataCriacao", "Valor": data_criacao_ate, "Operador": "<="}
        )
    if data_alteracao_de:
        filtros.append(
            {"Campo": "DataAlteracao", "Valor": data_alteracao_de, "Operador": ">="}
        )
    if data_alteracao_ate:
        filtros.append(
            {"Campo": "DataAlteracao", "Valor": data_alteracao_ate, "Operador": "<="}
        )
    if data_finalizacao_de:
        filtros.append(
            {"Campo": "DataFinalizacao", "Valor": data_finalizacao_de, "Operador": ">="}
        )
    if data_finalizacao_ate:
        filtros.append(
            {"Campo": "DataFinalizacao", "Valor": data_finalizacao_ate, "Operador": "<="}
        )
    if operador:
        filtros.append({"Campo": "NomeOperador", "Valor": operador, "Operador": "="})
    if operador_chave is not None:
        filtros.append(
            {"Campo": "ChaveOperador", "Valor": operador_chave, "Operador": "="}
        )
    if grupo:
        filtros.append({"Campo": "NomeGrupo", "Valor": grupo, "Operador": "="})
    if status:
        # A API aceita lista via operador IN em alguns tenants, em outros não —
        # filtro client-side garante correção.
        filtros.append({"Campo": "NomeStatus", "Valor": status, "Operador": "IN"})
    if sla_expirado is True:
        filtros.append({"Campo": "Sla1Expirado", "Valor": "S", "Operador": "="})
    return filtros


def _passa_filtros(
    c: ChamadoEnriquecido,
    *,
    data_criacao_de: str | None,
    data_criacao_ate: str | None,
    data_alteracao_de: str | None,
    data_alteracao_ate: str | None,
    data_finalizacao_de: str | None = None,
    data_finalizacao_ate: str | None = None,
    operador: str | None,
    operador_chave: int | None = None,
    grupo: str | None,
    status: list[str] | None,
    sla_expirado: bool | None,
    sem_operador: bool | None = None,
    apenas_ativos: bool,
) -> bool:
    if apenas_ativos and not c.ativo:
        return False
    if data_criacao_de and (c.data_criacao or "") < data_criacao_de:
        return False
    if data_criacao_ate and (c.data_criacao or "") > data_criacao_ate:
        return False
    if data_alteracao_de and (c.data_alteracao or "") < data_alteracao_de:
        return False
    if data_alteracao_ate and (c.data_alteracao or "") > data_alteracao_ate:
        return False
    if data_finalizacao_de:
        if not c.data_finalizacao or c.data_finalizacao < data_finalizacao_de:
            return False
    if data_finalizacao_ate:
        if not c.data_finalizacao or c.data_finalizacao > data_finalizacao_ate:
            return False
    if operador:
        # Match parcial case-insensitive — issue requer.
        alvo = operador.strip().lower()
        if alvo not in (c.operador or "").strip().lower():
            return False
    if operador_chave is not None:
        if c.operador_chave != operador_chave:
            return False
    if grupo and (c.grupo or "").strip() != grupo.strip():
        return False
    if status:
        alvos = {s.strip().lower() for s in status}
        if (c.status or "").strip().lower() not in alvos:
            return False
    if sla_expirado is True and not (c.sla1_expirado or c.sla2_expirado):
        return False
    if sla_expirado is False and (c.sla1_expirado or c.sla2_expirado):
        return False
    if sem_operador is True and (c.operador or "").strip():
        return False
    if sem_operador is False and not (c.operador or "").strip():
        return False
    return True


def _desempacotar_detalhe(detalhe: Any) -> dict[str, Any]:
    """Normaliza o payload de detalhe (que a API devolve em `{TChamado: {...}}`).

    Além do unwrap, alguns campos vêm como listas `[{id, text}]` em vez de
    strings diretas (ex.: `CodOperador`, `NomeOperador`). Achatamos para que
    o enriquecimento e presença do operador funcionem igual à listagem.
    """
    if not isinstance(detalhe, dict):
        return {}
    nucleo = detalhe.get("TChamado") if isinstance(detalhe.get("TChamado"), dict) else detalhe
    plano = dict(nucleo)

    # CodOperador = [{id, text}] → ChaveOperador(int) + NomeOperador(str)
    cod_op = plano.get("CodOperador")
    if isinstance(cod_op, list) and cod_op:
        primeiro = cod_op[0] if isinstance(cod_op[0], dict) else {}
        try:
            plano.setdefault("ChaveOperador", int(primeiro.get("id")) if primeiro.get("id") else None)
        except (TypeError, ValueError):
            pass
        if primeiro.get("text") and not plano.get("NomeOperador"):
            plano["NomeOperador"] = str(primeiro["text"]).strip()

    # Mesmo padrão para CodUsuario e CodCliente.
    cod_user = plano.get("CodUsuario")
    if isinstance(cod_user, list) and cod_user:
        primeiro = cod_user[0] if isinstance(cod_user[0], dict) else {}
        try:
            plano.setdefault("ChaveUsuario", int(primeiro.get("id")) if primeiro.get("id") else None)
        except (TypeError, ValueError):
            pass
        if primeiro.get("text") and not plano.get("NomeUsuario"):
            plano["NomeUsuario"] = str(primeiro["text"]).strip()

    # NomeStatus vem em CodStatusAtual = [{id, sequence, text}]
    cod_status = plano.get("CodStatusAtual")
    if isinstance(cod_status, list) and cod_status:
        primeiro = cod_status[0] if isinstance(cod_status[0], dict) else {}
        if primeiro.get("text") and not plano.get("NomeStatus"):
            plano["NomeStatus"] = str(primeiro["text"]).strip()

    # NomeGrupo pode estar só em CodGrupo (string) — não dá pra derivar nome.
    return plano


async def obter_chamado(
    client: DeskClient,
    *,
    chave: int,
    incluir_historico: bool = True,
    incluir_anexos: bool = False,
    operadores: OperadoresCache | None = None,
    cache: DeskCache | None = None,
    ignorar_cache: bool = False,
) -> dict[str, Any]:
    """Retorna detalhe completo de um chamado.

    Usa cache persistente (quando disponível) — finalizados têm TTL longo,
    ativos são invalidados por mudança em DataAlteracao.
    """
    usou_cache = False
    cached = None
    if cache and not ignorar_cache:
        cached = await cache.get_chamado(chave)
    if cached is not None:
        # presença do operador não cacheia — re-resolvemos para obter online atual
        enriquecido_dict = cached.get("chamado")
        if isinstance(enriquecido_dict, dict):
            enriquecido = ChamadoEnriquecido(**enriquecido_dict)
            [enriquecido] = await _aplicar_presenca([enriquecido], operadores)
            cached["chamado"] = enriquecido.model_dump()
            cached["_cache_hit"] = True
            usou_cache = True
        else:
            cached = None

    if not usou_cache:
        detalhe_raw = await client.obter("ChamadosSuporte", chave)
        detalhe = _desempacotar_detalhe(detalhe_raw)
        codigo_chamado = detalhe.get("CodChamado") or (
            detalhe_raw.get("CodChamado") if isinstance(detalhe_raw, dict) else None
        )
        enriquecido = enriquecer_chamado(detalhe)
        [enriquecido] = await _aplicar_presenca([enriquecido], operadores)

        resultado: dict[str, Any] = {
            "chamado": enriquecido.model_dump(),
            "historico": None,
            "anexos": None,
            "_cache_hit": False,
        }
    else:
        resultado = cached  # type: ignore[assignment]
        codigo_chamado = resultado.get("chamado", {}).get("codigo")

    if incluir_historico and resultado.get("historico") is None:
        try:
            resultado["historico"] = await _listar_historico_normalizado(
                client, chave=chave, codigo=codigo_chamado,
                cache=cache, ignorar_cache=ignorar_cache,
            )
        except Exception as e:
            logger.warning("Falha ao buscar histórico de %s: %s", chave, e)
            resultado["historico"] = {
                "chave": chave,
                "total": 0,
                "acoes": [],
                "erro": str(e),
            }

    if incluir_anexos and resultado.get("anexos") is None:
        try:
            anexos = await client.listar(
                "Anexos",
                {
                    "Tatual": 0,
                    "Quantidade": 100,
                    "Filtros": [
                        {"Campo": "ChaveChamado", "Valor": chave, "Operador": "="}
                    ],
                },
            )
            resultado["anexos"] = anexos.get("root") or []
        except Exception as e:
            logger.warning("Falha ao buscar anexos de %s: %s", chave, e)
            resultado["anexos"] = {"erro": str(e)}

    # Persiste no cache (apenas quando veio fresh da API e temos cache disponível).
    if cache and not usou_cache and not ignorar_cache:
        chamado_dict = resultado.get("chamado", {})
        try:
            await cache.set_chamado(
                chave,
                {"chamado": chamado_dict, "historico": None, "anexos": None},
                data_alteracao=chamado_dict.get("data_alteracao"),
                hora_alteracao=chamado_dict.get("hora_alteracao"),
                finalizado=not bool(chamado_dict.get("ativo", True)),
            )
        except Exception as e:
            logger.warning("Falha ao escrever cache de chamado %s: %s", chave, e)

    return resultado


async def listar_historico_chamado(
    client: DeskClient,
    *,
    chave: int | None = None,
    codigo: str | None = None,
    limite_texto: int | None = None,
    incluir_raw: bool = False,
    cache: DeskCache | None = None,
    ignorar_cache: bool = False,
) -> dict[str, Any]:
    """Retorna o histórico normalizado de um chamado.

    Aceita a `chave` numérica OU o `codigo` string (CodChamado, ex.
    "0426-011564"). Quando só a chave é passada, o CodChamado é resolvido
    internamente. Textos longos são dumpados em arquivo — o response mantém
    só um preview + `texto_arquivo` com o caminho. Usa cache persistente
    quando disponível (invalidado pela DataAlteracao do chamado).
    """
    return await _listar_historico_normalizado(
        client,
        chave=chave,
        codigo=codigo,
        limite_texto=limite_texto,
        incluir_raw=incluir_raw,
        cache=cache,
        ignorar_cache=ignorar_cache,
    )


async def buscar_chamados_similares(
    client: DeskClient,
    *,
    texto_busca: str,
    apenas_resolvidos: bool = True,
    limite: int = 10,
    periodo_dias: int = 180,
    operadores: OperadoresCache | None = None,
) -> list[ChamadoEnriquecido]:
    """Busca chamados cujo Assunto contém o texto fornecido."""
    texto = (texto_busca or "").strip()
    if not texto:
        return []

    filtros: list[dict[str, Any]] = [
        {"Campo": "Assunto", "Valor": texto, "Operador": "CONTEM"},
    ]
    if apenas_resolvidos:
        filtros.append(
            {"Campo": "DataFinalizacao", "Valor": "0000-00-00", "Operador": "<>"}
        )

    body = {
        "Tatual": 0,
        "Quantidade": max(limite * 5, 100),
        "Filtros": filtros,
        "Ordenacao": [{"Campo": "DataFinalizacao", "Ordem": "DESC"}],
    }

    try:
        resposta = await client.listar("ChamadosSuporte", body)
        registros = resposta.get("root") or []
    except Exception as e:
        logger.warning("Busca com filtros falhou, refazendo client-side: %s", e)
        resposta = await client.listar(
            "ChamadosSuporte",
            {
                "Tatual": 0,
                "Quantidade": 3000,
                "Ordenacao": [{"Campo": "DataFinalizacao", "Ordem": "DESC"}],
            },
        )
        registros = resposta.get("root") or []

    texto_lower = texto.lower()
    enriquecidos: list[ChamadoEnriquecido] = []
    for raw in registros:
        c = enriquecer_chamado(raw)
        if texto_lower not in (c.assunto or "").lower():
            continue
        if apenas_resolvidos and c.ativo:
            continue
        enriquecidos.append(c)
        if len(enriquecidos) >= limite:
            break
    return await _aplicar_presenca(enriquecidos, operadores)
