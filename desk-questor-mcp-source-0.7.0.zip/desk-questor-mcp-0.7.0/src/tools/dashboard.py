"""Dashboard N3 — agregados para o agent decidir onde focar."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta

from ..desk_client import DeskClient
from ..enrichment import BRT, enriquecer_chamado, ordenar_chamados
from ..models import ChamadoEnriquecido, DashboardN3
from ..operadores_cache import OperadoresCache


async def dashboard_n3(
    client: DeskClient, operadores: OperadoresCache | None = None
) -> DashboardN3:
    """Agrega todos os chamados ativos de hoje em métricas úteis para N3."""
    hoje = datetime.now(BRT).date().isoformat()

    resposta = await client.listar(
        "ChamadosSuporte",
        {
            "Tatual": 0,
            "Quantidade": 3000,
            "Ordenacao": [{"Campo": "DataCriacao", "Ordem": "DESC"}],
        },
    )
    registros = resposta.get("root") or []

    ativos: list[ChamadoEnriquecido] = []
    for raw in registros:
        c = enriquecer_chamado(raw)
        if not c.ativo:
            continue
        if c.data_criacao != hoje:
            continue
        ativos.append(c)

    por_grupo = Counter((c.grupo or "—") for c in ativos)

    sla1_expirando_2h = 0
    for c in ativos:
        restante = c.tempo_restante_sla1
        if not restante:
            continue
        try:
            sinal = 1
            s = restante
            if s.startswith("-"):
                sinal = -1
                s = s[1:]
            hh, mm, *_ = s.split(":")
            td = sinal * timedelta(hours=int(hh), minutes=int(mm))
            if timedelta(0) < td <= timedelta(hours=2):
                sla1_expirando_2h += 1
        except (ValueError, AttributeError):
            continue

    sem_atribuicao = sum(
        1 for c in ativos if not (c.operador and c.operador.strip())
    )

    top_sem_resposta = ordenar_chamados(ativos, "sem_resposta_desc")[:10]

    if operadores is not None:
        for c in top_sem_resposta:
            chave_op = c.raw.get("ChaveOperador") if isinstance(c.raw, dict) else None
            info = await operadores.resolver(nome=c.operador, chave=chave_op)
            if info:
                c.operador_chave = info.get("chave")
                c.operador_online = info.get("online")
                c.operador_grupo_principal = info.get("grupo_principal")

    return DashboardN3(
        total_ativos=len(ativos),
        por_grupo=dict(por_grupo),
        sla1_expirando_2h=sla1_expirando_2h,
        sem_atribuicao=sem_atribuicao,
        top_sem_resposta=top_sem_resposta,
        gerado_em=datetime.now(BRT).isoformat(),
    )
