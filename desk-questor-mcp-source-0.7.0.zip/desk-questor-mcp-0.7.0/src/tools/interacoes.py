"""Tools de escrita em chamados (comentar, atualizar status)."""

from __future__ import annotations

import logging
from typing import Any

from ..desk_client import DeskClient

logger = logging.getLogger("desk-questor-mcp.tools.interacoes")


async def comentar_chamado(
    client: DeskClient,
    *,
    chave: int,
    texto: str,
    publico: bool = False,
) -> dict[str, Any]:
    """Posta um comentário/ação no chamado.

    `publico=False` → comentário interno (default), não aparece para o cliente.
    """
    if not texto or not texto.strip():
        raise ValueError("texto do comentário não pode ser vazio")

    body = {
        "ChaveChamado": chave,
        "Descricao": texto.strip(),
        "Publico": "S" if publico else "N",
    }

    # Tenta padrões conhecidos em ordem de probabilidade.
    ultimo_erro: Exception | None = None
    for entidade, acao in (
        ("ChamadosSuporte", "Comentar"),
        ("Acoes", None),
        ("ChamadosSuporte", "Acao"),
    ):
        try:
            resposta = await client.post(entidade, body, acao=acao)
            return {
                "status": "ok",
                "chave_chamado": chave,
                "publico": publico,
                "endpoint_usado": f"{entidade}/{acao}" if acao else entidade,
                "resposta": resposta,
            }
        except Exception as e:
            logger.debug("Comentar via %s/%s falhou: %s", entidade, acao, e)
            ultimo_erro = e
            continue
    raise RuntimeError(f"Falha ao comentar chamado {chave}: {ultimo_erro}")


async def atualizar_status_chamado(
    client: DeskClient,
    *,
    chave: int,
    novo_status: str,
    comentario: str | None = None,
) -> dict[str, Any]:
    """Muda status do chamado, opcionalmente com comentário."""
    if not novo_status or not novo_status.strip():
        raise ValueError("novo_status não pode ser vazio")

    body: dict[str, Any] = {
        "Chave": chave,
        "NomeStatus": novo_status.strip(),
    }
    if comentario and comentario.strip():
        body["Descricao"] = comentario.strip()

    ultimo_erro: Exception | None = None
    for entidade, acao in (
        ("ChamadosSuporte", "AtualizarStatus"),
        ("ChamadosSuporte", "Status"),
        ("ChamadosSuporte", None),
    ):
        try:
            resposta = await client.post(entidade, body, acao=acao)
            return {
                "status": "ok",
                "chave_chamado": chave,
                "novo_status": novo_status,
                "endpoint_usado": f"{entidade}/{acao}" if acao else entidade,
                "resposta": resposta,
            }
        except Exception as e:
            logger.debug("AtualizarStatus via %s/%s falhou: %s", entidade, acao, e)
            ultimo_erro = e
            continue
    raise RuntimeError(f"Falha ao atualizar status de {chave}: {ultimo_erro}")
