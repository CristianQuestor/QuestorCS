"""Tools de monitoramento de chat ao vivo via Ably.

Complementa a tool `listar_historico_chamado` (que só devolve sessões de chat
já encerradas) — permite acompanhar mensagens de uma conversa **enquanto ela
está acontecendo**, antes de ser consolidada em `/ChamadoHistoricos`.

Por baixo usa o canal Ably do tenant (único canal "questor"), filtra pelo par
(`ChaveUsuario`, `ChaveOperador`) do chamado e devolve as msgs cronológicas.
"""
from __future__ import annotations

import logging
from typing import Any

from .. import ably_chat
from ..desk_client import DeskClient
from ..enrichment import enriquecer_chamado

logger = logging.getLogger("desk-questor-mcp.tools.chat")


def _desempacotar_detalhe(detalhe: Any) -> dict[str, Any]:
    """Mesma lógica de chamados.py: unwrap TChamado e achata arrays `[{id, text}]`.

    Importamos local pra evitar ciclo de import.
    """
    from .chamados import _desempacotar_detalhe as _impl
    return _impl(detalhe)


async def escutar_chat_chamado(
    client: DeskClient,
    *,
    chave: int,
    duracao_segundos: float = 30,
    incluir_typing: bool = False,
) -> dict[str, Any]:
    """Escuta o Ably por `duracao_segundos` e retorna mensagens de chat desse chamado.

    Resolve o par (ChaveUsuario, ChaveOperador) consultando o detalhe do
    chamado, e filtra o firehose do canal pra devolver só o que bate.

    Notas:
    - Se o chamado não tem operador atribuído, devolvemos apenas por
      `ChaveUsuario` (o que pode pegar mensagens de outro chamado aberto
      com o mesmo cliente).
    - Mensagens só chegam enquanto alguém está digitando/enviando — se o
      chat estiver silencioso nos `duracao_segundos`, retorna lista vazia.
    - `incluir_typing=True` inclui os eventos "Ocultar" (indicador de
      digitação), normalmente ruidosos.
    """
    # 1) Detalhe do chamado pra pegar ChaveUsuario + ChaveOperador
    detalhe_raw = await client.obter("ChamadosSuporte", chave)
    detalhe = _desempacotar_detalhe(detalhe_raw)
    c = enriquecer_chamado(detalhe)

    cod_usuario: int | None = None
    chave_operador: int | None = None

    # ChaveUsuario é o id do cliente; ChaveOperador o do atendente atual.
    raw = c.raw if hasattr(c, "raw") else None
    if isinstance(raw, dict):
        try:
            if raw.get("ChaveUsuario") is not None:
                cod_usuario = int(raw["ChaveUsuario"])
        except (TypeError, ValueError):
            pass
        try:
            if raw.get("ChaveOperador") is not None:
                chave_operador = int(raw["ChaveOperador"])
        except (TypeError, ValueError):
            pass
    if chave_operador is None and getattr(c, "operador_chave", None):
        chave_operador = c.operador_chave

    logger.info("escutar_chat_chamado: chave=%s cod_usuario=%s chave_operador=%s duracao=%.1fs",
                chave, cod_usuario, chave_operador, duracao_segundos)

    # 2) Escuta Ably pelo tempo pedido
    mensagens = await ably_chat.escutar_chat(
        duracao_segundos,
        cod_usuario=cod_usuario,
        chave_operador=chave_operador,
        incluir_typing=incluir_typing,
    )

    return {
        "chave": chave,
        "codigo": getattr(c, "codigo", None),
        "cliente": getattr(c, "cliente_nome_completo", None),
        "operador": getattr(c, "operador", None),
        "cod_usuario": cod_usuario,
        "chave_operador": chave_operador,
        "duracao_segundos": duracao_segundos,
        "total": len(mensagens),
        "mensagens": mensagens,
        "nota": (
            "Sem operador atribuído — filtro só por cliente. "
            "Mensagens podem vir de outro chamado aberto com o mesmo cliente."
            if chave_operador is None else None
        ),
    }


async def escutar_chat_global(
    duracao_segundos: float = 15,
    *,
    cod_usuario: int | None = None,
    chave_operador: int | None = None,
    incluir_typing: bool = False,
) -> dict[str, Any]:
    """Escuta o Ably sem resolver chamado — útil pra dashboard e debug.

    Quando `cod_usuario` e/ou `chave_operador` são fornecidos, filtra.
    Sem filtros = todo chat do tenant (pode ser centenas de msgs por minuto).
    """
    mensagens = await ably_chat.escutar_chat(
        duracao_segundos,
        cod_usuario=cod_usuario,
        chave_operador=chave_operador,
        incluir_typing=incluir_typing,
    )
    return {
        "duracao_segundos": duracao_segundos,
        "filtros": {"cod_usuario": cod_usuario, "chave_operador": chave_operador},
        "total": len(mensagens),
        "mensagens": mensagens,
    }
