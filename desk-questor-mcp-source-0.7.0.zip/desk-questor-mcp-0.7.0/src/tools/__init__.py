"""Módulos de tools do desk-questor-mcp."""
