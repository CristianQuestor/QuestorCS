"""Tools para catálogos (grupos, operadores, status, categorias)."""

from __future__ import annotations

from typing import Any

from ..desk_client import DeskClient
from ..operadores_cache import OperadoresCache


async def listar_grupos(client: DeskClient) -> list[dict[str, Any]]:
    resposta = await client.listar("GrupoEmpresas", {"Tatual": 0, "Quantidade": 500})
    return resposta.get("root") or []


async def listar_operadores(
    client: DeskClient,
    *,
    apenas_ativos: bool = True,
    cache: OperadoresCache | None = None,
) -> list[dict[str, Any]]:
    body: dict[str, Any] = {"Tatual": 0, "Quantidade": 1000}
    if apenas_ativos:
        body["Filtros"] = [{"Campo": "Ativo", "Valor": "S", "Operador": "="}]
    try:
        resposta = await client.listar("Operadores", body)
    except Exception:
        resposta = await client.listar(
            "Operadores", {"Tatual": 0, "Quantidade": 1000}
        )
    registros = resposta.get("root") or []
    if apenas_ativos:
        registros = [r for r in registros if str(r.get("Ativo", "S")).upper() == "S"]

    # Força refresh do cache oportunisticamente (mesma chamada)
    if cache is not None:
        try:
            await cache.snapshot()
        except Exception:
            pass
    return registros


async def listar_status(client: DeskClient) -> list[dict[str, Any]]:
    resposta = await client.listar("Status", {"Tatual": 0, "Quantidade": 200})
    return resposta.get("root") or []


async def listar_categorias(client: DeskClient) -> list[dict[str, Any]]:
    resposta = await client.listar("Categorias", {"Tatual": 0, "Quantidade": 1000})
    return resposta.get("root") or []
