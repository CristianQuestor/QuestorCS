"""Cliente Ably para escutar o canal de chat do Desk Manager em tempo real.

O Desk Manager usa Ably (WebSocket pub-sub) para entregar as mensagens de chat
**ao vivo** para a UI do operador. As mensagens só entram no endpoint REST
`/ChamadoHistoricos` quando a sessão é encerrada — até lá, só via Ably.

## Descoberta do endpoint

Fonte: bundle JS `https://dqnkcwgy21udk.cloudfront.net/view/21562/js/Controller.min.js`

```js
var e = new Ably.Realtime("FzTjhQ.Pcf0RA:uHz5r1xRJTpn5_n_");
channelRT = e.channels.get(glbPrefixo);  // "questor" no nosso tenant
channelRT.subscribe(function(o) { ... });
```

A chave é hardcoded no JS e aceita subscribe sem auth adicional — basta criar
um `AblyRealtime(key)` e pegar o canal `"questor"`.

## Esquema do payload (evento `name == "chat"`)

Três sub-tipos distinguidos por flag:

- `Criar: "true"`  → **cliente** manda mensagem para o operador
- `Alerta: "true"` → **operador** manda mensagem para o cliente (inclui bots
                      de timeout, "aguardamos seu retorno", etc.)
- `Ocultar: "true"` → indicador de "digitando" (ruído, geralmente descartamos)

Campos comuns (quando `Criar` ou `Alerta`):

```json
{
  "Criar": "true" | "Alerta": "true",
  "Msg": "texto da mensagem (pode conter HTML <br>, imagens markdown)",
  "NomeCompleto": "quem está enviando",
  "CodUsuario": "85187",               // SEMPRE o cliente (dono da conversa)
  "AlertaOpers": "786,0",              // operador(es) envolvidos, separados por vírgula
  "SMS": "email@cliente.com" | "0",
  "DH": "2026-04-24 10:13:19"          // data/hora da msg (nem sempre presente)
}
```

Outros nomes de evento vistos no canal (não processados por default):
`dms` (atualização de grid), `ai` / `airesume` (chamadas IA).

## Identificação do chamado

O payload **não traz** `CodChamado` — para associar uma mensagem a um chamado
específico, fazemos o join (`CodUsuario`, primeiro valor de `AlertaOpers`)
contra os chamados ativos. Um mesmo par (cliente, operador) pode ter múltiplos
chamados abertos simultaneamente — nesse caso retornamos todas as msgs do par
e deixamos o agente desambiguar pelo conteúdo.
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from typing import Any

try:
    from ably import AblyRealtime
except ImportError as _e:  # pragma: no cover
    AblyRealtime = None  # type: ignore
    _ABLY_IMPORT_ERROR = _e
else:
    _ABLY_IMPORT_ERROR = None

logger = logging.getLogger("desk-questor-mcp.ably")

# Chave hardcoded no bundle JS da UI do Desk — Controller.min.js/Library.min.js.
# É uma chave Ably de app pública (FzTjhQ) com permissão de subscribe no canal
# do tenant. Não expõe nada que o operador logado não veja naturalmente.
ABLY_KEY = "FzTjhQ.Pcf0RA:uHz5r1xRJTpn5_n_"

# Nome do canal = prefixo do tenant (glbPrefixo no JS). Pra Questor: "questor".
CANAL_DEFAULT = "questor"


class AblyNaoDisponivel(RuntimeError):
    """Pacote `ably` não está instalado."""


def _parse_alerta_opers(valor: Any) -> list[int]:
    """`AlertaOpers` vem como string "786,0,123" — devolve lista de ints != 0.

    O primeiro valor costuma ser o operador principal; os demais são
    acompanhantes (supervisores, auditores). Ignoramos zeros porque são
    placeholders de "sem operador".
    """
    if valor is None:
        return []
    if isinstance(valor, (int, float)):
        return [int(valor)] if valor else []
    if isinstance(valor, str):
        resultado = []
        for parte in valor.split(","):
            parte = parte.strip()
            if not parte:
                continue
            try:
                v = int(parte)
            except ValueError:
                continue
            if v:
                resultado.append(v)
        return resultado
    return []


def classificar_msg(dados: dict[str, Any]) -> str | None:
    """Retorna o tipo da mensagem de chat: 'cliente', 'operador' ou 'typing'.

    Devolve `None` se não for uma mensagem de chat reconhecida (ex.: payload
    de evento que não é `chat`, ou flags ausentes).
    """
    if dados.get("Criar") == "true":
        return "cliente"
    if dados.get("Alerta") == "true":
        return "operador"
    if dados.get("Ocultar") == "true":
        return "typing"
    return None


def normalizar_msg(dados: dict[str, Any], recebida_em: datetime) -> dict[str, Any]:
    """Converte payload cru do Ably em registro normalizado."""
    tipo = classificar_msg(dados)
    return {
        "tipo": tipo,  # 'cliente' | 'operador' | 'typing' | None
        "nome_emissor": dados.get("NomeCompleto"),
        "cod_usuario_cliente": dados.get("CodUsuario"),
        "operadores_envolvidos": _parse_alerta_opers(dados.get("AlertaOpers")),
        "texto": dados.get("Msg"),
        "email_cliente": dados.get("SMS") if dados.get("SMS") != "0" else None,
        "dh_mensagem": dados.get("DH"),  # da UI do Desk
        "dh_recebida": recebida_em.isoformat(timespec="seconds"),
        "raw": dados,
    }


def msg_pertence_ao_par(msg: dict[str, Any], *, cod_usuario: int | None,
                         chave_operador: int | None) -> bool:
    """Filtra se a mensagem pertence à conversa entre esse cliente e esse operador.

    Se algum dos filtros for None, ignora esse critério. Vazio em ambos os
    lados → aceita tudo.
    """
    if cod_usuario is not None:
        try:
            if int(msg.get("cod_usuario_cliente") or 0) != int(cod_usuario):
                return False
        except (TypeError, ValueError):
            return False
    if chave_operador is not None:
        opers = msg.get("operadores_envolvidos") or []
        if int(chave_operador) not in opers:
            return False
    return True


async def escutar_chat(
    duracao_segundos: float,
    *,
    cod_usuario: int | None = None,
    chave_operador: int | None = None,
    incluir_typing: bool = False,
    key: str = ABLY_KEY,
    canal: str = CANAL_DEFAULT,
) -> list[dict[str, Any]]:
    """Conecta ao Ably por `duracao_segundos` e retorna msgs recebidas.

    Filtros aplicados: se `cod_usuario` ou `chave_operador` são informados,
    descarta mensagens que não batem. `incluir_typing=False` descarta os
    eventos de "digitando" (Ocultar), que poluem muito.

    Retorna cronológico (ordem de chegada). Conexão é fechada ao final.
    """
    if AblyRealtime is None:
        raise AblyNaoDisponivel(
            "Pacote 'ably' não instalado. Rode: pip install ably"
        ) from _ABLY_IMPORT_ERROR

    duracao = max(1.0, min(float(duracao_segundos), 600.0))  # clamp 1s–10min
    coletadas: list[dict[str, Any]] = []

    def on_message(msg):
        if msg.name != "chat":
            return
        recebida_em = datetime.now()
        payload = msg.data
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except json.JSONDecodeError:
                return
        if not isinstance(payload, dict):
            return
        registro = normalizar_msg(payload, recebida_em)
        if registro["tipo"] is None:
            return
        if registro["tipo"] == "typing" and not incluir_typing:
            return
        if not msg_pertence_ao_par(registro, cod_usuario=cod_usuario,
                                     chave_operador=chave_operador):
            return
        coletadas.append(registro)

    realtime = AblyRealtime(key)
    try:
        channel = realtime.channels.get(canal)
        await channel.subscribe(on_message)
        logger.info("Ably: inscrito em %r por %.1fs (usuario=%s operador=%s)",
                    canal, duracao, cod_usuario, chave_operador)
        await asyncio.sleep(duracao)
    finally:
        try:
            await realtime.close()
        except Exception:
            pass  # close errors não interessam

    logger.info("Ably: coletadas %d mensagens", len(coletadas))
    return coletadas
