"""Histórico de ações (ChamadoHistoricos) do Desk Manager.

Contrato canônico — confirmado pelo fonte do coletor oficial
(`D:\\RepositoryH\\coletordados` / HubtechData):

    POST https://api.desk.ms/ChamadoHistoricos/lista
    Authorization: <token de /Login/autenticar>
    Content-Type: application/json
    Body: {
        "Chave": "<chave-do-chamado-como-string>",
        "Solicitante": "N",
        "Colunas": { "Chave":"on", "Descricao":"on", ... }
    }

Resposta: `{"root": [...], "total": "N"}` — cada item traz `Operador`,
`Solicitante` e `CodCausa` como arrays de `{id, text}`, além de `Status`
como array de `{id, sequence, text}`.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from .desk_cache import DeskCache
from .desk_client import DeskAPIError, DeskAuthError, DeskClient

logger = logging.getLogger("desk-questor-mcp.historico")

# Limite default de caracteres por ação. Textos maiores são salvos em arquivo
# e substituídos por um preview no response para não inundar o contexto do agent.
LIMITE_TEXTO_DEFAULT = 2000


def _cache_dir() -> Path:
    raiz = os.environ.get("DESK_HISTORICO_CACHE_DIR")
    if raiz:
        base = Path(raiz)
    else:
        base = Path(__file__).resolve().parent.parent / "cache" / "historico"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _escrever_texto_longo(chave: int, sequencia: int, texto: str) -> str:
    destino = _cache_dir() / str(chave)
    destino.mkdir(parents=True, exist_ok=True)
    arquivo = destino / f"acao_{sequencia:04d}.txt"
    arquivo.write_text(texto, encoding="utf-8")
    return str(arquivo)


def _parse_publico(valor: Any) -> bool:
    if isinstance(valor, bool):
        return valor
    if isinstance(valor, (int, float)):
        return bool(valor)
    if isinstance(valor, str):
        v = valor.strip().upper()
        if v in ("S", "SIM", "TRUE", "1", "PUBLICO", "PÚBLICO"):
            return True
        if v in ("N", "NAO", "NÃO", "FALSE", "0", "INTERNO", "PRIVADO"):
            return False
    return False


# Formas de atendimento (NomeFormaAtendimento) que implicam resposta pública ao
# cliente. Usado como fallback quando o response do `/listaCustom` não traz a
# flag explícita `Aberto` (a coluna "Publica" não é exportável nesse endpoint).
_FORMAS_PUBLICAS = {"chat", "e-mail", "email", "telefone", "whatsapp",
                     "portal", "formulário", "formulario"}
_FORMAS_INTERNAS = {"interno", "nota interna", "particular",
                     "comentário interno", "comentario interno"}


def _derivar_publico_de_forma(item: dict[str, Any]) -> bool | None:
    forma = item.get("NomeFormaAtendimento")
    if not isinstance(forma, str) or not forma.strip():
        return None
    f = forma.strip().lower()
    if f in _FORMAS_PUBLICAS:
        return True
    if f in _FORMAS_INTERNAS:
        return False
    return None


def _combinar_data_hora(data: Any, hora: Any) -> str | None:
    if not data:
        return None
    d = str(data).strip()
    if d in ("", "0000-00-00"):
        return None
    h = ""
    if hora:
        h = str(hora).strip()
    if not h:
        h = "00:00:00"
    if " " in d and len(d) >= 10:
        return d
    return f"{d} {h}"


def _texto_de_array(valor: Any) -> str | None:
    """Extrai o `text` do primeiro elemento de arrays como `[{id, text}]`."""
    if isinstance(valor, list) and valor:
        first = valor[0]
        if isinstance(first, dict):
            txt = first.get("text") or first.get("Nome") or first.get("name")
            if txt:
                return str(txt).strip() or None
        elif isinstance(first, str):
            return first.strip() or None
    return None


def _detectar_tipo(item: dict[str, Any], publico: bool) -> str:
    for campo in ("Tipo", "TipoAcao", "NomeTipo", "DescricaoTipo", "Natureza"):
        valor = item.get(campo)
        if valor and isinstance(valor, str):
            return valor.strip()
    forma = item.get("NomeFormaAtendimento")
    if forma and isinstance(forma, str):
        return forma.strip()
    return "Resposta Pública" if publico else "Comentário Interno"


def _extrair_texto(item: dict[str, Any]) -> str:
    for campo in ("Descricao", "Texto", "Mensagem", "Conteudo", "Comentario"):
        valor = item.get(campo)
        if valor:
            return str(valor)
    return ""


def _extrair_operador(item: dict[str, Any]) -> str | None:
    texto = _texto_de_array(item.get("Operador"))
    if texto:
        return texto
    for campo in (
        "NomeOperador",
        "NomeUsuarioOperador",
        "NomeAutor",
        "Autor",
    ):
        valor = item.get(campo)
        if valor and isinstance(valor, str):
            return valor.strip() or None
    valor = item.get("Operador")
    if isinstance(valor, str):
        return valor.strip() or None
    return None


def _extrair_solicitante(item: dict[str, Any]) -> str | None:
    texto = _texto_de_array(item.get("Solicitante"))
    if texto:
        return texto
    valor = item.get("Solicitante")
    if isinstance(valor, str) and valor.strip() not in ("S", "N", ""):
        return valor.strip()
    return None


def _extrair_status(item: dict[str, Any]) -> dict[str, str] | None:
    # Formato listaCustom (UI) — flat
    nome = item.get("NomeStatus")
    if isinstance(nome, str) and nome.strip():
        return {
            "id": "",
            "sequence": str(item.get("CodStatus") or "").strip(),
            "text": nome.strip(),
        }
    # Formato /lista (coletor legado) — array `[{id, sequence, text}]`
    status = item.get("Status")
    if isinstance(status, list) and status:
        first = status[0]
        if isinstance(first, dict):
            return {
                "id": str(first.get("id") or ""),
                "sequence": str(first.get("sequence") or ""),
                "text": str(first.get("text") or "").strip(),
            }
    if isinstance(status, str) and status.strip():
        return {"id": "", "sequence": "", "text": status.strip()}
    return None


def _extrair_anexos(item: dict[str, Any]) -> list[Any]:
    for campo in ("Anexos", "TotalAnexosAcao", "AnexosAcao"):
        valor = item.get(campo)
        if isinstance(valor, list):
            return valor
    return []


def _extrair_sequencia(item: dict[str, Any], fallback: int) -> int:
    for campo in ("Sequencia", "NumeroAcao", "Ordem"):
        valor = item.get(campo)
        try:
            if valor is not None:
                return int(valor)
        except (TypeError, ValueError):
            continue
    return fallback


def normalizar_item(item: dict[str, Any], *, sequencia_default: int) -> dict[str, Any]:
    # "Aberto" no Desk costuma ser flag S/N que indica resposta pública.
    # Prioridade: Aberto → Publico/EhPublico/Publicado → derivado de
    # NomeFormaAtendimento (quando veio via /listaCustom que não exporta flag).
    publico_raw = (
        item.get("Aberto")
        if item.get("Aberto") is not None
        else item.get("Publico", item.get("EhPublico", item.get("Publicado")))
    )
    if publico_raw is not None:
        publico = _parse_publico(publico_raw)
    else:
        derivado = _derivar_publico_de_forma(item)
        publico = derivado if derivado is not None else True
    data_hora = (
        _combinar_data_hora(item.get("DataAcao"), item.get("HoraAcaoInicio"))
        or _combinar_data_hora(item.get("Data"), item.get("Hora"))
        or _combinar_data_hora(item.get("DataAcao"), item.get("HoraAcao"))
        or _combinar_data_hora(item.get("DataCriacao"), item.get("HoraCriacao"))
    )
    return {
        "sequencia": _extrair_sequencia(item, sequencia_default),
        "data_hora": data_hora,
        "operador": _extrair_operador(item),
        "solicitante": _extrair_solicitante(item),
        "status": _extrair_status(item),
        "tipo": _detectar_tipo(item, publico),
        "publico": publico,
        "texto": _extrair_texto(item),
        "anexos": _extrair_anexos(item),
        "hora_inicio": item.get("HoraAcaoInicio"),
        "hora_fim": item.get("HoraAcaoFim"),
        "total_horas": item.get("TotalHoras"),
        "raw": item,
    }


def _ordenar(acoes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def key(a: dict[str, Any]) -> tuple:
        return (a.get("data_hora") or "", a.get("sequencia") or 0)

    return sorted(acoes, key=key)


async def _resolver_chave(client: DeskClient, codigo: str) -> int | None:
    """Busca a Chave numérica a partir de um CodChamado (ex.: `0426-011564`).

    A API do Desk usa `Pesquisa` como texto livre para filtrar; filtros
    estruturados via `Filtros` não fazem match exato por CodChamado. Por
    isso buscamos e filtramos no cliente.
    """
    try:
        resposta = await client.listar(
            "ChamadosSuporte",
            {"Tatual": 0, "Quantidade": 50, "Pesquisa": codigo},
        )
    except Exception as e:
        logger.debug("Falha ao resolver Chave de %s: %s", codigo, e)
        return None
    registros = resposta.get("root") if isinstance(resposta, dict) else None
    if not isinstance(registros, list):
        return None
    alvo = str(codigo).strip()
    for r in registros:
        if isinstance(r, dict) and str(r.get("CodChamado") or "").strip() == alvo:
            chave = r.get("Chave")
            try:
                return int(chave) if chave is not None else None
            except (TypeError, ValueError):
                return None
    return None


async def listar_historico(
    client: DeskClient,
    *,
    chave: int | None = None,
    codigo: str | None = None,
    limite_texto: int | None = None,
    incluir_raw: bool = False,
    cache: DeskCache | None = None,
    ignorar_cache: bool = False,
) -> dict[str, Any]:
    """Retorna histórico normalizado.

    Aceita `chave` (int, campo `Chave` da API) OU `codigo` (CodChamado).
    Se apenas `codigo` vier, resolve a Chave internamente.

    Textos longos (> `limite_texto`) são salvos em arquivo e substituídos
    por um preview + `texto_arquivo` no response. Passe `limite_texto=0`
    para nunca truncar.

    Cache: quando `cache` é fornecido, tenta servir do SQLite antes de bater
    na API. Invalidado pela `DataAlteracao` do chamado (obtida via listagem
    rápida de 1 registro) — se mudou, refetcha. Passe `ignorar_cache=True`
    para forçar refresh.
    """
    if chave is None and not codigo:
        raise ValueError("Informe pelo menos chave ou codigo do chamado")

    if chave is None and codigo:
        chave = await _resolver_chave(client, codigo)
        if chave is None:
            raise RuntimeError(
                f"Não consegui resolver Chave para codigo={codigo}. "
                "Passe 'chave' explicitamente."
            )

    # Otimização: se o cache for fresh (<60s), serve direto sem snapshot.
    # Caso contrário, faz snapshot pra validar invalidação por DataAlteracao.
    data_alt: str | None = None
    hora_alt: str | None = None
    finalizado: bool = False
    pode_servir_direto = False
    if cache and not ignorar_cache:
        pode_servir_direto = await cache.historico_esta_fresh(chave, janela_segundos=60)

    if cache is not None and not pode_servir_direto:
        info = await _snapshot_chamado(client, chave)
        if info is not None:
            data_alt, hora_alt, finalizado = info

    if cache and not ignorar_cache:
        cached = await cache.get_historico(
            chave,
            data_alteracao_atual=data_alt,
            hora_alteracao_atual=hora_alt,
        )
        if cached is not None:
            cached["_cache_hit"] = True
            return cached

    try:
        resposta = await client.listar_historico_chamado(chave)
    except (DeskAPIError, DeskAuthError) as e:
        raise RuntimeError(
            f"ChamadoHistoricos/lista falhou para chave={chave}: {e}"
        ) from e

    limite = LIMITE_TEXTO_DEFAULT if limite_texto is None else limite_texto
    registros = resposta.get("root") or []
    acoes = [
        normalizar_item(item, sequencia_default=i + 1)
        for i, item in enumerate(registros)
        if isinstance(item, dict)
    ]
    acoes_ordenadas = _ordenar(acoes)
    for i, a in enumerate(acoes_ordenadas, start=1):
        if not a.get("sequencia"):
            a["sequencia"] = i
        if not incluir_raw:
            a.pop("raw", None)
        _aplicar_limite_texto(a, chave=chave, limite=limite)

    resultado = {
        "chave": chave,
        "codigo": codigo,
        "total": len(acoes_ordenadas),
        "acoes": acoes_ordenadas,
        "endpoint": "ChamadoHistoricos",
        "_cache_hit": False,
    }

    if cache and not ignorar_cache:
        try:
            await cache.set_historico(
                chave,
                resultado,
                data_alteracao_chamado=data_alt,
                hora_alteracao_chamado=hora_alt,
                finalizado=finalizado,
            )
        except Exception as e:
            logger.warning("Falha ao escrever cache de histórico %s: %s", chave, e)

    return resultado


async def _snapshot_chamado(
    client: DeskClient, chave: int
) -> tuple[str | None, str | None, bool] | None:
    """Retorna (DataAlteracao, HoraAlteracao, finalizado) do chamado.

    Usado pelo cache para detectar mudanças — uma lista de 1 registro é bem
    barata e já traz os campos necessários.
    """
    try:
        resposta = await client.listar(
            "ChamadosSuporte",
            {
                "Tatual": 0,
                "Quantidade": 1,
                "Filtros": [{"Campo": "Chave", "Valor": chave, "Operador": "="}],
            },
        )
    except Exception as e:
        logger.debug("Snapshot de chamado %s falhou: %s", chave, e)
        return None
    registros = resposta.get("root") if isinstance(resposta, dict) else None
    if not registros:
        return None
    r = registros[0] if isinstance(registros[0], dict) else {}
    data_final = r.get("DataFinalizacao") or "0000-00-00"
    finalizado = str(data_final).strip() not in ("", "0000-00-00")
    return r.get("DataAlteracao"), r.get("HoraAlteracao"), finalizado


def _aplicar_limite_texto(acao: dict[str, Any], *, chave: int, limite: int) -> None:
    texto = acao.get("texto") or ""
    if limite <= 0 or len(texto) <= limite:
        acao["texto_truncado"] = False
        return
    caminho = _escrever_texto_longo(chave, acao["sequencia"], texto)
    acao["texto"] = texto[:limite] + "…[truncado]"
    acao["texto_truncado"] = True
    acao["texto_arquivo"] = caminho
    acao["texto_tamanho_original"] = len(texto)
