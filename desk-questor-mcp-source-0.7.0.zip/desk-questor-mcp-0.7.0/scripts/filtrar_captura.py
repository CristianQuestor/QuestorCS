"""Filtra a captura de rede pelos requests mais interessantes."""
import json
import re
from pathlib import Path

IN = Path(__file__).parent / "captura_chat.json"
data = json.loads(IN.read_text(encoding="utf-8"))

# Palavras-chave no URL que interessam
RE_INTERESSE = re.compile(
    r"conversa|chat|mensag|historic|interac|chamado|acao|ticket|forma",
    re.IGNORECASE,
)

# URLs de assets a ignorar
RE_IGNORAR = re.compile(
    r"\.(js|css|svg|png|jpg|jpeg|gif|woff|woff2|ttf|ico|map)(\?|$)",
    re.IGNORECASE,
)

interessantes = []
for entry in data["requests"]:
    url = entry.get("url", "")
    if RE_IGNORAR.search(url):
        continue
    if not RE_INTERESSE.search(url):
        continue
    if entry.get("resource_type") == "document":
        continue
    interessantes.append(entry)

# Dedupe por (phase, method, url)
vistos = set()
out = []
for e in interessantes:
    k = (e.get("phase"), e.get("method"), e.get("url"))
    if k in vistos:
        continue
    vistos.add(k)
    out.append(e)

# Ordena por URL
out.sort(key=lambda e: (e.get("url", ""), e.get("phase", "")))

result_file = Path(__file__).parent / "captura_filtrada.json"
result_file.write_text(json.dumps(out, indent=2, ensure_ascii=False, default=str),
                        encoding="utf-8")
print(f"{len(out)} requests interessantes (de {len(data['requests'])} totais)")
print(f"salvos em {result_file}")
print()
print("=== Resumo por URL ===")
urls = {}
for e in out:
    url = e.get("url", "")
    urls.setdefault(url, {"req": 0, "resp": 0, "status": None, "method": None,
                           "post": None, "body_preview": None})
    if e.get("phase") == "request":
        urls[url]["req"] += 1
        if e.get("post_data"):
            urls[url]["post"] = e["post_data"][:500]
        urls[url]["method"] = e.get("method")
    elif e.get("phase") == "response":
        urls[url]["resp"] += 1
        urls[url]["status"] = e.get("status")
        body = e.get("body")
        if body:
            urls[url]["body_preview"] = body[:400]

for url, info in sorted(urls.items()):
    print(f"  {info['method']} {url} -> status={info['status']} req={info['req']} resp={info['resp']}")
    if info.get("post"):
        print(f"    POST: {info['post']}")
    if info.get("body_preview"):
        print(f"    RESP: {info['body_preview']}")
