"""Teste: conecta ao Ably com a key fixa e escuta 15s no canal 'questor'.

Valida que a key funciona fora do browser (por exemplo dentro do MCP Python).
"""
import asyncio
import json
from datetime import datetime

from ably import AblyRealtime

ABLY_KEY = "FzTjhQ.Pcf0RA:uHz5r1xRJTpn5_n_"
CANAL = "questor"


async def main():
    received = []

    def on_message(msg):
        data_raw = msg.data
        try:
            data = json.loads(data_raw) if isinstance(data_raw, str) else data_raw
        except Exception:
            data = data_raw
        received.append({
            "at": datetime.now().isoformat(timespec="seconds"),
            "name": msg.name,
            "data": data,
        })

    realtime = AblyRealtime(ABLY_KEY)
    channel = realtime.channels.get(CANAL)
    await channel.subscribe(on_message)
    print(f"Inscrito em {CANAL}, aguardando 15s...")

    await asyncio.sleep(15)

    await realtime.close()

    print(f"\nTotal recebido: {len(received)}")
    # Contar por tipo
    tipos = {}
    for r in received:
        if not isinstance(r.get("data"), dict):
            continue
        d = r["data"]
        t = ("Criar" if d.get("Criar") == "true"
             else "Alerta" if d.get("Alerta") == "true"
             else "Ocultar" if d.get("Ocultar") == "true"
             else "outro")
        tipos[t] = tipos.get(t, 0) + 1
    print(f"Por tipo: {tipos}")

    # Mostrar 10 primeiros Criar/Alerta (ignorando Ocultar)
    print("\nPrimeiras mensagens 'Criar'/'Alerta':")
    n = 0
    for r in received:
        d = r.get("data")
        if not isinstance(d, dict):
            continue
        if d.get("Criar") != "true" and d.get("Alerta") != "true":
            continue
        n += 1
        msg_preview = str(d.get("Msg", ""))[:80]
        print(f"  [{r['at']}] {d.get('NomeCompleto')} (usu={d.get('CodUsuario')} "
              f"op={d.get('AlertaOpers')}): {msg_preview}")
        if n >= 10:
            break


if __name__ == "__main__":
    asyncio.run(main())
