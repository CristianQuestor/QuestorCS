"""Busca a conversa completa do chamado 0426-012054 via listaCustom e
mostra em formato limpo, tipo chat."""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlencode

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskClient  # noqa: E402

CHAVE = 1624588


async def main():
    async with DeskClient.from_env() as client:
        token = await client._get_token()  # type: ignore
        dados = {
            "Ajax": "true",
            "Filtros": {"CodChamado": [str(CHAVE), "equal"]},
            "Colunas": {
                "Chave": "on", "CodChamado": "on", "Descricao": "on",
                "DataAcao": "on", "HoraAcaoInicio": "on", "HoraAcaoFim": "on",
                "NomeOperador": "on", "NomeStatus": "on",
                "NomeFormaAtendimento": "on",
            },
        }
        form = urlencode({"Dados": json.dumps(dados), "App": "Ticket"})
        async with httpx.AsyncClient(timeout=30.0) as http:
            r = await http.post(
                f"{client.config.api_url}/ChamadoHistoricos/listaCustom",
                content=form,
                headers={
                    "Authorization": token,
                    "PublicKey": client.config.public_key,
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                },
            )
        d = json.loads(r.text)

    # Salva JSON completo
    out = Path(__file__).parent / "conversa_0426-012054_via_mcp.json"
    out.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")

    # Salva conversa reconstruída em texto
    txt_out = Path(__file__).parent / "conversa_0426-012054_via_mcp.txt"
    with open(txt_out, "w", encoding="utf-8") as f:
        f.write(f"Chamado 0426-012054 (Chave {CHAVE}) - reconstruído via API\n")
        f.write(f"Total de sessões de chat: {d.get('total')}\n")
        f.write("=" * 80 + "\n\n")
        # Ordena por data/hora asc
        items = sorted(d.get("root") or [],
                        key=lambda i: (i.get("DataAcao", ""),
                                       i.get("HoraAcaoInicio", "")))
        for i, item in enumerate(items, 1):
            f.write(f"--- SESSÃO {i} ---\n")
            f.write(f"Data: {item.get('DataAcao')} "
                    f"{item.get('HoraAcaoInicio')} → {item.get('HoraAcaoFim')}\n")
            f.write(f"Operador: {item.get('NomeOperador')}\n")
            f.write(f"Forma: {item.get('NomeFormaAtendimento')}\n")
            f.write(f"Status final: {item.get('NomeStatus')}\n")
            f.write("\n")
            f.write(item.get("Descricao") or "")
            f.write("\n\n")

    # Printa no stdout
    print(f"Total: {d.get('total')} sessões de chat materializadas")
    print(f"JSON:  {out}")
    print(f"TXT :  {txt_out}")
    print()
    for i, item in enumerate(items, 1):
        descricao = item.get("Descricao") or ""
        n_linhas = descricao.count("\n")
        print(f"  Sessão {i}: {item.get('DataAcao')} "
              f"{item.get('HoraAcaoInicio')}→{item.get('HoraAcaoFim')}  "
              f"{item.get('NomeOperador')}  ({n_linhas} linhas)")


if __name__ == "__main__":
    asyncio.run(main())
