"""Analisa o dump de WebSocket do Ably para entender a estrutura das mensagens."""
import json
import re
from pathlib import Path
from collections import Counter

data = json.loads((Path(__file__).parent / "capturar_ably_dump.json").read_text(encoding="utf-8"))

for i, ws in enumerate(data["websockets"]):
    print(f"=== WebSocket {i}: {ws['url'][:90]}...")
    print(f"    frames: {len(ws['frames'])}")

# Extrai só frames recv com conteúdo Ably (tipo JSON)
frames_recv = []
for ws in data["websockets"]:
    for f in ws["frames"]:
        if f["direcao"] == "recv" and f["data"].startswith("{"):
            frames_recv.append(f["data"])

print(f"\nTotal frames recv JSON: {len(frames_recv)}")

# Parseia cada frame
tipos_action = Counter()
tipos_name = Counter()
samples_por_name = {}
for raw in frames_recv:
    try:
        # Frames Ably vem como { action: N, ...}
        msg = json.loads(raw)
    except Exception:
        continue
    act = msg.get("action")
    tipos_action[act] += 1
    # Só ação=15 (MESSAGE) traz mensagens reais
    if act == 15:
        for m in msg.get("messages") or []:
            nome = m.get("name")
            tipos_name[nome] += 1
            if nome not in samples_por_name and nome is not None:
                samples_por_name[nome] = m

print(f"\nAções Ably: {dict(tipos_action)}")
print(f"Nomes de eventos: {dict(tipos_name)}")

print("\n" + "=" * 60)
print("SAMPLES de cada tipo de evento:")
for nome, sample in samples_por_name.items():
    print(f"\n--- name={nome} ---")
    # Extrai data do sample
    data_str = sample.get("data", "")
    if isinstance(data_str, str):
        try:
            data_parsed = json.loads(data_str)
            print(json.dumps(data_parsed, indent=2, ensure_ascii=False)[:1500])
        except Exception:
            print(repr(data_str)[:1000])
    else:
        print(json.dumps(data_str, indent=2, ensure_ascii=False)[:1500])

# Mostra TODAS as mensagens de chat
print("\n" + "=" * 60)
print("TODAS as mensagens de 'chat':")
chats = []
for raw in frames_recv:
    try:
        msg = json.loads(raw)
        if msg.get("action") != 15:
            continue
        for m in msg.get("messages") or []:
            if m.get("name") == "chat":
                data_str = m.get("data", "")
                try:
                    chats.append(json.loads(data_str))
                except Exception:
                    chats.append({"raw": data_str[:200]})
    except Exception:
        continue

print(f"Total de mensagens chat: {len(chats)}")
for i, ch in enumerate(chats):
    keys = list(ch.keys())
    print(f"  [{i}] keys={keys}")
    if "Msg" in ch:
        msg_text = str(ch.get("Msg", ""))[:100]
        print(f"      Msg: {msg_text}")
    if "CodChamado" in ch:
        print(f"      CodChamado: {ch['CodChamado']}")
    if "CodUsuario" in ch:
        print(f"      CodUsuario: {ch['CodUsuario']} NomeCompleto: {ch.get('NomeCompleto')}")
