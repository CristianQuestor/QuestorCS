"""Probe específico do endpoint /Conversas (já sabemos que existe).

Objetivo: descobrir o body correto para obter as mensagens do chat do
chamado 0426-012054 / chave 1624588 (que tem chat ao vivo ativo).
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskAPIError, DeskClient  # noqa: E402


CHAVE = 1624588
COD = "0426-012054"

# Mix: endpoint + body
TENTATIVAS = [
    # 1) Conversas/lista com Colunas — replica padrão de ChamadoHistoricos
    ("Conversas/lista", {
        "Chave": str(CHAVE),
        "Colunas": {"Chave": "on", "Mensagem": "on", "DataEnvio": "on", "HoraEnvio": "on",
                     "Remetente": "on", "Tipo": "on", "Texto": "on", "Descricao": "on"},
    }),
    ("Conversas/lista", {
        "CodChamado": COD,
        "Colunas": {"Chave": "on", "Mensagem": "on", "DataEnvio": "on", "HoraEnvio": "on",
                     "Remetente": "on", "Tipo": "on", "Texto": "on", "Descricao": "on"},
    }),
    ("Conversas/lista", {
        "ChaveChamado": str(CHAVE),
        "Colunas": {"Chave": "on", "Mensagem": "on", "DataEnvio": "on", "HoraEnvio": "on",
                     "Remetente": "on", "Tipo": "on", "Texto": "on", "Descricao": "on"},
    }),
    # 2) Conversas/lista com Filtros (padrão de ChamadosSuporte)
    ("Conversas/lista", {
        "Tatual": 0, "Quantidade": 200,
        "Filtros": [{"Campo": "ChaveChamado", "Valor": CHAVE, "Operador": "="}],
    }),
    ("Conversas/lista", {
        "Tatual": 0, "Quantidade": 200,
        "Filtros": [{"Campo": "CodChamado", "Valor": COD, "Operador": "="}],
    }),
    # 3) Sem filtro — lista de conversas abertas (ver shape)
    ("Conversas/lista", {
        "Tatual": 0, "Quantidade": 10,
    }),
    # 4) Variações de endpoint específico para mensagens
    ("Conversas/mensagens", {"Chave": str(CHAVE)}),
    ("Conversas/mensagens", {"ChaveChamado": str(CHAVE)}),
    ("ConversaMensagens/lista", {"Chave": str(CHAVE)}),
    ("ConversaMensagens/lista", {"ChaveChamado": str(CHAVE)}),
    ("MensagensConversa/lista", {"ChaveChamado": str(CHAVE)}),
    # 5) Obter conversa (detalhe com Chave)
    ("Conversas", {"Chave": str(CHAVE)}),
    ("Conversas", {"CodChamado": COD}),
    # 6) Campo Colunas com inclusão de mensagens
    ("Conversas/lista", {
        "ChaveChamado": str(CHAVE),
        "Tatual": 0, "Quantidade": 200,
        "Colunas": {"Chave": "on", "DataCriacao": "on", "HoraCriacao": "on",
                     "CodChamado": "on", "ChaveChamado": "on", "Mensagens": "on",
                     "UltimaMensagem": "on", "Status": "on"},
    }),
]


async def run():
    resultados = []
    async with DeskClient.from_env() as client:
        for endpoint, body in TENTATIVAS:
            url = f"{client.config.api_url}/{endpoint}"
            label = f"{endpoint} {json.dumps(body, ensure_ascii=False)[:90]}"
            try:
                r = await client._request("POST", url, json_body=body, timeout=30.0)
            except DeskAPIError as e:
                print(f"FAIL {label} -> HTTP {e.status_code}: {str(e)[:150]}")
                resultados.append({"endpoint": endpoint, "body": body,
                                   "status": f"HTTP {e.status_code}",
                                   "erro": str(e)[:300]})
                continue
            except Exception as e:
                print(f"ERR  {label} -> {type(e).__name__}: {str(e)[:150]}")
                continue

            if isinstance(r, dict):
                total = r.get("total")
                root = r.get("root")
                n = len(root) if isinstance(root, list) else None
                sample = root[0] if isinstance(root, list) and root else None
                sample_keys = list(sample.keys())[:20] if isinstance(sample, dict) else None
                print(f"OK   {label} -> total={total} root_len={n} keys(top)={list(r.keys())[:8]} "
                      f"sample_keys={sample_keys}")
                resultados.append({"endpoint": endpoint, "body": body,
                                   "status": "OK", "total": total, "root_len": n,
                                   "top_keys": list(r.keys()), "sample": sample})
            else:
                print(f"OK?  {label} -> {type(r).__name__}: {str(r)[:150]}")
                resultados.append({"endpoint": endpoint, "body": body,
                                   "status": "OK-nao-dict", "tipo": type(r).__name__,
                                   "valor": str(r)[:500]})

    out = Path(__file__).parent / "probe_conversas_resultados.json"
    out.write_text(json.dumps(resultados, indent=2, ensure_ascii=False, default=str),
                   encoding="utf-8")
    print(f"\n-> salvo em {out}")


if __name__ == "__main__":
    asyncio.run(run())
