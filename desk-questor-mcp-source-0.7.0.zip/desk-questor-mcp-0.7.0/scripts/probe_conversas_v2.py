"""Probe v2: descobrir como obter as mensagens SEM disparar 'Alguém chegou primeiro'.

Hipóteses:
- /Conversas/{subaction} além de /lista (ex.: /obter, /detalhe, /mensagens, /historico)
- Em questor.desk.ms em vez de api.desk.ms
- ChamadosSuporte pode ter uma subaction /conversas ou /chat
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskAPIError, DeskClient  # noqa: E402


CHAVE = 1624588
COD = "0426-012054"


async def run():
    resultados = []
    async with DeskClient.from_env() as client:
        base_api = client.config.api_url
        base_portal = "https://questor.desk.ms"

        casos = []
        # 1) Subactions de /Conversas
        for sub in ["obter", "detalhe", "detalhar", "mensagens", "historico",
                    "historicoMensagens", "mensagem/lista", "listarMensagens",
                    "buscar", "get", "conteudo", "ver", "visualizar"]:
            for body in [
                {"Chave": str(CHAVE)},
                {"CodChamado": COD},
                {"ChaveChamado": str(CHAVE)},
                {"Chave": str(CHAVE), "ApenasLeitura": "S"},
                {"Chave": str(CHAVE), "SoLeitura": "S"},
                {"Chave": str(CHAVE), "Visualizar": "S"},
            ]:
                casos.append((f"{base_api}/Conversas/{sub}", body, "Conversas/" + sub))

        # 2) ChamadosSuporte com subaction chat/conversa
        for sub in ["conversa", "conversas", "chat", "mensagens", "historicoChat",
                    "conversaMensagens"]:
            for body in [
                {"Chave": CHAVE},
                {"Chave": str(CHAVE)},
                {"CodChamado": COD},
            ]:
                casos.append((f"{base_api}/ChamadosSuporte/{sub}", body,
                              f"ChamadosSuporte/{sub}"))

        # 3) No portal (questor.desk.ms)
        for path in ["/Conversas/lista", "/Conversas/mensagens",
                     "/ChamadosSuporte/conversa", "/ChamadoHistoricos/lista",
                     "/ConversaChamado/lista"]:
            casos.append((f"{base_portal}{path}", {"Chave": str(CHAVE)},
                          f"portal{path}"))
            casos.append((f"{base_portal}{path}", {"CodChamado": COD},
                          f"portal{path}-cod"))

        for url, body, label in casos:
            try:
                r = await client._request("POST", url, json_body=body, timeout=15.0)
            except DeskAPIError as e:
                code = e.status_code
                msg = str(e)[:160]
                if code == 404:
                    continue  # silencia 404
                print(f"FAIL {label:60s} [{list(body.keys())[0]}] HTTP {code}: {msg}")
                resultados.append({"label": label, "body": body,
                                   "status": f"HTTP {code}", "erro": msg})
                continue
            except Exception as e:
                continue

            if isinstance(r, dict):
                total = r.get("total")
                root = r.get("root")
                n = len(root) if isinstance(root, list) else None
                sample = root[0] if isinstance(root, list) and root else None
                sample_keys = list(sample.keys())[:25] if isinstance(sample, dict) else None
                print(f"OK   {label:60s} total={total} n={n} "
                      f"top={list(r.keys())[:8]} sample_keys={sample_keys}")
                resultados.append({"label": label, "body": body,
                                   "status": "OK", "total": total, "root_len": n,
                                   "top_keys": list(r.keys()), "sample": sample})
            else:
                print(f"OK?  {label:60s} tipo={type(r).__name__}: {str(r)[:120]}")

    out = Path(__file__).parent / "probe_conversas_v2_resultados.json"
    out.write_text(json.dumps(resultados, indent=2, ensure_ascii=False, default=str),
                   encoding="utf-8")
    print(f"\n-> {len(resultados)} resultados salvos em {out}")


if __name__ == "__main__":
    asyncio.run(run())
