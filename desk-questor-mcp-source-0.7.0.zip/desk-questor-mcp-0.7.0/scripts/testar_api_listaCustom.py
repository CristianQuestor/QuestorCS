"""Prova se /ChamadoHistoricos/listaCustom funciona com:
- token da API (Authorization) em api.desk.ms
- body form-urlencoded Dados={}&App=Ticket

Se sim → dá pra usar direto do MCP.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlencode

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskClient  # noqa: E402

CHAVE = 1624588


async def main():
    async with DeskClient.from_env() as client:
        token = await client._get_token()  # type: ignore

        dados = {
            "Ajax": "true",
            "Filtros": {"CodChamado": [str(CHAVE), "equal"]},
            "Colunas": {
                "Chave": "on", "CodChamado": "on", "Descricao": "on",
                "DescricaoAbrev": "on", "DataAcao": "on",
                "HoraAcaoInicio": "on", "HoraAcaoFim": "on",
                "NomeOperador": "on", "CodOperador": "on",
                "NomeStatus": "on", "CodStatus": "on",
                "NomeFormaAtendimento": "on", "CodFormaAtendimento": "on",
                "NomeCausa": "on",
            },
        }

        # Teste 1: api.desk.ms + Authorization (token do login)
        url_api = f"{client.config.api_url}/ChamadoHistoricos/listaCustom"
        form = urlencode({"Dados": json.dumps(dados), "App": "Ticket"})
        print(f"[1] POST {url_api}")
        async with httpx.AsyncClient(timeout=30.0) as http:
            r = await http.post(url_api, content=form, headers={
                "Authorization": token,
                "PublicKey": client.config.public_key,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            })
        print(f"    status={r.status_code} bytes={len(r.text)}")
        print(f"    preview: {r.text[:500]}")

        # Teste 2: api.desk.ms + BackReqToken
        if client.config.back_req_token:
            print(f"\n[2] POST {url_api} (BackReqToken)")
            async with httpx.AsyncClient(timeout=30.0) as http:
                r = await http.post(url_api, content=form, headers={
                    "Authorization": client.config.back_req_token,
                    "PublicKey": client.config.public_key,
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                })
            print(f"    status={r.status_code} bytes={len(r.text)}")
            print(f"    preview: {r.text[:500]}")

        # Teste 3: api.desk.ms, mas body em JSON (não form-urlencoded)
        print(f"\n[3] POST {url_api} com JSON body")
        async with httpx.AsyncClient(timeout=30.0) as http:
            r = await http.post(url_api, json={"Dados": json.dumps(dados), "App": "Ticket"},
                                 headers={
                                     "Authorization": token,
                                     "PublicKey": client.config.public_key,
                                     "Accept": "application/json",
                                 })
        print(f"    status={r.status_code} bytes={len(r.text)}")
        print(f"    preview: {r.text[:500]}")


if __name__ == "__main__":
    asyncio.run(main())
