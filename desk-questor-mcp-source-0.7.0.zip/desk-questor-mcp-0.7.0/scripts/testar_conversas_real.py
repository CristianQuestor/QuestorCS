"""Testa o endpoint real encontrado no bundle JS da UI:

    POST /Conversas/lista
    Content-Type: application/x-www-form-urlencoded
    body: Dados={"CodChamado":"0426-012054"}&App=Ticket

Testa em 2 contextos:
  A) Sessão web real (cookies do login /Suporte/logar) — mesmo que a UI faz
  B) Com o token da API (Authorization header), em api.desk.ms e questor.desk.ms
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlencode

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskClient  # noqa: E402

USUARIO_UI = "fabio"
SENHA_UI = "6n38@JT0"
COD = "0426-012054"
CHAVE = 1624588


async def login_ui() -> httpx.AsyncClient:
    """Replica o /Suporte/logar da UI e devolve cliente autenticado por cookie."""
    client = httpx.AsyncClient(follow_redirects=True, timeout=30.0)
    # Primeiro abre a home pra receber cookies iniciais
    await client.get("https://questor.desk.ms/?LoginTicket")

    dados = {
        "IdMobile": "", "TypeMobile": "", "Prefixo": "questor",
        "Dispositivo": "", "Login": USUARIO_UI, "Senha": SENHA_UI, "website": "",
    }
    form = urlencode({"Dados": json.dumps(dados)})
    r = await client.post(
        "https://questor.desk.ms/Suporte/logar",
        content=form,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    print(f"Login UI: {r.status_code} -> {r.text[:200]}")
    return client


async def testar_com_ui(http: httpx.AsyncClient, endpoint: str, dados: dict):
    url = f"https://questor.desk.ms/{endpoint}"
    form = urlencode({"Dados": json.dumps(dados), "App": "Ticket"})
    r = await http.post(url, content=form,
                         headers={"Content-Type": "application/x-www-form-urlencoded",
                                  "Accept": "application/json"})
    ct = r.headers.get("content-type", "")
    return r.status_code, ct, r.text


async def testar_com_api(client: DeskClient, endpoint: str, dados: dict):
    """Tenta usar o token da API em api.desk.ms (formato form do coletor)."""
    token = await client._get_token()  # type: ignore
    base = client.config.api_url
    url = f"{base}/{endpoint}"
    form = urlencode({"Dados": json.dumps(dados), "App": "Ticket"})
    async with httpx.AsyncClient(timeout=30.0) as http:
        r = await http.post(url, content=form, headers={
            "Authorization": token,
            "PublicKey": client.config.public_key,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        })
    return r.status_code, r.headers.get("content-type", ""), r.text


async def main():
    print("=" * 70)
    print(f"Chamado: {COD} (Chave {CHAVE})")
    print("=" * 70)

    # ---- A) Via sessão web (cookies do login /Suporte/logar)
    print("\n[A] SESSÃO WEB (UI real)")
    ui = await login_ui()
    casos_ui = [
        ("Conversas/lista", {"CodChamado": COD}),
        ("Conversas/lista", {"CodChamado": COD, "Interacao": "true"}),
        ("Conversas/lista", {"CodChamado": COD, "Interacao": "true", "MenorData": "true"}),
        ("ChamadoHistoricos/lista", {"Codigo": COD}),
        ("ChamadoHistoricos/listaCustom", {
            "Ajax": "true",
            "Filtros": {"CodChamado": [COD, "equal"]},
            "Colunas": {"Chave": "on", "DescricaoAbrev": "on", "NomeStatus": "on",
                         "DataAcao": "on", "HoraAcaoInicio": "on", "NomeOperador": "on"},
        }),
        ("Conversas/exibir", {}),
    ]
    for endpoint, dados in casos_ui:
        try:
            status, ct, body = await testar_com_ui(ui, endpoint, dados)
        except Exception as e:
            print(f"  ERR {endpoint} {list(dados.keys())}: {e}")
            continue
        preview = body[:600].replace("\n", " ")
        print(f"  {status} {endpoint} {list(dados.keys())} ct={ct[:30]} | {preview}")

    await ui.aclose()

    # ---- B) Via token API (api.desk.ms)
    print("\n[B] TOKEN API (api.desk.ms)")
    async with DeskClient.from_env() as client:
        for endpoint, dados in casos_ui:
            try:
                status, ct, body = await testar_com_api(client, endpoint, dados)
            except Exception as e:
                print(f"  ERR {endpoint} {list(dados.keys())}: {e}")
                continue
            preview = body[:600].replace("\n", " ")
            print(f"  {status} {endpoint} {list(dados.keys())} ct={ct[:30]} | {preview}")


if __name__ == "__main__":
    asyncio.run(main())
