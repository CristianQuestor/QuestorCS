"""Mostra o response completo dos endpoints interessantes."""
import json
from pathlib import Path

data = json.loads((Path(__file__).parent / "captura_chat.json").read_text(encoding="utf-8"))

ALVOS = [
    "questor.desk.ms/Conversas/exibir",
    "questor.desk.ms/Ticket/dashboard",
    "questor.desk.ms/prefixoticket",
    "/Conversas",
    "/Chamado",
    "/Historic",
    "/Ticket/",
    "/Mensag",
    "/Chat",
]

for entry in data["requests"]:
    url = entry.get("url", "")
    if not any(a in url for a in ALVOS):
        continue
    if "analytics" in url or "hubspot" in url or "google.com" in url:
        continue
    if entry.get("phase") == "response":
        print("=" * 80)
        print(f"{entry.get('method')} {url}")
        print(f"status={entry.get('status')} ct={entry.get('content_type')}")
        body = entry.get("body")
        if body:
            print(f"BODY:\n{body[:3000]}")
        print()
    elif entry.get("phase") == "request" and entry.get("post_data"):
        print("-" * 80)
        print(f"REQ {entry.get('method')} {url}")
        print(f"POST_DATA: {entry.get('post_data')[:1500]}")
