"""Captura TUDO do Ably (WebSocket) ao abrir uma tela de chat real do Desk.

Estratégia:
1. Login via UI
2. Força o SPA a abrir o modal de chat do chamado 0426-012054 via JS
   (injetando chamadas na console do browser)
3. Fica 45s escutando websocket frames
4. Dumpa todas as requests + frames em capturar_ably_dump.json

Uso: python scripts/capturar_ably.py
"""
from __future__ import annotations

import asyncio
import json
from datetime import datetime
from pathlib import Path

from playwright.async_api import async_playwright

USUARIO = "fabio"
SENHA = "6n38@JT0"
COD = "0426-012054"
CHAVE = 1624588

OUT = Path(__file__).parent / "capturar_ably_dump.json"


async def main():
    requests_log: list[dict] = []
    ws_log: list[dict] = []
    console_log: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            ignore_https_errors=True,
            viewport={"width": 1600, "height": 900},
        )
        page = await context.new_page()

        # Listeners
        page.on("console", lambda m: console_log.append(
            f"[{m.type}] {m.text[:500]}"
        ))

        def on_request(req):
            try:
                post = req.post_data
            except Exception:
                post = None
            requests_log.append({
                "at": datetime.utcnow().isoformat(),
                "phase": "req", "method": req.method, "url": req.url,
                "resource_type": req.resource_type,
                "post_data": (post[:2000] if post else None),
            })
        page.on("request", on_request)

        async def on_response(resp):
            try:
                body = None
                if resp.request.resource_type in ("xhr", "fetch"):
                    try:
                        body = await resp.text()
                        if body and len(body) > 4000:
                            body = body[:4000] + "..."
                    except Exception:
                        body = None
                requests_log.append({
                    "at": datetime.utcnow().isoformat(),
                    "phase": "resp", "method": resp.request.method,
                    "url": resp.url, "status": resp.status,
                    "body": body,
                })
            except Exception:
                pass
        page.on("response", on_response)

        def on_websocket(ws):
            entry = {"url": ws.url, "created_at": datetime.utcnow().isoformat(),
                     "frames": []}
            ws_log.append(entry)
            print(f"[WS] conectou: {ws.url}")

            def _frame(direcao, data):
                if isinstance(data, (bytes, bytearray)):
                    try:
                        data = data.decode("utf-8", "replace")
                    except Exception:
                        data = repr(data)
                entry["frames"].append({
                    "direcao": direcao,
                    "at": datetime.utcnow().isoformat(),
                    "data": str(data)[:4000],
                })

            ws.on("framesent", lambda payload: _frame("sent", payload))
            ws.on("framereceived", lambda payload: _frame("recv", payload))
            ws.on("close", lambda ws=ws: entry.update(closed_at=datetime.utcnow().isoformat()))
        page.on("websocket", on_websocket)

        # 1) Login
        print("[1] login...")
        await page.goto("https://questor.desk.ms/?LoginTicket",
                         wait_until="domcontentloaded", timeout=30000)
        await page.locator("#ModalLoginTicket input[name='Login']").fill(USUARIO)
        await page.locator("#ModalLoginTicket input[name='Senha']").fill(SENHA)
        await page.locator("#ModalLoginTicket button:has-text('Entrar')").first.click()
        try:
            await page.wait_for_load_state("networkidle", timeout=20000)
        except Exception:
            pass
        await asyncio.sleep(4)
        print(f"  url={page.url}")

        # 2) Injeta JS para abrir o chamado e iniciar a conversa
        print(f"[2] tentando abrir chamado {COD}")
        # Primeiro verifica se globals existem
        info = await page.evaluate("""
        () => ({
            hasJQuery: typeof jQuery !== 'undefined',
            hasAbly: typeof Ably !== 'undefined',
            glbPrefixo: (typeof glbPrefixo !== 'undefined') ? glbPrefixo : null,
            glbUserCod: (typeof glbUserCod !== 'undefined') ? glbUserCod : null,
            glbAppName: (typeof glbAppName !== 'undefined') ? glbAppName : null,
            glbUrlRT: (typeof glbUrlRT !== 'undefined') ? glbUrlRT : null,
            hasChannelRT: (typeof channelRT !== 'undefined') ? channelRT.name : null,
        })
        """)
        print(f"  globals: {json.dumps(info, indent=2)}")

        # Tenta abrir direto via URL com hash
        print("[3] navegando para hash do chamado")
        for hash_url in [
            f"https://questor.desk.ms/?Ticket#ChamadosSuporte/{COD}",
            f"https://questor.desk.ms/?Ticket#ChamadosSuporte/{CHAVE}",
            f"https://questor.desk.ms/?Ticket#Conversas/{CHAVE}",
            f"https://questor.desk.ms/?Ticket#Conversas",
        ]:
            print(f"    -> {hash_url}")
            await page.goto(hash_url, wait_until="networkidle", timeout=15000)
            await asyncio.sleep(3)

        # Tenta injetar a chamada que a UI faria para abrir a conversa
        print("[4] tentando iniciar conversa via JS")
        try:
            resultado_js = await page.evaluate("""
            async () => {
                try {
                    // Tenta a chamada /Conversas/iniciar como a UI faz
                    const r = await fetch('/Conversas/iniciar', {
                        method: 'PUT',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'Dados=' + encodeURIComponent(JSON.stringify({Chave: '""" + str(CHAVE) + """', Tipo: 'ChatAtendimento'})) + '&App=Ticket'
                    });
                    return {status: r.status, body: (await r.text()).slice(0, 500)};
                } catch(e) { return {erro: e.toString()}; }
            }
            """)
            print(f"    /Conversas/iniciar: {resultado_js}")
        except Exception as e:
            print(f"    erro: {e}")

        # Inscrever manualmente em canais Ably de teste
        print("[5] testando subscribe em canais Ably específicos")
        try:
            subs = await page.evaluate("""
            async () => {
                if (typeof Ably === 'undefined') return {erro: 'Ably não carregado'};
                const key = "FzTjhQ.Pcf0RA:uHz5r1xRJTpn5_n_";
                const client = new Ably.Realtime(key);
                const received = [];

                // Tenta vários nomes de canal prováveis
                const canais = [
                    'questor',                               // glbPrefixo
                    'questor-" + str(CHAVE) + "',
                    'questor_" + str(CHAVE) + "',
                    'questor." + str(CHAVE) + "',
                    'chamado-" + str(CHAVE) + "',
                    '" + str(CHAVE) + "',
                    'questor-chat',
                    'questor-chat-" + str(CHAVE) + "',
                ];
                const subs = [];
                for (const nome of canais) {
                    try {
                        const ch = client.channels.get(nome);
                        ch.subscribe((msg) => {
                            received.push({canal: nome, name: msg.name,
                                            data: String(msg.data).slice(0, 300)});
                        });
                        subs.push(nome);
                    } catch(e) {}
                }

                // Aguarda 10s pra ver se chega algo
                await new Promise(r => setTimeout(r, 10000));
                return {subs, received, connectionState: client.connection.state};
            }
            """)
            print(f"    subscribe result: {json.dumps(subs, indent=2)[:2000]}")
        except Exception as e:
            print(f"    erro: {e}")

        # Aguarda mais um tempo pra capturar tráfego
        print("[6] aguardando 20s de tráfego extra")
        await asyncio.sleep(20)

        await browser.close()

    OUT.write_text(json.dumps({
        "requests": requests_log,
        "websockets": ws_log,
        "console": console_log[-200:],
    }, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\nTotal requests: {len(requests_log)}")
    print(f"WebSockets: {len(ws_log)}")
    for ws in ws_log:
        print(f"  {ws['url']}: {len(ws['frames'])} frames")
    print(f"Salvo em {OUT}")


if __name__ == "__main__":
    asyncio.run(main())
