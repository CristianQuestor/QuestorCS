# Inicia o desk-questor-mcp em desenvolvimento
$ErrorActionPreference = "Stop"
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo

if (Test-Path .venv\Scripts\Activate.ps1) {
    & .venv\Scripts\Activate.ps1
}

if (-not (Test-Path .env)) {
    Write-Host "Crie um .env a partir de .env.example antes de iniciar." -ForegroundColor Yellow
    exit 1
}

python -m src.server
