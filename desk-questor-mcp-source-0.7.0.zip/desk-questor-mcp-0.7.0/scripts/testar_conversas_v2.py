"""Testa com a CHAVE numérica no filtro (não o CodChamado texto),
e busca outros endpoints do bundle com o CodChamado de forma correta.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlencode

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskClient  # noqa: E402

COD = "0426-012054"
CHAVE = 1624588


async def login_ui() -> httpx.AsyncClient:
    client = httpx.AsyncClient(follow_redirects=True, timeout=30.0)
    await client.get("https://questor.desk.ms/?LoginTicket")
    dados = {"IdMobile": "", "TypeMobile": "", "Prefixo": "questor",
             "Dispositivo": "", "Login": "fabio", "Senha": "6n38@JT0", "website": ""}
    form = urlencode({"Dados": json.dumps(dados)})
    r = await client.post("https://questor.desk.ms/Suporte/logar", content=form,
                           headers={"Content-Type": "application/x-www-form-urlencoded"})
    assert r.status_code == 200, r.status_code
    return client


async def post_form(http: httpx.AsyncClient, url: str, dados: dict,
                     incluir_app: bool = True) -> tuple[int, str]:
    payload = {"Dados": json.dumps(dados)}
    if incluir_app:
        payload["App"] = "Ticket"
    form = urlencode(payload)
    r = await http.post(url, content=form, headers={
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
    })
    return r.status_code, r.text


async def main():
    ui = await login_ui()
    print("Login UI OK\n")

    # Filtros com CHAVE (numérica) ao invés de CodChamado texto
    casos = [
        # Variações no endpoint de histórico customizado
        ("ChamadoHistoricos/listaCustom", {
            "Ajax": "true",
            "Filtros": {"CodChamado": [str(CHAVE), "equal"]},
            "Colunas": {"Chave": "on", "DescricaoAbrev": "on", "NomeStatus": "on",
                         "DataAcao": "on", "HoraAcaoInicio": "on", "NomeOperador": "on",
                         "Descricao": "on", "HoraAcaoFim": "on", "Forma": "on"},
        }),
        # Sem filtro, só pra ver shape geral
        ("ChamadoHistoricos/listaCustom", {
            "Ajax": "true",
            "Filtros": {"CodChamado": [str(CHAVE), "equal"]},
            "Colunas": {"Chave": "on", "Descricao": "on", "DescricaoAbrev": "on",
                         "NomeStatus": "on", "DataAcao": "on", "HoraAcaoInicio": "on",
                         "NomeOperador": "on", "CodOperador": "on", "CodChamado": "on",
                         "Forma": "on", "NomeFormaAtendimento": "on", "Publica": "on",
                         "CodAcao": "on"},
            "TAtual": "off",
        }),
        # Endpoint Conversas/lista com vários shapes
        ("Conversas/lista", {"CodChamado": str(CHAVE)}),
        ("Conversas/lista", {"CodChamado": COD}),
        ("Conversas/lista", {"Chave": str(CHAVE)}),
        ("Conversas/lista", {"Codigo": COD}),
        # Sem filtro — lista tudo que o operador vê
        ("Conversas/lista", {"Ajax": "true"}),
        ("Conversas/lista", {"CheckSPAM": "true", "Tipo": "4"}),  # forma usada em DropdownMenu
        # DonoCodUsuario (código do CLIENTE que iniciou conversa)
        # Usuário 85187 = Flavia pires (do detalhe do chamado)
        ("Conversas/lista", {"DonoCodUsuario": "85187", "Interacao": "true"}),
        ("Conversas/lista", {"DonoCodUsuario": "85187", "Interacao": "true",
                              "MenorData": "true"}),
        # Campos relacionados ao chamado
        ("ChamadoLogs/listaCustom", {
            "Filtros": {"CodChamado": [str(CHAVE), "equal"]},
            "Local": [["A", "R", "S", "P"]],
        }),
        ("ChamadosSuporte/editarChamado", {}, False),  # precisa Chave separada
    ]

    for caso in casos:
        if len(caso) == 3:
            endpoint, dados, incluir_app = caso
        else:
            endpoint, dados = caso
            incluir_app = True

        url = f"https://questor.desk.ms/{endpoint}"
        try:
            status, body = await post_form(ui, url, dados, incluir_app)
        except Exception as e:
            print(f"ERR {endpoint}: {e}")
            continue
        preview = body[:900].replace("\n", " ")
        print(f"[{status}] {endpoint} {list(dados.keys())}")
        print(f"       {preview}\n")

    await ui.aclose()


if __name__ == "__main__":
    asyncio.run(main())
