"""Validação E2E: chama escutar_chat_chamado direto no código do MCP
para provar que integra Desk detalhe + Ably e devolve msgs filtradas.

Cenários:
1. Chamado 0426-012054 (Flavia + Caciano) — escuta 20s
2. Global sem filtro — 5s pra amostra
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.desk_client import DeskClient  # noqa: E402
from src.tools import chat as tool_chat  # noqa: E402

CHAVE = 1624588


async def main():
    async with DeskClient.from_env() as client:
        print("=" * 70)
        print(f"[1] escutar_chat_chamado(chave={CHAVE}, duracao=20s)")
        print("=" * 70)
        r = await tool_chat.escutar_chat_chamado(
            client, chave=CHAVE, duracao_segundos=20,
        )
        print(f"chamado: {r['codigo']} cliente={r['cliente']} "
              f"operador={r['operador']}")
        print(f"cod_usuario={r['cod_usuario']} chave_operador={r['chave_operador']}")
        print(f"total mensagens filtradas: {r['total']}")
        if r.get("nota"):
            print(f"nota: {r['nota']}")
        for m in r["mensagens"]:
            t = m["tipo"].upper()
            texto = str(m.get("texto") or "")[:100].replace("\n", " ")
            print(f"  [{m['dh_recebida']}] {t:9s} {m['nome_emissor']!r:40s}: {texto}")

        print()
        print("=" * 70)
        print("[2] escutar_chat_global(duracao=5s) — amostra sem filtro")
        print("=" * 70)
        r = await tool_chat.escutar_chat_global(duracao_segundos=5)
        print(f"total: {r['total']}")
        for m in r["mensagens"][:5]:
            t = m["tipo"].upper()
            texto = str(m.get("texto") or "")[:80].replace("\n", " ")
            print(f"  [{m['dh_recebida']}] {t:9s} usu={m['cod_usuario_cliente']:>6s} "
                  f"ops={m['operadores_envolvidos']}: {texto}")


if __name__ == "__main__":
    asyncio.run(main())
