"""Gera zip do código-fonte da versão atual para upload no Drive.

Uso: python scripts/build_source_zip.py
Saída: dist/desk-questor-mcp-source-<versao>.zip
"""
from __future__ import annotations

import os
import re
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent


def _ler_versao() -> str:
    """Extrai `version = "x.y.z"` do pyproject.toml — evita drift."""
    conteudo = (RAIZ / "pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"', conteudo, re.MULTILINE)
    if not match:
        raise RuntimeError("Não consegui ler 'version' de pyproject.toml")
    return match.group(1)


VERSAO = _ler_versao()
SAIDA = RAIZ / "dist" / f"desk-questor-mcp-source-{VERSAO}.zip"

INCLUI_EXTS = {".py", ".toml", ".md", ".txt", ".ps1", ".example", ".gitignore"}
# Arquivos soltos na raiz que queremos sempre empacotar. Todos os .md da raiz
# também são incluídos automaticamente (issues, melhorias, etc.).
ARQUIVOS_RAIZ_FIXOS = {
    ".env.example",
    ".gitignore",
    "pyproject.toml",
    "requirements.txt",
}
PASTAS_OK = {"src", "tests", "scripts"}
IGNORA_DIRS = {".venv", "dist", "build", "__pycache__", ".pytest_cache"}


def deve_incluir_dir(rel: str) -> bool:
    if rel == ".":
        return True
    partes = rel.replace("\\", "/").split("/")
    if any(p in IGNORA_DIRS or p.endswith(".egg-info") for p in partes):
        return False
    return partes[0] in PASTAS_OK


def main() -> None:
    SAIDA.parent.mkdir(exist_ok=True)
    prefix = f"desk-questor-mcp-{VERSAO}"
    with zipfile.ZipFile(SAIDA, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(RAIZ):
            rel_dir = os.path.relpath(root, RAIZ)
            if not deve_incluir_dir(rel_dir):
                dirs[:] = []
                continue
            for f in files:
                rel = os.path.relpath(os.path.join(root, f), RAIZ)
                rel_unix = rel.replace("\\", "/")
                if rel_dir == ".":
                    # Raiz: fixos + todos os .md (issues, melhorias, CLAUDE/README)
                    if f not in ARQUIVOS_RAIZ_FIXOS and not f.endswith(".md"):
                        continue
                else:
                    if os.path.splitext(f)[1] not in INCLUI_EXTS:
                        continue
                    if "__pycache__" in rel_unix:
                        continue
                z.write(os.path.join(root, f), arcname=f"{prefix}/{rel_unix}")
    tamanho_kb = SAIDA.stat().st_size / 1024
    print(f"OK: {SAIDA.name} ({tamanho_kb:.1f} KB)")


if __name__ == "__main__":
    main()
