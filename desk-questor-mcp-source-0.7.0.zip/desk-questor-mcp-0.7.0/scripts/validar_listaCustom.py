"""Valida que /ChamadoHistoricos/listaCustom é superset de /ChamadoHistoricos/lista.

Testa em 3 chamados:
- 0426-011314 (Chave 1623848) - tem 3 ações via /lista
- 0426-012054 (Chave 1624588) - tem 0 via /lista, N via /listaCustom
- Mais um qualquer recente pra sanidade.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlencode

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskClient  # noqa: E402

CHAMADOS = [
    (1623848, "0426-011314"),   # 3 ações via /lista
    (1624588, "0426-012054"),   # 0 via /lista, >0 via /listaCustom
]


async def listar_custom(client: DeskClient, chave: int) -> dict:
    token = await client._get_token()  # type: ignore
    url = f"{client.config.api_url}/ChamadoHistoricos/listaCustom"
    dados = {
        "Ajax": "true",
        "Filtros": {"CodChamado": [str(chave), "equal"]},
        "Colunas": {
            "Chave": "on", "CodChamado": "on", "Descricao": "on",
            "DescricaoAbrev": "on", "DataAcao": "on",
            "HoraAcaoInicio": "on", "HoraAcaoFim": "on",
            "NomeOperador": "on", "CodOperador": "on",
            "NomeStatus": "on", "CodStatus": "on",
            "NomeFormaAtendimento": "on", "CodFormaAtendimento": "on",
            "NomeCausa": "on", "TotalHoras": "on",
        },
    }
    form = urlencode({"Dados": json.dumps(dados), "App": "Ticket"})
    async with httpx.AsyncClient(timeout=30.0) as http:
        r = await http.post(url, content=form, headers={
            "Authorization": token,
            "PublicKey": client.config.public_key,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        })
    return json.loads(r.text)


async def main():
    async with DeskClient.from_env() as client:
        for chave, cod in CHAMADOS:
            print("=" * 70)
            print(f"Chamado {cod} (Chave {chave})")

            # /lista atual (o que o MCP usa)
            antiga = await client.listar_historico_chamado(chave)
            total_antiga = antiga.get("total", "?")
            n_antiga = len(antiga.get("root") or [])

            # /listaCustom (novo)
            nova = await listar_custom(client, chave)
            total_nova = nova.get("total", "?")
            n_nova = len(nova.get("root") or [])

            print(f"  /lista            : total={total_antiga} root_len={n_antiga}")
            print(f"  /listaCustom      : total={total_nova} root_len={n_nova}")

            # Mostra formas de atendimento do listaCustom (chat vs outros)
            formas: dict[str, int] = {}
            for item in (nova.get("root") or []):
                f = item.get("NomeFormaAtendimento") or "?"
                formas[f] = formas.get(f, 0) + 1
            print(f"  FormasAtendimento : {formas}")


if __name__ == "__main__":
    asyncio.run(main())
