"""Valida a nova implementação de listar_historico_chamado (usando /listaCustom).

Executa o mesmo caminho que a tool do MCP faz — mas usando o código já em
disco (antes do MCP recarregar)."""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskClient  # noqa: E402
from src.historico import listar_historico  # noqa: E402


async def main():
    async with DeskClient.from_env() as client:
        for codigo, chave in [
            ("0426-012054", 1624588),
            ("0426-011314", 1623848),
        ]:
            print("=" * 70)
            print(f"Chamado {codigo} (chave {chave})")
            resultado = await listar_historico(
                client, chave=chave, codigo=codigo,
                limite_texto=200,  # preview curto
                ignorar_cache=True,  # força refetch via novo endpoint
            )
            print(f"  endpoint={resultado['endpoint']} total={resultado['total']}")
            for acao in resultado["acoes"]:
                print(f"    [{acao['sequencia']}] {acao['data_hora']} "
                      f"por={acao['operador']!r:40s} "
                      f"tipo={acao['tipo']!r:15s} publico={acao['publico']}")
                print(f"         status={acao['status']}")
                txt = acao["texto"][:120].replace("\n", " | ")
                print(f"         texto:  {txt}")
                if acao.get("texto_arquivo"):
                    print(f"         ARQ:    {acao['texto_arquivo']}")


if __name__ == "__main__":
    asyncio.run(main())
