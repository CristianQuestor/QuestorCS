"""Captura o tráfego de rede da UI do Desk Manager para descobrir o endpoint
REAL usado ao abrir a tela 'Lista de Conversas' de um chamado.

Fluxo:
1. Abre https://questor.desk.ms/?LoginTicket
2. Faz login com as credenciais fornecidas
3. Captura TUDO (requests, responses, websockets) por 30s
4. Navega para variações de URL de chat do chamado 0426-012054
5. Salva o log completo em scripts/captura_chat.json

Rode com: python scripts/capturar_chat_ui.py
"""
from __future__ import annotations

import asyncio
import json
from datetime import datetime
from pathlib import Path

from playwright.async_api import async_playwright

USUARIO = "fabio"
SENHA = "6n38@JT0"
LOGIN_URL = "https://questor.desk.ms/?LoginTicket"
COD_CHAMADO = "0426-012054"
CHAVE_CHAMADO = 1624588

URLS_EXPLORAR = [
    "https://questor.desk.ms/",
    f"https://questor.desk.ms/Chamado/{COD_CHAMADO}",
    f"https://questor.desk.ms/Chamado/Chat/{COD_CHAMADO}",
    f"https://questor.desk.ms/Chamado/Conversa/{COD_CHAMADO}",
    f"https://questor.desk.ms/Chamado/{CHAVE_CHAMADO}",
    f"https://questor.desk.ms/Conversas/{COD_CHAMADO}",
    f"https://questor.desk.ms/Conversas/{CHAVE_CHAMADO}",
    f"https://questor.desk.ms/Conversas",
    f"https://questor.desk.ms/Chat/{COD_CHAMADO}",
]

OUT = Path(__file__).parent / "captura_chat.json"


async def main():
    requests_log = []
    websockets_log = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            ignore_https_errors=True,
            viewport={"width": 1600, "height": 900},
        )
        page = await context.new_page()

        # --- Listeners ---
        async def on_request(req):
            try:
                post = req.post_data
            except Exception:
                post = None
            requests_log.append({
                "at": datetime.utcnow().isoformat(),
                "phase": "request",
                "method": req.method,
                "url": req.url,
                "resource_type": req.resource_type,
                "headers": {k: v for k, v in req.headers.items() if k.lower() not in ("cookie",)},
                "post_data": (post[:4000] if post else None),
            })

        async def on_response(resp):
            try:
                url = resp.url
                status = resp.status
                ct = resp.headers.get("content-type", "")
                body = None
                if resp.request.resource_type in ("xhr", "fetch"):
                    try:
                        body = await resp.text()
                        if body and len(body) > 6000:
                            body = body[:6000] + "...[TRUNCADO]"
                    except Exception:
                        body = None
                requests_log.append({
                    "at": datetime.utcnow().isoformat(),
                    "phase": "response",
                    "method": resp.request.method,
                    "url": url,
                    "status": status,
                    "content_type": ct,
                    "resource_type": resp.request.resource_type,
                    "body": body,
                })
            except Exception as e:
                requests_log.append({"phase": "response-err", "erro": str(e)})

        def on_websocket(ws):
            entry = {"url": ws.url, "created_at": datetime.utcnow().isoformat(),
                     "frames_sent": [], "frames_received": []}
            websockets_log.append(entry)
            ws.on("framesent", lambda f: entry["frames_sent"].append(
                (f.payload if isinstance(f.payload, str) else f.payload.decode("utf-8", "replace"))[:2000]
            ))
            ws.on("framereceived", lambda f: entry["frames_received"].append(
                (f.payload if isinstance(f.payload, str) else f.payload.decode("utf-8", "replace"))[:2000]
            ))

        page.on("request", on_request)
        page.on("response", on_response)
        page.on("websocket", on_websocket)

        print(f"[1/3] Abrindo {LOGIN_URL}")
        try:
            await page.goto(LOGIN_URL, wait_until="networkidle", timeout=30000)
        except Exception as e:
            print(f"aviso: goto networkidle timeout, continuando: {e}")
        print(f"    url atual: {page.url}")
        print(f"    título: {await page.title()}")

        # Dump do HTML pra achar os seletores
        html_path = Path(__file__).parent / "login_page.html"
        html_path.write_text(await page.content(), encoding="utf-8")
        print(f"    HTML salvo em {html_path}")

        # Tenta múltiplas estratégias de login
        print(f"[2/3] Tentando login com usuario={USUARIO!r}")
        preenchido = False
        for seletor_user in ["input[name='user']", "input[name='usuario']",
                              "input[name='Usuario']", "input[name='login']",
                              "input[name='Login']", "input[type='text']",
                              "input[placeholder*='usu' i]", "#usuario", "#user",
                              "#login"]:
            try:
                if await page.locator(seletor_user).first.is_visible(timeout=1500):
                    await page.locator(seletor_user).first.fill(USUARIO)
                    print(f"    usuário preenchido via {seletor_user}")
                    preenchido = True
                    break
            except Exception:
                continue

        for seletor_senha in ["input[name='password']", "input[name='senha']",
                               "input[name='Senha']", "input[name='Password']",
                               "input[type='password']", "#senha", "#password"]:
            try:
                if await page.locator(seletor_senha).first.is_visible(timeout=1500):
                    await page.locator(seletor_senha).first.fill(SENHA)
                    print(f"    senha preenchida via {seletor_senha}")
                    break
            except Exception:
                continue

        # Submit
        submetido = False
        for seletor_submit in ["button[type='submit']", "input[type='submit']",
                                "button:has-text('Entrar')", "button:has-text('Login')",
                                "button:has-text('Acessar')", "#btnEntrar",
                                "button"]:
            try:
                if await page.locator(seletor_submit).first.is_visible(timeout=1500):
                    await page.locator(seletor_submit).first.click()
                    print(f"    submetido via {seletor_submit}")
                    submetido = True
                    break
            except Exception:
                continue

        if not submetido:
            try:
                await page.keyboard.press("Enter")
                print("    pressionado ENTER")
            except Exception:
                pass

        # Espera navegação pós-login
        try:
            await page.wait_for_load_state("networkidle", timeout=20000)
        except Exception as e:
            print(f"    wait networkidle timeout: {e}")
        await asyncio.sleep(3)
        print(f"    url pós-login: {page.url}")
        print(f"    título pós-login: {await page.title()}")

        # Salva HTML pós-login
        pos_login_html = Path(__file__).parent / "pos_login.html"
        pos_login_html.write_text(await page.content(), encoding="utf-8")
        print(f"    HTML pós-login em {pos_login_html}")

        print(f"[3/3] Navegando para URLs candidatas de chat")
        for url in URLS_EXPLORAR:
            try:
                print(f"    -> {url}")
                await page.goto(url, wait_until="networkidle", timeout=15000)
                await asyncio.sleep(2)
            except Exception as e:
                print(f"       erro: {e}")

        # Salva HTML da última página
        final_html = Path(__file__).parent / "ultima_pagina.html"
        final_html.write_text(await page.content(), encoding="utf-8")

        await browser.close()

    OUT.write_text(json.dumps({
        "requests": requests_log,
        "websockets": websockets_log,
    }, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\nTotal requests capturados: {len(requests_log)}")
    print(f"Total websockets: {len(websockets_log)}")
    print(f"Log completo em {OUT}")


if __name__ == "__main__":
    asyncio.run(main())
