"""Probe para descobrir o endpoint real do chat do Desk.

Contexto: chamado 0426-012054 (chave 1624588) tem conversa de chat ativa
visível na UI (arquivo d:\\Downloads\\conversa.txt ~53 mensagens em 23/04/2026),
mas /ChamadoHistoricos/lista devolve `total: 0`.

Teoria: o chat ao vivo fica em outra entidade até a sessão ser
encerrada/transferida (aí o Desk consolida em ChamadoHistoricos).

Este script tenta vários nomes plausíveis de endpoint + shapes de body.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

# Carrega .env
env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskAPIError, DeskClient  # noqa: E402


CHAVE = 1624588
COD = "0426-012054"

ENDPOINTS = [
    "Conversas",
    "ChatMensagens",
    "ChatMensagem",
    "Mensagens",
    "Chats",
    "Chat",
    "ChamadoChat",
    "ChamadoChats",
    "ChamadoMensagens",
    "ChamadoConversas",
    "ListaConversas",
    "HistoricoChat",
    "HistoricoConversa",
    "Acoes",
    "AcaoChat",
    "ChatAcao",
    "InteracoesChat",
    "ChamadoInteracoes",
    "ChamadoInteracao",
    "Interacoes",
    "ChamadoHistoricoChat",
    "Sessoes",
    "SessaoChat",
    "ChatSessao",
    "ChatSessoes",
    "MensagensChat",
    "ConversaMensagens",
    "ConversaChamado",
]

BODIES = [
    ("chave_str", {"Chave": str(CHAVE)}),
    ("chave_int", {"Chave": CHAVE}),
    ("chavechamado_str", {"ChaveChamado": str(CHAVE)}),
    ("chavechamado_int", {"ChaveChamado": CHAVE}),
    ("codchamado", {"CodChamado": COD}),
    ("filtro_chave", {"Tatual": 0, "Quantidade": 100,
                       "Filtros": [{"Campo": "ChaveChamado", "Valor": CHAVE, "Operador": "="}]}),
    ("filtro_chave_str", {"Tatual": 0, "Quantidade": 100,
                           "Filtros": [{"Campo": "Chave", "Valor": str(CHAVE), "Operador": "="}]}),
]


async def probar():
    resultados: list[dict] = []
    async with DeskClient.from_env() as client:
        for ent in ENDPOINTS:
            for nome_body, body in BODIES:
                url = f"{client.config.api_url}/{ent}/lista"
                try:
                    r = await client._request(
                        "POST",
                        url,
                        json_body=body,
                        timeout=15.0,
                        auth_retry=True,
                    )
                    # sucesso — registra resumo
                    total = r.get("total") if isinstance(r, dict) else None
                    root = r.get("root") if isinstance(r, dict) else None
                    n = len(root) if isinstance(root, list) else None
                    keys = list(r.keys())[:10] if isinstance(r, dict) else None
                    resultados.append({
                        "endpoint": ent, "body": nome_body,
                        "status": "OK", "total": total, "root_len": n,
                        "keys": keys,
                        "sample": (root[0] if isinstance(root, list) and root else None),
                    })
                    print(f"OK {ent}/lista [{nome_body}] total={total} root_len={n} keys={keys}")
                except DeskAPIError as e:
                    code = e.status_code
                    msg = str(e)[:120]
                    # Só loga 200 com erro no body ou 500 (pode revelar que endpoint existe)
                    if code is None or code == 200 or (code and 500 <= code < 600):
                        resultados.append({
                            "endpoint": ent, "body": nome_body,
                            "status": f"HTTP {code}", "erro": msg,
                        })
                        print(f"?? {ent}/lista [{nome_body}] {code}: {msg}")
                    # 404 = endpoint não existe; 400 = existe mas body ruim
                    elif code == 400:
                        resultados.append({
                            "endpoint": ent, "body": nome_body,
                            "status": "HTTP 400 (endpoint existe?)", "erro": msg,
                        })
                        print(f"!! {ent}/lista [{nome_body}] 400: {msg}")
                except Exception as e:
                    print(f"XX {ent}/lista [{nome_body}] {type(e).__name__}: {str(e)[:120]}")

    out = Path(__file__).parent / "probe_chat_resultados.json"
    out.write_text(json.dumps(resultados, indent=2, ensure_ascii=False, default=str),
                   encoding="utf-8")
    print(f"\n→ {len(resultados)} resultados não-404 salvos em {out}")


if __name__ == "__main__":
    asyncio.run(probar())
