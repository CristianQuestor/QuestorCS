"""Lista todos POST para questor.desk.ms + api.desk.ms."""
import json
from pathlib import Path

data = json.loads((Path(__file__).parent / "captura_chat.json").read_text(encoding="utf-8"))

# Index por URL para casar request+response
by_url_method = {}
for e in data["requests"]:
    url = e.get("url", "")
    if "desk.ms" not in url:
        continue
    if "analytics" in url or "hubspot" in url:
        continue
    key = (e.get("method"), url)
    by_url_method.setdefault(key, {"req": None, "resp": None})
    if e.get("phase") == "request":
        by_url_method[key]["req"] = e
    else:
        by_url_method[key]["resp"] = e

print(f"Total URLs Desk distintas: {len(by_url_method)}\n")

for (method, url), info in sorted(by_url_method.items()):
    req = info.get("req") or {}
    resp = info.get("resp") or {}
    status = resp.get("status")
    print("=" * 80)
    print(f"{method} {url}")
    print(f"  status={status}  resource_type={req.get('resource_type')}")
    if req.get("post_data"):
        print(f"  POST DATA: {req['post_data'][:600]}")
    if resp.get("body"):
        body = resp["body"]
        print(f"  RESPONSE ({len(body)}b):")
        print(f"    {body[:1500]}")
    print()
