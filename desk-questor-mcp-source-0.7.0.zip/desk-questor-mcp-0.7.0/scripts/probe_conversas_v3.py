"""Probe v3: explorar rotas da UI do Desk (questor.desk.ms).

A tela do chat no Desk Manager tem título 'Lista de Conversas #0426-012054 Chat Desk Manager'.
Se for UI web renderizada, deve existir uma rota tipo /Chamado/<cod>/Chat ou
/Conversas/<chave>. Vamos probar tanto GET quanto POST.

Também testa endpoints adicionais plausíveis ligados a chat WhatsApp/robô.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.desk_client import DeskAPIError, DeskClient  # noqa: E402


CHAVE = 1624588
COD = "0426-012054"


async def run():
    resultados = []
    async with DeskClient.from_env() as client:
        token = await client._get_token()  # type: ignore

        # Endpoints adicionais plausíveis na api.desk.ms
        api_extras = [
            # Chat via WhatsApp/robô (Desk tem produto WhatsApp integrado)
            "ChatWhats/lista", "WhatsApp/lista", "ChatRobo/lista",
            "ChatMsg/lista", "Mensagem/lista", "Msg/lista",
            # Conversas com extra
            "Conversas/reabrir", "Conversas/abrir", "Conversas/fechar",
            "ConversasChat/lista", "ChamadoConversa/lista",
            # Endpoint descritos em outros CRMs Desk
            "ChatAcoes/lista", "ChatInteracoes/lista",
            "Interacao/lista", "InteracaoChat/lista",
            "UltimasMensagens/lista", "MensagensRecentes/lista",
        ]
        # Extras em /ChamadosSuporte
        cs_extras = [
            "ChamadosSuporte/conversas", "ChamadosSuporte/historicoChat",
            "ChamadosSuporte/mensagens", "ChamadosSuporte/chat/lista",
        ]

        all_api = [f"{client.config.api_url}/{e}" for e in api_extras + cs_extras]

        # URLs "estilo UI" no portal (rotas HTML possíveis)
        portal = "https://questor.desk.ms"
        portal_urls = [
            f"{portal}/Chamado/{COD}/Conversas",
            f"{portal}/Chamado/{COD}/Chat",
            f"{portal}/Chamado/{CHAVE}/Conversas",
            f"{portal}/Chamado/{CHAVE}/Chat",
            f"{portal}/Conversas/{CHAVE}",
            f"{portal}/Conversas/{COD}",
            f"{portal}/ListaConversas/{CHAVE}",
            f"{portal}/ListaConversas/{COD}",
            f"{portal}/Chat/{CHAVE}",
            f"{portal}/Chat/{COD}",
            f"{portal}/Chamado?codigo={COD}&aba=chat",
            f"{portal}/Chamado/Chat/{COD}",
            f"{portal}/Chamado/Conversa/{COD}",
        ]

        # Probe API: POST com {Chave: str}
        for url in all_api:
            try:
                r = await client._request("POST", url,
                                          json_body={"Chave": str(CHAVE)},
                                          timeout=10.0)
            except DeskAPIError as e:
                if e.status_code == 404:
                    continue
                print(f"API FAIL {url} HTTP {e.status_code}: {str(e)[:100]}")
                resultados.append({"url": url, "status": f"HTTP {e.status_code}",
                                   "erro": str(e)[:200]})
                continue
            except Exception as e:
                continue
            if isinstance(r, dict):
                print(f"API OK   {url} keys={list(r.keys())[:8]} total={r.get('total')}")
                resultados.append({"url": url, "status": "OK",
                                   "keys": list(r.keys()), "total": r.get('total')})

        # Probe portal: GET com Authorization (tenta HTML)
        async with httpx.AsyncClient(follow_redirects=False, timeout=10.0) as http:
            for url in portal_urls:
                for method in ["GET", "POST"]:
                    try:
                        resp = await http.request(
                            method, url,
                            headers={"Authorization": token,
                                     "PublicKey": client.config.public_key},
                        )
                    except Exception as e:
                        continue
                    ct = resp.headers.get("content-type", "")
                    snippet = resp.text[:200].replace("\n", " ")
                    if resp.status_code in (404,):
                        continue
                    print(f"PORTAL {method} {url} {resp.status_code} ct={ct} | {snippet}")
                    resultados.append({"url": url, "method": method,
                                       "status": resp.status_code,
                                       "content_type": ct, "snippet": snippet})

    out = Path(__file__).parent / "probe_conversas_v3_resultados.json"
    out.write_text(json.dumps(resultados, indent=2, ensure_ascii=False, default=str),
                   encoding="utf-8")
    print(f"\n-> {len(resultados)} salvos em {out}")


if __name__ == "__main__":
    asyncio.run(run())
