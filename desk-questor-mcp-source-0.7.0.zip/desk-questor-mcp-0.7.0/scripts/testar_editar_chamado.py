"""Testa o /ChamadosSuporte/editarChamado — o endpoint que a UI chama
quando operador abre um chamado. Passa-se a Chave separada (não dentro de Dados).
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlencode

import httpx

env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

COD = "0426-012054"
CHAVE = 1624588


async def login_ui() -> httpx.AsyncClient:
    client = httpx.AsyncClient(follow_redirects=True, timeout=30.0)
    await client.get("https://questor.desk.ms/?LoginTicket")
    dados = {"IdMobile": "", "TypeMobile": "", "Prefixo": "questor",
             "Dispositivo": "", "Login": "fabio", "Senha": "6n38@JT0", "website": ""}
    r = await client.post("https://questor.desk.ms/Suporte/logar",
                           content=urlencode({"Dados": json.dumps(dados)}),
                           headers={"Content-Type": "application/x-www-form-urlencoded"})
    assert r.status_code == 200, r.status_code
    return client


async def main():
    ui = await login_ui()
    print("Login UI OK")

    # /ChamadosSuporte/editarChamado espera Chave + Menu + App (padrão da UI)
    casos = [
        ("ChamadosSuporte/editarChamado",
         {"Chave": CHAVE, "App": "Ticket", "Menu": "ChamadosSuporte"}),
        ("ChamadosSuporte/editarChamado",
         {"Chave": str(CHAVE), "App": "Ticket"}),
        # Sem menu
        ("ChamadosSuporte/editarChamado",
         {"Chave": CHAVE, "App": "Ticket"}),
        # Histórico correto — ajustado sem Forma/Publica/CodAcao
        ("ChamadoHistoricos/listaCustom", {
            "form_app": True,
            "dados": {
                "Ajax": "true",
                "Filtros": {"CodChamado": [str(CHAVE), "equal"]},
                "Colunas": {
                    "Chave": "on", "CodChamado": "on", "Descricao": "on",
                    "DescricaoAbrev": "on", "DataAcao": "on",
                    "HoraAcaoInicio": "on", "HoraAcaoFim": "on",
                    "NomeOperador": "on", "CodOperador": "on",
                    "NomeStatus": "on", "CodStatus": "on",
                    "NomeFormaAtendimento": "on", "CodFormaAtendimento": "on",
                    "NomeCausa": "on",
                },
            },
        }),
    ]

    for endpoint, payload in casos:
        print("\n" + "=" * 70)
        print(f"POST questor.desk.ms/{endpoint}")
        if "form_app" in payload:
            form_data = urlencode({"Dados": json.dumps(payload["dados"]), "App": "Ticket"})
        else:
            form_data = urlencode(payload)
        print(f"  body: {form_data[:200]}")
        try:
            r = await ui.post(f"https://questor.desk.ms/{endpoint}",
                               content=form_data,
                               headers={
                                   "Content-Type": "application/x-www-form-urlencoded",
                                   "Accept": "application/json",
                               })
        except Exception as e:
            print(f"  ERR: {e}")
            continue
        print(f"  status={r.status_code} bytes={len(r.text)}")
        # Salva response completo em arquivo — pode ser grande
        name = endpoint.replace("/", "_")
        fname = Path(__file__).parent / f"resp_{name}.json"
        fname.write_text(r.text, encoding="utf-8")
        print(f"  salvo em {fname.name}")
        print(f"  preview: {r.text[:1200]}")

    await ui.aclose()


if __name__ == "__main__":
    asyncio.run(main())
