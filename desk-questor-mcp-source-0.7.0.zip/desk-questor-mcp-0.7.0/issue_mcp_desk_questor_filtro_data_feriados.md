# Issue MCP `desk-questor` — Filtro de data em chamados ativos + feriados nacionais

**Data:** 21/04/2026 (Tiradentes)
**Solicitante:** Fabio Puhl (CTO)
**Repositório alvo:** `D:\WorkSpace\desk-questor-mcp\`
**Prioridade:** P0 (feature 1) / P1 (feature 2)

---

## Contexto

O MCP `desk-questor` hoje só permite listar chamados **criados no dia corrente** (`listar_chamados_ativos_hoje`). Isso é suficiente para o loop de monitoramento do N3, mas **impede análises gerenciais básicas** como:

- "Quantos chamados de ontem ficaram sem primeira resposta?"
- "Qual o passivo acumulado da fila X nos últimos 7 dias?"
- "Quantos clientes estão há mais de 48h esperando atendimento?"

Em 20–21/04/2026 foi identificada a necessidade concreta dessa capacidade: com feriado nacional no dia 21, qualquer análise retrospectiva fica bloqueada sem filtro de data.

Adicionalmente, foi identificado que o campo `horas_uteis_aberto` desconta sábado/domingo, **mas não desconta feriados nacionais**, o que distorce indicadores em dias como hoje.

---

## Feature 1 (P0) — Nova tool `listar_chamados_ativos` com filtros de data

### Problema

Hoje só temos `listar_chamados_ativos_hoje` que implicitamente filtra `DataCriacao = hoje`. Não há como consultar chamados de períodos anteriores, nem filtrar por data de alteração, operador ou combinações.

### Comportamento esperado

Nova tool `listar_chamados_ativos` com os seguintes parâmetros:

```python
listar_chamados_ativos(
    data_criacao_de: Optional[str] = None,    # "YYYY-MM-DD"
    data_criacao_ate: Optional[str] = None,   # "YYYY-MM-DD"
    data_alteracao_de: Optional[str] = None,  # "YYYY-MM-DD"
    data_alteracao_ate: Optional[str] = None, # "YYYY-MM-DD"
    grupo: Optional[str] = None,              # mesmo contrato do listar_chamados_ativos_hoje
    operador: Optional[str] = None,           # nome parcial ou exato
    status: Optional[List[str]] = None,       # ex.: ["Andamento", "Aguardando Atendimento"]
    sla_expirado: Optional[bool] = None,
    sem_operador: Optional[bool] = None,      # filtro "não atribuído"
    apenas_ativos: bool = True,               # default True — exclui finalizados
    limite: int = 500,                        # teto 2000 para análises retroativas
    ordem: str = "tempo_aberto_desc"
)
```

### Retorno

Mesmo schema enriquecido já usado em `listar_chamados_ativos_hoje`:

- `chave`, `codigo`, `assunto`, `status`, `grupo`, `cliente_nome_completo`
- `operador`, `operador_chave`, `operador_online`, `operador_grupo_principal`
- `data_criacao`, `hora_criacao`, `data_alteracao`, `hora_alteracao`
- `horas_aberto`, `horas_uteis_aberto`, `horas_sem_resposta`
- `qt_acoes`, `total_anexos`, `urgencia`
- `sla1_expirado`, `sla2_expirado`, `tempo_restante_sla1`, `tempo_restante_sla2`

### Retrocompatibilidade

Manter `listar_chamados_ativos_hoje` funcionando. Ela vira um **alias interno**:

```python
def listar_chamados_ativos_hoje(params):
    hoje = date_hoje_brt().isoformat()
    return listar_chamados_ativos(
        params.model_copy(update={
            "data_criacao_de": hoje,
            "data_criacao_ate": hoje
        })
    )
```

### Casos de uso a validar (smoke test)

```python
# 1. Passivo retroativo de 1 dia
listar_chamados_ativos(
    data_criacao_de="2026-04-20",
    data_criacao_ate="2026-04-20",
    apenas_ativos=True
)
# → deve retornar chamados de 20/04 ainda abertos

# 2. Chamados sem primeira resposta de ontem
listar_chamados_ativos(
    data_criacao_de="2026-04-20",
    data_criacao_ate="2026-04-20",
    status=["Aguardando Atendimento"],
    sem_operador=True
)

# 3. Janela de 7 dias da fila Folha
listar_chamados_ativos(
    data_criacao_de="2026-04-14",
    data_criacao_ate="2026-04-20",
    grupo="Suporte - Folha de Pagamento",
    limite=2000
)

# 4. Atividade específica de um operador em janela
listar_chamados_ativos(
    data_alteracao_de="2026-04-20",
    data_alteracao_ate="2026-04-20",
    operador="Jessica"
)
```

### Critério de aceitação

- [ ] Tool aceita todos os parâmetros acima e valida formato de data (`YYYY-MM-DD`).
- [ ] Sem nenhum filtro de data, retorna todos os chamados ativos (respeitando `limite`).
- [ ] Combinação de filtros funciona com AND (ex.: grupo + data_criacao + sem_operador).
- [ ] Schema de retorno idêntico ao de `listar_chamados_ativos_hoje`.
- [ ] `listar_chamados_ativos_hoje` continua funcionando sem alteração de contrato.
- [ ] Performance: retorno de até 2000 chamados em ≤ 15s.
- [ ] Erro claro quando `data_criacao_de > data_criacao_ate`.

### Sugestão de implementação

Olhar como `listar_chamados_ativos_hoje` hoje monta o payload da rota `ChamadosFiltros/lista` no Desk Manager. A API do Desk aceita filtros de data na consulta — basta repassar os parâmetros recebidos para o body da requisição. Não deve exigir um endpoint novo, só generalizar o existente.

Se a API do Desk limitar o retorno (ex.: teto de 500 por request), implementar paginação interna e montar o resultado unificado.

---

## Feature 2 (P1) — `horas_uteis_aberto` deve descontar feriados nacionais

### Problema

Hoje (21/04/2026, feriado de Tiradentes), chamados abertos pela manhã aparecem com `horas_uteis_aberto` entre 5h e 11h — **contagem corrida**, sem qualquer desconto.

Exemplo do retorno real de hoje:

```json
{
  "codigo": "0426-012038",
  "hora_criacao": "08:22:12",
  "horas_aberto": 11.18,
  "horas_uteis_aberto": 11.18   // ← deveria ser 0, é feriado nacional
}
```

O comportamento atual equipara feriado a dia útil, o que distorce:

- Métrica de SLA (se calculada em cima desse campo).
- Classificação de `urgencia` (alto/medio/baixo).
- Análises de backlog ("X horas sem resposta").

### Comportamento esperado

`horas_uteis_aberto` deve considerar como **não-úteis**:

1. Sábados
2. Domingos
3. **Feriados nacionais brasileiros** (fixos + móveis)
4. (Opcional — ver nota abaixo) Feriados municipais de Chapecó/SC onde fica a matriz

Para o dia de hoje, `horas_uteis_aberto` de todos os 13 chamados deveria ser **0**.

### Sugestão de implementação

Usar a biblioteca [`holidays`](https://pypi.org/project/holidays/) (já madura em Python):

```python
import holidays
from datetime import datetime, timedelta

BR_HOLIDAYS = holidays.country_holidays('BR', years=range(2024, 2031))

def eh_dia_util(dt: datetime) -> bool:
    # weekday(): 0=seg ... 5=sáb, 6=dom
    if dt.weekday() >= 5:
        return False
    if dt.date() in BR_HOLIDAYS:
        return False
    return True

def horas_uteis_entre(inicio: datetime, fim: datetime) -> float:
    """
    Soma horas (decimal) apenas dos intervalos em dias úteis.
    Implementação simples varrendo dia a dia — suficiente para janelas de dias/semanas.
    Para janelas maiores, otimizar com pré-cálculo.
    """
    total = 0.0
    cursor = inicio
    while cursor < fim:
        prox_dia = (cursor + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        fim_intervalo = min(prox_dia, fim)
        if eh_dia_util(cursor):
            total += (fim_intervalo - cursor).total_seconds() / 3600
        cursor = fim_intervalo
    return round(total, 2)
```

### Nota sobre feriados municipais

Sugestão: expor uma configuração opcional no MCP (ex.: variável de ambiente `DESK_QUESTOR_FERIADOS_EXTRAS`) aceitando lista de datas adicionais em `YYYY-MM-DD`. Default vazio. Assim dá para adicionar feriados municipais sem hardcoding.

### Critério de aceitação

- [ ] Biblioteca `holidays` adicionada às dependências.
- [ ] Hoje (21/04/2026) qualquer chamado retorna `horas_uteis_aberto = 0`.
- [ ] Chamado criado sexta 17h → consultado segunda 09h → `horas_uteis_aberto ≈ 1.0` (uma hora útil, considerando fim de expediente sexta e início segunda).
- [ ] Chamado criado 23/12/2026 (véspera) → consultado 27/12/2026 → desconta 25/12 (Natal).
- [ ] Configuração `DESK_QUESTOR_FERIADOS_EXTRAS` funcional.
- [ ] Testes unitários cobrindo: sábado, domingo, Tiradentes, Natal, combinações.

### Escopo expandido (opcional, ideal)

Além do feriado, considerar **horário comercial** (ex.: 08h–18h em dias úteis). Se o time considera relevante, adicionar:

```python
HORA_INICIO_COMERCIAL = 8   # 08:00
HORA_FIM_COMERCIAL = 18     # 18:00
```

Deixar o parâmetro configurável via env vars. Se implementado, `horas_uteis_aberto` passa a refletir horas de expediente efetivas.

---

## Observações gerais

### O que NÃO é escopo desta issue

Os seguintes itens são trackeados em outros MDs e **não** devem ser tocados aqui:

- **Autenticação do endpoint `ChamadoHistoricos`** — já resolvido na última iteração (a tool `listar_historico_chamado` está funcionando).
- **Bugs laterais do `obter_chamado`** — já resolvidos (enriquecimento de operador + resolução de CodChamado).

### Testes e validação

Adicionar ao conjunto de smoke tests do MCP as 4 chamadas de validação da Feature 1 e os 4 casos de `horas_uteis_aberto` da Feature 2.

### Atualização de documentação

Após implementação, atualizar o `README.md` do MCP com:

- Nova tool `listar_chamados_ativos` documentada.
- Observação sobre `horas_uteis_aberto` agora considerar feriados.
- Como configurar `DESK_QUESTOR_FERIADOS_EXTRAS`.

---

## Definition of Done

- [ ] Feature 1 implementada com todos os casos de uso passando.
- [ ] Feature 2 implementada com testes unitários verdes.
- [ ] `listar_chamados_ativos_hoje` continua funcionando sem regressão.
- [ ] Smoke tests rodando no CI (se houver) ou documentados no `README`.
- [ ] MCP recarregado no ambiente do Fabio (Claude Desktop) e validado com:
  - Pergunta: "Quantos chamados de 20/04/2026 ficaram sem primeira resposta?"
  - Resposta deve vir em uma única chamada da nova tool, não em 251 chamadas individuais.

---

**Referência histórica:**

- `investigacao_endpoint_historico_desk_v3.md` — sessão que destravou o histórico.
- `melhorias_mcp_desk_questor_v2.md` — diagnóstico consolidado que originou estas features.
