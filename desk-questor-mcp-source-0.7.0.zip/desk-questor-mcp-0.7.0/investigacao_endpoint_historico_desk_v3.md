# Investigação — Endpoint de Histórico de Chamados (API Desk Manager) — v3

**Data:** 20/04/2026 (segunda iteração da tarde)
**Versão anterior:** `investigacao_endpoint_historico_desk_v2.md`
**Responsável pela execução:** Fabio Puhl
**MCP envolvido:** `desk-questor` (tool `listar_historico_chamado`)

---

## 0. Evolução v1 → v2 → v3

| Aspecto | v1 | v2 | **v3 (agora)** |
|---|---|---|---|
| Endpoints testados | 8 variações, todas 404 | Rota correta identificada: `ChamadoHistoricos(form)` | Mesma rota, **duas estratégias de autenticação** tentadas |
| Natureza do erro | 404 — rota não existe | "Token expirado" — rota existe, auth falha | **500 no login auto + "Token expirado" no backreq** |
| Estratégias do wrapper | 1 (chamada direta) | 1 (com token padrão) | **2 (login renovado + backreq)** |

O problema estreitou. Cada iteração elimina hipóteses. Restou um bloqueio bem delimitado: **o fluxo de autenticação esperado pela API do Desk para o módulo de histórico é diferente e ainda não foi reproduzido pelo wrapper.**

---

## 1. Erro atual (completo)

Testado em 20/04 tarde, com códigos `0426-011564` e `0426-011707` — comportamento **idêntico** nos dois:

```
Nenhum endpoint de histórico respondeu para este tenant
(tentado:
   ChamadoHistoricos(form,login)   → Falha após 3 tentativas: HTTP 500
   ChamadoHistoricos(form,backreq) → Erro retornado pela API: Token expirado ou não existe)
Último erro: Erro retornado pela API: Token expirado ou não existe
```

---

## 2. Leitura das duas estratégias

| Estratégia | O que o wrapper faz | Resposta do servidor | Interpretação |
|---|---|---|---|
| `form,login` | Dispara login novo antes de chamar histórico | HTTP 500 após 3 tentativas | O endpoint de login está rejeitando o fluxo — payload/credencial/header do login auto não está no formato esperado, OU credencial atual não tem permissão de login direto na API |
| `form,backreq` | Reaproveita token/contexto da requisição anterior bem-sucedida | "Token expirado ou não existe" | Token que é válido para `ChamadosFiltros`, `OperadoresFiltros` etc. **não é aceito** em `ChamadoHistoricos` — confirma definitivamente que o escopo/autenticação é outro |

**Conclusão central:** a autenticação do módulo de histórico do Desk Manager não é herdada das outras rotas. Precisa de um handshake próprio que o wrapper ainda não conhece.

---

## 3. Questionamento central (refinado em v3)

**Como o frontend oficial do Desk Manager autentica a chamada `POST /ChamadoHistoricos/lista`?**

Perguntas-filhas:

1. O frontend dispara um login/refresh dedicado antes de chamar essa rota?
2. Existe **cookie de sessão** persistente (ex.: `ASP.NET_SessionId`, `desk_session`) que acompanha essa chamada e que o wrapper não está reenviando?
3. Há algum **header específico** (ex.: `X-Desk-Context`, `X-Tenant`, `Referer` obrigatório) que o backend valida só nesse endpoint?
4. A API exige **CSRF token** emitido numa chamada prévia (ex.: `/autenticacao/token`)?
5. O "login auto" do wrapper está usando usuário/senha configurados, mas o fornecedor pode estar esperando fluxo OAuth/JWT/SSO?

---

## 4. Bugs laterais — status atual

### 4.1 `obter_chamado(chave=X, incluir_historico=true)` — **AINDA NÃO CORRIGIDO**

Retorno atual:

```json
"historico": {
  "chave": 1624098,
  "total": 0,
  "acoes": [],
  "erro": "Não consegui resolver CodChamado para chave=1624098. Passe 'codigo' explicitamente."
}
```

O `raw.TChamado.CodChamado = "0426-011564"` está disponível na mesma resposta. Wrapper não está fazendo a ponte interna. Fix trivial, independente do bloqueio principal de autenticação.

### 4.2 Enriquecimento do operador em `obter_chamado` — **NOVO BUG IDENTIFICADO**

Testado em 20/04 tarde: `obter_chamado(chave=1624098)` retornou:

```json
{
  "operador": null,
  "operador_chave": null,
  "operador_online": null,
  "operador_grupo_principal": null
}
```

Porém, em `raw.TChamado.CodOperador` está presente:

```json
"CodOperador": [{"id": "605", "text": "Analice Franceschi"}]
```

O enriquecimento só está funcionando em `listar_chamados_ativos_hoje`. Precisa ser replicado em `obter_chamado` (mesma lógica de join com `listar_operadores`).

---

## 5. Observação de bastidor — dados são tempo real

Comparando dois `obter_chamado` feitos em sessões diferentes sobre a **mesma chave** `1624098`:

| Campo | Sessão manhã (11:30) | Sessão tarde (14:00) |
|---|---|---|
| Operador | Jessica Peruzzo (id 194) | **Analice Franceschi (id 605)** |
| `CodGrupo` | `000036` | **`000037`** |
| `TAcoes` | 2 | **3** |
| `SegundoAtendimento` | N | N |
| `Sla1Expirado` | S | S |
| `Sla2Expirado` | S | S |

**O chamado foi transferido entre filas e recebeu nova ação.** O dado que o MCP entrega é instantâneo e refletindo o estado real do Desk — isso é bom sinal de robustez da integração.

**Implicação:** o histórico, quando destravar, permitirá auditar transferências entre filas, mudanças de operador e natureza de cada interação. Essa transferência específica (de CodGrupo 000036 para 000037) hoje só é perceptível por diff de snapshots — com histórico, vira evento auditável.

---

## 6. Roteiro de ação (refinado)

### Passo 1 (CRÍTICO) — Captura F12 no Desk Web

**Objetivo:** capturar os headers/cookies exatos que o frontend envia em `POST /ChamadoHistoricos/lista`.

1. Login no Desk Web com usuário de suporte.
2. F12 → Network → filtro `chamadohistoricos` (ou XHR).
3. Abrir chamado `0426-011564` e clicar em Histórico/Interações.
4. **Anotar**, para a requisição `ChamadoHistoricos/lista`:
   - Todos os headers da requisição (`Authorization`, `Cookie`, `X-*`, `Content-Type`, `Referer`)
   - Body completo (form-encoded)
   - Se houver requisição **imediatamente anterior** (ex.: `/autenticacao/login`, `/session`, `/token`), capturar também — pode ser o handshake que falta
5. Comparar com requisição para `ChamadosFiltros/lista` (que funciona no MCP) — a diferença revela o que falta.

### Passo 2 (EM PARALELO) — Corrigir os dois bugs laterais

Não dependem do Passo 1. O time pode liberar em PR separado:

- **Bug 4.1:** em `obter_chamado`, extrair `raw.TChamado.CodChamado` e passar para `listar_historico_chamado`.
- **Bug 4.2:** em `obter_chamado`, fazer o mesmo join com `listar_operadores` que já é feito em `listar_chamados_ativos_hoje`.

### Passo 3 (EM PARALELO) — Implementar filtro de data

Lacuna #2 da v2 das melhorias, ainda pendente: nova tool `listar_chamados_ativos` com `data_criacao_de`/`data_criacao_ate` (mantendo `listar_chamados_ativos_hoje` como alias).

### Passo 4 (SE PASSO 1 NÃO RESOLVER) — Contato com fornecedor

Mensagem sugerida:

> Com o token padrão da API (que funciona em `ChamadosFiltros/lista`, `OperadoresFiltros/lista`, `GruposFiltros/lista`), tentamos acessar `ChamadoHistoricos/lista` e recebemos consistentemente `"Token expirado ou não existe"`. Ao tentar login renovado antes da chamada, recebemos HTTP 500. Existe escopo, permissão, header específico ou fluxo de autenticação dedicado para o endpoint de histórico que precisamos replicar?

---

## 7. Checklist atualizado

**Lacuna #1 — Histórico de ações**

- [x] URL real: `https://api.desk.ms/ChamadoHistoricos/lista`
- [x] Método: POST
- [x] Formato: `form` (application/x-www-form-urlencoded)
- [x] Tool `listar_historico_chamado` aceita `codigo` (CodChamado string)
- [x] Wrapper tenta 2 estratégias de auth (login, backreq)
- [ ] **Autenticação específica do módulo de histórico descoberta e replicada**
- [ ] Shape da resposta confirmado
- [ ] Retorno populado em chamados reais (0426-011564, 0426-011707)
- [ ] Distinção clara entre ação pública e comentário interno

**Bugs laterais**

- [ ] `obter_chamado(incluir_historico=true)` resolve CodChamado internamente
- [ ] `obter_chamado` enriquece `operador_online`, `operador_chave`, `operador_grupo_principal`

**Lacuna #3 — Presença do operador**

- [x] Funciona em `listar_chamados_ativos_hoje`
- [ ] Funciona em `obter_chamado` (ver bug 4.2)

**Lacuna #2 — Filtro de data e horas úteis**

- [x] Campo `horas_uteis_aberto` existe
- [ ] Fórmula validada com chamado que atravessa fim de semana
- [ ] Tool com filtros de `data_criacao_de`/`data_criacao_ate`

---

## 8. Ganhos analíticos consolidados (independentes do histórico)

Mesmo com o histórico ainda bloqueado, a sessão confirmou **quatro capacidades novas**:

1. **Detecção de chamado atribuído a operador offline** (lacuna #3 cobre).
2. **Visibilidade de realocação cruzada entre filas** — exemplo: Jessica Peruzzo (grupo principal "ERP Questor Empresarial") atendendo chamado de "Folha de Pagamento" em 20/04 manhã.
3. **Auditoria de transferência entre filas entre snapshots** — caso `0426-011564` mudou de `CodGrupo 000036` para `000037` e trocou operador entre duas consultas do mesmo dia.
4. **Carga real por operador** — já possível via listagem + agregação, sem precisar do histórico.

---

## 9. Próximo movimento recomendado

**Prioridade única do momento:** executar o Passo 1 (F12 no Desk Web). Qualquer investimento no wrapper antes disso é tentativa cega.

Em paralelo, o time pode liberar os dois bugs laterais (4.1 e 4.2) sem bloqueio — são correções de 15 minutos cada e já destravam `obter_chamado` como ponto único para análise de um chamado específico.

Quando o histórico destravar, valida-se o smoke test completo:

```text
listar_historico_chamado(codigo="0426-011564") → {total: >0, acoes: [...] com tipo, publico, texto}
obter_chamado(chave=1624098, incluir_historico=true) → historico populado (não mais {total:0, erro:...})
obter_chamado(chave=1624098) → operador_online preenchido
```
