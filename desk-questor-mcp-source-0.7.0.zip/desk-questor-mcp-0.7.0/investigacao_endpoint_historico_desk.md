# Investigação — Endpoint de Histórico de Chamados (API Desk Manager)

**Data:** 20/04/2026
**Responsável pela execução:** Fabio Puhl
**MCP envolvido:** `desk-questor` (tool `listar_historico_chamado`)
**Status:** ✅ RESOLVIDO via inspeção do workflow n8n `7L2r516aXil2ZGZW` — ver seção "Resolução" no final.

---

## Questionamento

**Qual é a rota REST correta, em `https://api.desk.ms`, que retorna o histórico de ações/interações de um chamado?**

Secundariamente:
- Essa rota existe na API pública deste tenant?
- Se existir, qual o payload de requisição esperado (nome do filtro: `ChaveChamado`, `Chave`, outro)?
- Se não existir, qual a alternativa suportada pelo fornecedor (webhook, exportação, SDK)?

---

## Evidências coletadas

O wrapper MCP `desk-questor` já testa **8 variações** de endpoint. Todas retornam **HTTP 404** neste tenant.

Endpoints já testados e descartados:

| # | Rota | Filtro |
|---|---|---|
| 1 | `ChamadoHistoricos` | `Filtros[ChaveChamado]` |
| 2 | `ChamadosHistoricos` | `Filtros[ChaveChamado]` |
| 3 | `ChamadosHistorico` | `Filtros[ChaveChamado]` |
| 4 | `HistoricoChamado` | `Filtros[ChaveChamado]` |
| 5 | `Historico` | `Filtros[ChaveChamado]` |
| 6 | `Acoes` | `Filtros[ChaveChamado]` |
| 7 | `ChamadoHistoricos` | `Filtros[Chave]` |
| 8 | `ChamadosHistoricos` | `Filtros[Chave]` |

Último erro observado:
```
HTTP 404 em https://api.desk.ms/ChamadosHistoricos/lista
```

Chaves usadas como canário (podem ser reaproveitadas):
- `1624098` (chamado `0426-011564` — Suporte ERP Pequenas Empresas)
- `1624241` (chamado `0426-011707` — Suporte ERP Pequenas Empresas)

Ambos possuem `TAcoes > 0` no objeto `TChamado`, portanto **existem ações registradas** — o dado existe, falta o endpoint.

---

## Roteiro de investigação (ordem sugerida — do mais barato ao mais caro)

### Passo 1 — Inspeção de rede no Desk Web (5 min, maior chance de sucesso)

1. Entrar no Desk Manager web com usuário de suporte.
2. Abrir o chamado `0426-011564` (chave `1624098`).
3. F12 → aba **Network** → filtro `XHR`/`Fetch`.
4. Clicar na aba/seção de "Histórico", "Interações" ou "Ações" do chamado.
5. **Anotar a primeira requisição disparada** — URL completa, método, payload, resposta.

Campos que precisamos extrair:
- **URL exata** (ex.: `https://api.desk.ms/?????/lista`)
- **Método** (POST provavelmente)
- **Filtro no body** (como o frontend referencia o chamado)
- **Shape da resposta** (array direto? envelopado em `{Dados: [...]}`?)

### Passo 2 — Confronto com documentação oficial

- Verificar se o fornecedor (Desk Manager / `desk.ms`) publica referência da API pública.
- Confirmar se o endpoint descoberto no Passo 1 está documentado ou é interno.
- Validar se o token em uso tem permissão para a rota.

### Passo 3 — Contato com fornecedor (se Passos 1–2 não bastarem)

Abrir chamado no suporte do próprio Desk Manager perguntando explicitamente:
> "Qual endpoint REST da API pública retorna o histórico de ações/interações de um chamado, dado a `Chave` ou `CodChamado`?"

### Passo 4 — Fallback (se não houver API REST)

Avaliar com o time interno:
- Webhook de ações disparado a cada interação?
- Exportação periódica de ações para o Datalake?
- Acesso direto ao banco, se aplicável?

---

## Checklist de validação

- [x] URL real do endpoint de histórico identificada: `https://api.desk.ms/ChamadoHistoricos/lista`
- [x] Método HTTP: `POST`
- [x] Nome do filtro no payload: `CodChamado` (string `"0426-011564"`, NÃO `ChaveChamado` numérico) + `Solicitante=S`
- [x] Shape da resposta confirmado: `{"root": [...], "total": N}`
- [x] Permissão/token validada: exige `Authorization: {DESK_BACKREQTOKEN}` (cred n8n #16), NÃO o token do login
- [x] Wrapper MCP ajustado (`desk-questor-mcp` v0.3.0, módulo `src/historico.py`)
- [ ] `listar_historico_chamado(codigo="0426-011564")` retorna `{total, acoes[]}` não-vazio — **aguarda reinício do Claude Desktop para smoke test**
- [ ] Cada ação distingue `tipo` público vs. interno — **aguarda smoke test**
- [ ] Smoke test com chaves `1624098` e `1624241` passa — **aguarda smoke test**

---

## Saída esperada quando destravado

```json
{
  "chave": 1624098,
  "total": 2,
  "acoes": [
    {
      "sequencia": 1,
      "data_hora": "2026-04-20 09:40:12",
      "operador": "Jessica Peruzzo",
      "tipo": "Resposta Pública",
      "publico": true,
      "texto": "...",
      "anexos": []
    },
    {
      "sequencia": 2,
      "data_hora": "2026-04-20 10:15:44",
      "operador": "Jessica Peruzzo",
      "tipo": "Comentário Interno",
      "publico": false,
      "texto": "...",
      "anexos": []
    }
  ]
}
```

Sem isso, toda análise qualitativa sobre atendimento continua cega — não há como distinguir "respondeu o cliente" de "apenas mudou status".

---

## Resolução (20/04/2026, tarde)

A resposta veio por **inspeção do workflow n8n `7L2r516aXil2ZGZW`** (nome: `Desk_MS_Pegar ChamadoHistoricos`, 64 nodes). Consulta direta ao banco do n8n via Metabase (DB id 14, tabela `workflow_entity`, campo `nodes`).

### Contrato real do endpoint

| Atributo | Valor |
|---|---|
| URL | `POST https://api.desk.ms/ChamadoHistoricos/lista` |
| Content-Type | **`application/x-www-form-urlencoded`** (não JSON) |
| Authorization | **`DESK_BACKREQTOKEN`** (cred n8n #16 "Header Auth account Desk MS BackReqToken") |
| Body | `Solicitante=S&CodChamado=<codigo-string>` |
| Chave do chamado | **`CodChamado`** (string tipo `"0426-011564"`), NÃO `Chave` nem `ChaveChamado` |

### Por que as 8 tentativas anteriores falhavam

Todas usavam o padrão do MCP para os demais endpoints do Desk:
- Content-Type `application/json` ➜ este endpoint exige form.
- `Authorization` com o token do login ➜ este endpoint exige o BackReqToken estático.
- Filtro em `ChaveChamado` numérico ➜ este endpoint filtra por `CodChamado` string.

Qualquer uma dessas três divergências, isoladamente, basta para retornar 404 no Desk — ele não "disambigua" payload, simplesmente 404 quando a rota+auth+contrato não batem.

### Ajustes entregues no wrapper (`desk-questor-mcp` 0.3.0)

- `src/desk_client.py`: `_request` passou a aceitar `auth_mode=("login"|"backreq")` e `form_body=…`; novo helper `listar_form()`.
- `src/historico.py`: reescrito — chama `ChamadoHistoricos/lista` com form+BackReqToken+CodChamado. Quando recebe `chave` resolve `CodChamado` automaticamente via `ChamadosSuporte`. Mantém fallback JSON para compatibilidade.
- Tool MCP `listar_historico_chamado` agora aceita `codigo: str` além de `chave: int`. Preferir `codigo`.
- Memória global (`desk_api_auth.md`) atualizada descrevendo os dois modos de auth.

### Pré-requisito operacional

Todo ambiente que for rodar o MCP agora precisa de `DESK_BACKREQTOKEN` preenchido no `.env`. Antes era opcional; agora é obrigatório para a tool de histórico funcionar.

---

## Resolução 2 (20/04/2026, tarde — v0.4.0)

Smoke test com o MCP instalado reproduziu o problema mesmo após a versão 0.3.0:

```
ChamadoHistoricos(form,login) → HTTP 500
ChamadoHistoricos(form,backreq) → "Token expirado ou não existe"
```

- **`backreq`** falhou porque o BackReqToken estático estocado no n8n (cred #16) **expirou há meses** — coleta da tabela `desk_chamadohistoricos_dados` no datalake parou em **2024-12-31** e os workflows que alimentam (`AiU6VSQx9R52gXtd`, `7L2r516aXil2ZGZW`) estão **inativos** por isso.
- **`login`** falhou porque o MCP fazia login em `questor.desk.ms/Login/autenticar` com body JSON. Esse token **funciona para `/ChamadosSuporte/lista`** mas retorna **HTTP 500** em `/ChamadoHistoricos/lista`.

### O caminho que funciona (workflow ATIVO `9zwhoKQ6kEsBw0xb`)

```
POST https://api.desk.ms/Login/autenticar          ← note: api.desk.ms, não questor.desk.ms
Content-Type: application/x-www-form-urlencoded    ← form, não JSON
Authorization: {DESK_AUTH_HEADER}
Body: PublicKey={DESK_PUBLIC_KEY}
```

O token devolvido aqui tem escopo diferente e é aceito pelo endpoint de histórico.

### Ajustes entregues na v0.4.0

- `src/desk_client.py`:
  - `DeskConfig` ganhou campo `login_body_format` ("form" | "json").
  - Default do `DESK_LOGIN_URL` virou `https://api.desk.ms/Login/autenticar` com body form.
  - `_fetch_token` manda body form-urlencoded quando configurado (default).
- `.env.example` atualizado com a nova URL padrão e o flag `DESK_LOGIN_BODY_FORMAT`.
- `src/historico.py` simplificado: 1 tentativa via form+login (caminho canônico); BackReqToken virou fallback opcional.

### Pré-requisitos atualizados

- `DESK_BACKREQTOKEN` voltou a ser **opcional** (era obrigatório na v0.3.0).
- `DESK_AUTH_HEADER` e `DESK_PUBLIC_KEY` continuam obrigatórios.
- Quem tinha `.env` com `DESK_LOGIN_URL=https://questor.desk.ms/...` precisa remover a linha ou setar `DESK_LOGIN_BODY_FORMAT=json` explicitamente.
