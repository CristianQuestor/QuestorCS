# MCP Desk Questor — Especificação Técnica

> Documento para o Claude Code construir o `desk-questor-mcp`, que permitirá a um agent monitorar e apoiar atendimentos do Desk Manager (desk.ms) em tempo real, com contexto completo.

## Objetivo

Construir um MCP Server que expõe tools para um agent Claude:
1. Listar chamados ativos do dia
2. Ler detalhes e histórico completo de um chamado
3. Buscar chamados similares (resolvidos no passado)
4. Comentar/atualizar chamados
5. Suportar um loop de monitoramento que cruze dados do Desk com Redmine, Metabase e código fonte para gerar sugestões úteis ao N3

## Stack

- **Python** com **FastMCP** (mesmo padrão dos outros MCPs Questor: `redmine-questor`, `quiara`, `google-chat-questor`)
- **httpx** para chamadas HTTP (async)
- **pydantic** para validação
- Autenticação via variáveis de ambiente (`.env`)
- Logs estruturados
- Repositório: `D:\WorkSpace\desk-questor-mcp`

## Autenticação — CRÍTICO

A API do Desk exige **DUAS credenciais distintas** em dois endpoints diferentes:

### 1. Obter Token (login)
```
POST https://questor.desk.ms/Login/autenticar
Headers:
  Authorization: {DESK_AUTH_HEADER}
Body (form-urlencoded ou JSON):
  PublicKey={DESK_PUBLIC_KEY}
Response: texto puro (NÃO é JSON) contendo o token
```

### 2. Chamar API de dados
```
POST https://api.desk.ms/{entidade}/lista
Headers:
  Authorization: {DESK_BACKREQTOKEN}   ← credencial DIFERENTE da de login
Content-Type: application/json
Body: JSON com parâmetros
```

### Variáveis de ambiente (.env)
```env
DESK_AUTH_HEADER=682fc7016507f977c4802ca5b6be2ef9416a4e16
DESK_PUBLIC_KEY=b76b021790284b250d99941cadb8d4aee70e2157
DESK_BACKREQTOKEN={pegar do n8n credencial id=16 "Header Auth account Desk MS BackReqToken"}
DESK_LOGIN_URL=https://questor.desk.ms/Login/autenticar
DESK_API_URL=https://api.desk.ms
```

O token obtido no login tem validade curta — o MCP deve fazer cache e renovar automaticamente quando expirar.

## Endpoints conhecidos

| Entidade | Endpoint | Uso |
|---|---|---|
| ChamadosSuporte | `/ChamadosSuporte/lista` | Listar chamados |
| ChamadosSuporte | `/ChamadosSuporte` (com `Chave` no body) | Detalhe de um chamado |
| Categorias | `/Categorias/lista` | Listar categorias |
| Operadores | `/Operadores/lista` | Listar operadores |
| Clientes | `/Clientes/lista` | Listar clientes |
| GrupoEmpresas | `/GrupoEmpresas/lista` | Grupos |
| Status | `/Status/lista` | Status configurados |

> Os endpoints já usados no workflow `Desk_MS_Pegar_Dados_Para_DataLake` do n8n podem ser referência: `n8n.questor.com.br/workflow/0WeyIO5BkLThSC7m` (chamador) e `n8n.questor.com.br/workflow/jiAHz6rY13e91RbU` (executor).

## Formato do body para `/lista`

```json
{
  "Tatual": 0,
  "Quantidade": 200,
  "Ordenacao": [
    {"Campo": "DataCriacao", "Ordem": "DESC"}
  ]
}
```

> A API retorna até **3000 registros** por chamada. Usar paginação via `Tatual` (total atual) quando for preciso buscar mais.

## Response de `/ChamadosSuporte/lista`

```json
{
  "root": [
    {
      "Chave": 1623378,
      "CodChamado": "0426-010844",
      "DataCriacao": "2026-04-17",
      "HoraCriacao": "09:34:32",
      "DataFinalizacao": "0000-00-00",   // "0000-00-00" = ainda ativo
      "HoraFinalizacao": "",
      "DataAlteracao": "2026-04-17",
      "HoraAlteracao": "09:34:32",
      "NomeStatus": "Aguardando Atendimento",
      "Assunto": "...",
      "Descricao": "...",
      "ChaveUsuario": 72266,
      "NomeUsuario": "Alessandra Bernadete Tobias de Aguiar",  // cliente
      "SobrenomeUsuario": "",
      "QtAcoes": 0,   // número de interações
      "TotalAnexos": 0,
      "TempoRestantePrimeiroAtendimento": "00:00:00",
      "TempoRestanteSegundoAtendimento": "00:00:00",
      "Sla1Expirado": "N",
      "Sla2Expirado": "N",
      "SequenciaGrupo": "000003",
      "NomeGrupo": "Suporte - Web"   // fila de atendimento
    }
  ],
  "total": 3000
}
```

### Pontos importantes
- `DataFinalizacao === "0000-00-00"` → chamado ainda ativo
- Data e hora vêm em campos separados (`DataCriacao` + `HoraCriacao`)
- Cliente é `NomeUsuario` + `SobrenomeUsuario`
- Atendente/operador está em outro campo (investigar — possivelmente `NomeOperador`, `ChaveOperador` ou em detalhe do chamado)
- SLA tem flag expirado: `Sla1Expirado`, `Sla2Expirado`

## Tools a implementar

### 1. `listar_chamados_ativos_hoje`
Retorna chamados abertos hoje que ainda estão ativos.

**Params:**
- `grupo?: str` — filtrar por fila (ex: "Suporte - Web")
- `sla_expirado?: bool` — só os com SLA expirado
- `ordem?: str` — default: `tempo_aberto_desc`
- `limite?: int` — default: 50

**Retorna:** lista enriquecida com:
- Todos os campos originais
- `horas_aberto` (calculado: agora - DataCriacao+HoraCriacao, BRT)
- `horas_sem_resposta` (agora - DataAlteracao+HoraAlteracao)
- `cliente_nome_completo`
- `urgencia` (alto/medio/baixo baseado em SLA e tempo)

### 2. `obter_chamado`
Retorna detalhe completo de um chamado específico.

**Params:**
- `chave: int` — obrigatório
- `incluir_historico?: bool` — default: `true`
- `incluir_anexos?: bool` — default: `false`

### 3. `listar_historico_chamado`
Retorna todas as interações/ações de um chamado.

**Params:**
- `chave: int`

### 4. `buscar_chamados_similares`
Busca chamados já resolvidos com assunto parecido.

**Params:**
- `texto_busca: str`
- `apenas_resolvidos?: bool` — default: `true`
- `limite?: int` — default: 10
- `periodo_dias?: int` — default: 180

### 5. `comentar_chamado`
Posta um comentário no chamado.

**Params:**
- `chave: int`
- `texto: str`
- `publico?: bool` — default: `false` (interno por padrão)

### 6. `atualizar_status_chamado`
Muda status do chamado.

**Params:**
- `chave: int`
- `novo_status: str`
- `comentario?: str`

### 7. `listar_grupos`
Retorna grupos/filas de atendimento.

### 8. `listar_operadores`
Retorna operadores ativos.

### 9. `dashboard_n3`
Retorna agregados úteis para o agent decidir onde focar:
- Total de ativos hoje
- Ativos por grupo
- SLA 1 expirando nas próximas 2h
- Chamados sem atribuição
- Top 10 mais tempo sem resposta

## Estrutura de pastas sugerida

```
desk-questor-mcp/
├── .env.example
├── .gitignore
├── README.md
├── pyproject.toml
├── requirements.txt
├── src/
│   ├── __init__.py
│   ├── server.py           # FastMCP entrypoint, registra as tools
│   ├── desk_client.py      # HTTP client com cache de token
│   ├── models.py           # Pydantic models (Chamado, Historico, etc)
│   ├── enrichment.py       # cálculo de horas, urgência, formatação
│   └── tools/
│       ├── __init__.py
│       ├── chamados.py     # listar, obter, buscar_similares
│       ├── interacoes.py   # comentar, atualizar_status
│       ├── dashboard.py    # dashboard_n3
│       └── catalogos.py    # grupos, operadores
├── tests/
│   ├── test_desk_client.py
│   └── test_enrichment.py
└── scripts/
    └── start.ps1
```

## Regras operacionais

1. **Cache de token** — salvar em memória com timestamp. Renovar 30s antes de expirar.
2. **Rate limiting** — respeitar `batchInterval: 200ms` entre chamadas (padrão do workflow existente).
3. **Timeout** — 600s nas chamadas `/lista` (grandes volumes), 30s em chamadas pontuais.
4. **Retry** — 3 tentativas com backoff exponencial em erros 5xx e timeouts.
5. **Logs** — toda chamada deve ter log estruturado com: tool, params, tempo de resposta, status.
6. **Erros** — nunca expor o token em mensagens de erro.
7. **BRT** — todos os cálculos de tempo devem considerar timezone `America/Sao_Paulo`.

## Exemplo de uso (depois de pronto)

Cenário: agent Claude rodando em loop a cada 15 min

```python
# Pseudo-código do agent
chamados = mcp.desk.listar_chamados_ativos_hoje(
    sla_expirado=False,
    limite=20
)

for c in chamados:
    # Contexto adicional via outros MCPs
    tarefas_redmine = mcp.redmine.redmine_search(query=c.assunto[:50])
    dados_cliente = mcp.metabase.execute(
        database_id=3,
        query=f"SELECT versao, modulo_mais_usado FROM es_versao WHERE cliente_id = {c.chave_usuario}"
    )
    
    similares = mcp.desk.buscar_chamados_similares(
        texto_busca=c.assunto,
        apenas_resolvidos=True,
        limite=5
    )
    
    # Claude analisa com TODO o contexto
    sugestao = analise_com_contexto_completo(c, tarefas_redmine, dados_cliente, similares)
    
    # Se confiança alta, comenta interno no chamado
    if sugestao.confianca > 0.7:
        mcp.desk.comentar_chamado(
            chave=c.chave,
            texto=sugestao.texto,
            publico=False
        )
    else:
        # Senão, só avisa no Google Chat N3
        mcp.google_chat.gchat_send_space(
            space_id="spaces/{N3}",
            mensagem=formatar(c, sugestao)
        )
```

## Observações importantes para a construção

1. **Seguir o padrão dos MCPs existentes** da Questor (`redmine-questor`, `quiara`) — mesma estrutura de pastas, mesmo estilo de código, mesmo tratamento de logs.

2. **NÃO usar `QuotedString` — usar parametrização adequada** em qualquer query SQL (caso o MCP exponha alguma tool que precise de SQL).

3. **Documentar os schemas** de todas as tools com descrições em português — é assim que o agent decide quando usar cada uma.

4. **Testar com 1 chamado real** antes de expor a tool. Validar especialmente:
   - Tratamento de `DataFinalizacao === "0000-00-00"`
   - Paginação quando > 200 resultados
   - Renovação de token ao expirar

5. **README.md** deve incluir:
   - Como instalar (pip install, .env)
   - Como registrar no `claude_desktop_config.json`
   - Exemplos de prompts que funcionam bem
   - Tabela completa de campos retornados

## Referências

- Workflow n8n que funciona (chamador): `https://n8n.questor.com.br/workflow/0WeyIO5BkLThSC7m`
- Workflow n8n que funciona (executor): `https://n8n.questor.com.br/workflow/jiAHz6rY13e91RbU`
- Credenciais no n8n:
  - `8dQInvpOE6nTU2zf` — "Header Auth account desk full direito" (usada para `/Login/autenticar`)
  - `16` — "Header Auth account Desk MS BackReqToken" (usada para `api.desk.ms/*`)
- Tabelas datalake como fallback:
  - `desk_chamadossuporte_dados`
  - `desk_chamadohistoricos_dados`
  - `desk_clientes_dados`
  - `desk_operadores_dados`
  - Schema completo em `/mnt/skills/organization/datalake-metabase/SKILL.md`

## Fase 2 (depois do MVP)

- Cache L2 em SQLite local para chamados já consultados
- Webhook do Desk (se houver) → trigger imediato em vez de polling
- Tool `marcar_sugestao_util` para feedback do operador (ajuda a treinar prompts)
- Integração com Q-Help quando a API estiver disponível (maio/2026)
