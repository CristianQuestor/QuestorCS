# Investigação — Endpoint de Histórico (API Desk Manager) — v4

**Data:** 20/04/2026 (terceira iteração da tarde, após análise do ColetorDados)
**Versão anterior:** `investigacao_endpoint_historico_desk_v3.md`
**Responsável:** Fabio Puhl
**MCP envolvido:** `desk-questor` v0.4.1

---

## 0. Evolução v1 → v2 → v3 → v4

| Item | v2 | v3 | **v4 (agora)** |
|---|---|---|---|
| Endpoint descoberto | `ChamadoHistoricos/lista` via form+BackReqToken | Confirmado, mas auth inaceitável | Confirmado + fontes cruzadas com **workflow n8n ATIVO `9zwhoKQ6kEsBw0xb`** e **código C# ColetorDados** |
| Auth do histórico | BackReqToken estático | Tentadas 2 estratégias, ambas falharam | **Trocado login default para `api.desk.ms/Login/autenticar` + form body** (padrão do workflow ativo) |
| Bug 4.1 (CodChamado em `obter_chamado`) | não diagnosticado | identificado | **corrigido** |
| Bug 4.2 (enrich operador em `obter_chamado`) | não diagnosticado | identificado | **corrigido** (causa raiz: payload vinha em `TChamado` + `CodOperador=[{id,text}]`) |

---

## 1. Fontes de verdade cruzadas

### 1.1 Workflow n8n ATIVO `9zwhoKQ6kEsBw0xb` ("Monitoramento Clientes na Fila Deskmanager")

- **Login**: `POST https://api.desk.ms/Login/autenticar`
- Body: **form-urlencoded** `PublicKey=b76b021790...`
- Header: `Authorization: 682fc7016...` (cred #52 "Desk")
- Endpoints subsequentes usam cred **#67 "Desk-Token-Gerado_Matheus"** (token estático pré-gerado, **NÃO** o token recém-obtido).

### 1.2 Código C# `ColetorDados` (alimenta o datalake `coletor_chamados`)

Arquivo `src/ColetorDados.Infra.IntegrationApi/IntegrationData.cs`:

| Operação | Método | Body |
|---|---|---|
| `ObterToken` | POST (JSON) | `{"PublicKey": "..."}` |
| `ObterListaChamados` | POST (JSON) | `{Tatual, Colunas:{Chave:"on",...,TotalAcoes:"on",...}, Ordem:[{Coluna:"Chave",Direcao:"true"}], Filtro:{Chave:<int>}}` |
| `ObterDadosGrupoEmpresas` | POST (JSON) | `{Tatual, Pesquisa, Ativo, Ordem}` |
| `ObterDadosRelatorio` | POST (JSON) | `{Chave:<int>, APartirDe:"<str>", Total:"<str>"}` |
| `InserirInteracaoHelpDesk` | **PUT** (JSON) | `{Chave:"<str>", TChamado:{CodFormaAtendimento, CodStatus, CodAprovador:[str], Descricao, CodOperador, CodGrupo, EnviarEmail:"S", DataInteracao, HoraInicial, HoraFinal, PrimeiroAtendimento, SegundoAtendimento}, TCampoExtra:{<id>:"<valor>"}}` |

**Coisas que o C# expõe e o MCP ainda não usa:**

- O schema `{Colunas, Ordem, Filtro (singular)}` em `/ChamadosSuporte/lista` é oficial. O MCP usa hoje `{Filtros:[{Campo,Valor,Operador}], Ordenacao}` — o servidor aceita ambos, mas o formato do C# é mais expressivo (p. ex. `Colunas` permite whitelist de campos retornados).
- Interação de chamado é **PUT**, não POST. O MCP fazia 3 tentativas POST — provavelmente só uma acertava, ou todas falhavam silenciosamente.
- Relatórios têm endpoint `/Relatorios/imprimir` com body `{Chave, APartirDe, Total}` — ainda não exposto no MCP.

### 1.3 Código C# NÃO coleta histórico

Busca por `Historico|ChamadoHistoricos|Acoes` em todo `ColetorDados/src`: **não há código** que chame `/ChamadoHistoricos/lista`. A coleta de histórico no datalake (`desk_chamadohistoricos_dados`) vinha exclusivamente do workflow n8n inativo — e parou em **2024-12-31**.

Isso reforça a hipótese central: **o endpoint `/ChamadoHistoricos/lista` pode ter sido descontinuado ou ter escopo diferente**. Nenhuma integração ativa hoje consome ele.

---

## 2. Ajustes entregues (v0.4.1 do MCP)

### 2.1 Login migrado para api.desk.ms + form

Seguindo o workflow ATIVO `9zwhoKQ6kEsBw0xb`. Default de `DESK_LOGIN_URL` agora é `https://api.desk.ms/Login/autenticar` com body form. Pode ser sobrescrito via env (`DESK_LOGIN_URL` + `DESK_LOGIN_BODY_FORMAT=form|json`).

Motivação: o caminho antigo (`questor.desk.ms` + JSON) gera token que retorna HTTP 500 em `/ChamadoHistoricos/lista`. O novo caminho gera token compatível com os mesmos endpoints onde o antigo funciona — sem regressão — e potencialmente destrava o histórico se o endpoint ainda responder.

### 2.2 Bug 4.1 — `obter_chamado` + histórico (CORRIGIDO)

**Sintoma:** `obter_chamado(chave=X, incluir_historico=true)` retornava `historico.erro = "Não consegui resolver CodChamado para chave=X"`.

**Causa:** a API devolve `{"TChamado": {...}}` em chamadas de detalhe. O código que extraía `CodChamado` lia do topo do dict, não de dentro de `TChamado`.

**Fix:** nova função `_desempacotar_detalhe()` em `src/tools/chamados.py` — detecta o envelope `TChamado` e achata para que `CodChamado`, `NomeOperador`, `NomeStatus`, etc. fiquem acessíveis.

### 2.3 Bug 4.2 — enriquecimento de operador em `obter_chamado` (CORRIGIDO)

**Sintoma:** `obter_chamado` retornava `operador=null`, `operador_online=null`, etc., apesar de `raw.TChamado.CodOperador=[{id:"605",text:"Analice Franceschi"}]` estar presente.

**Causa:** mesmo problema + detalhe singular usa formato `CodOperador=[{id,text}]` (array com objetos), enquanto listagem usa `NomeOperador` direto. O enriquecimento não sabia extrair do formato novo.

**Fix:** `_desempacotar_detalhe()` também converte `CodOperador=[{id,text}]` para `ChaveOperador=<int>` + `NomeOperador=<str>`. Mesmo para `CodUsuario` e `CodStatusAtual`.

### 2.4 Testes

Novo arquivo `tests/test_obter_chamado_unwrap.py` com 3 casos:
1. Unwrap de `TChamado` acha todos os campos (CodChamado, NomeOperador, ChaveOperador, NomeStatus, NomeUsuario).
2. `obter_chamado` enriquece operador online/grupo correctamente.
3. `obter_chamado(incluir_historico=true)` resolve CodChamado e envia body correto pra `/ChamadoHistoricos/lista`.

**Total:** 47/47 passando.

---

## 3. O que ainda está bloqueado

| Item | Status | Bloqueio |
|---|---|---|
| `listar_historico_chamado` retornar dados reais | pendente smoke test | Depende de reiniciar Claude Desktop com v0.4.1 e verificar se o novo token (api.desk.ms+form) é aceito pelo endpoint |
| Endpoint `/ChamadoHistoricos/lista` estar ativo | **incerto** | Nenhuma integração atual consome. Última coleta bem-sucedida: 2024-12-31. Pode ter sido descontinuado. |

**Se v0.4.1 continuar dando HTTP 500**: a conclusão deixa de ser "nosso wrapper está errado" e passa a ser "o endpoint está quebrado na API do fornecedor ou mudou de nome". Nesse caso, Passo 1 da v3 (F12 no Desk Web) vira obrigatório.

---

## 4. Oportunidades identificadas (tech-debt, independentes do bloqueio principal)

Todas surgiram da leitura do `ColetorDados`:

1. **Schema canônico de `/ChamadosSuporte/lista`**: migrar de `Filtros[array]` + `Ordenacao` para `{Colunas, Ordem, Filtro}`. Permite whitelist de campos (payload menor) e filtros mais expressivos (ex.: `Filtro:{DataCriacao: [de,"between",ate]}`).
2. **`comentar_chamado` / `atualizar_status_chamado` deveriam usar PUT**, não POST. O código atual tenta 3 combinações POST — prefixo, sufixo e sem — é possível que nenhuma funcione em produção. Corrigir para PUT em `/ChamadosSuporte` com body `{Chave, TChamado:{...}}`.
3. **Nova tool `executar_relatorio(chave, a_partir_de, total)`**: endpoint `/Relatorios/imprimir` está pronto e documentado no C#. Útil para exportar agregados do Desk sem consultar o datalake.
4. **Não usar `BackReqToken` como fallback** — o "token" na cred #16 é na verdade um token de login estático e estragado. Remover essa via reduz complexidade e mensagens de erro confusas.

---

## 5. Próximo movimento recomendado

1. Reiniciar Claude Desktop com MCP v0.4.1.
2. Rodar smoke test:
   - `obter_chamado(chave=1624098)` — deve retornar `operador="Analice Franceschi", operador_online=...` (bug 4.2 validado).
   - `obter_chamado(chave=1624098, incluir_historico=true)` — deve retornar `historico.total = 3` se o endpoint responder; se der 500/token, concluir que o endpoint está quebrado no fornecedor.
   - `listar_historico_chamado(codigo="0426-011564")` — idem.
3. Se (2) falhar com 500 no histórico: aplicar Passo 1 da v3 (F12 no Desk Web em um chamado real) para capturar headers/cookies do frontend.
4. Em paralelo, tratar tech-debt do item 4 como backlog P2 — nada bloqueia uso atual.
