"""Testes da issue_mcp_desk_questor_listar_chamados_filtro_data.md.

Cobre os 5 casos de uso da seção 3, validações da seção 2.4 e campos novos
(`data_finalizacao`, `horas_ate_finalizacao_uteis`, `finalizado_no_mesmo_dia`).
"""

from __future__ import annotations

from datetime import datetime

import pytest

from src import enrichment
from src.enrichment import BRT
from src.tools import chamados as tool_chamados


class FakeClient:
    """Mock que devolve lista de registros e conta chamadas."""

    def __init__(self, registros: list[dict], operadores: list[dict] | None = None):
        self.registros = registros
        self.operadores = operadores or []
        self.chamadas_listar = 0

    async def listar(self, entidade, body, *, auth_mode="login"):
        if entidade == "Operadores":
            return {"root": list(self.operadores)}
        if entidade == "ChamadosSuporte":
            self.chamadas_listar += 1
            tatual = body.get("Tatual", 0)
            qtd = body.get("Quantidade", 500)
            lote = self.registros[tatual : tatual + qtd]
            return {"root": lote, "total": len(self.registros)}
        raise RuntimeError(f"entidade {entidade} não mockada")


def _chamado(
    chave: int,
    data_criacao: str,
    *,
    operador: str | None = None,
    chave_operador: int | None = None,
    grupo: str = "Suporte - Web",
    status: str = "Em Andamento",
    finalizado: bool = False,
    data_finalizacao: str | None = None,
    hora_finalizacao: str | None = None,
) -> dict:
    return {
        "Chave": chave,
        "CodChamado": f"0426-{chave:06d}",
        "Assunto": f"Chamado {chave}",
        "DataCriacao": data_criacao,
        "HoraCriacao": "09:00:00",
        "DataAlteracao": data_criacao,
        "HoraAlteracao": "10:00:00",
        "DataFinalizacao": (data_finalizacao or "2026-04-20") if finalizado else "0000-00-00",
        "HoraFinalizacao": (hora_finalizacao or "17:00:00") if finalizado else "",
        "NomeStatus": status,
        "NomeGrupo": grupo,
        "NomeOperador": operador,
        "ChaveOperador": chave_operador,
        "NomeUsuario": "Cliente",
        "SobrenomeUsuario": "Teste",
        "Sla1Expirado": "N",
        "Sla2Expirado": "N",
        "TempoRestantePrimeiroAtendimento": "04:00:00",
        "TempoRestanteSegundoAtendimento": "08:00:00",
        "QtAcoes": 0,
    }


@pytest.fixture(autouse=True)
def travar_agora(monkeypatch):
    monkeypatch.setattr(
        enrichment, "_agora_brt", lambda: datetime(2026, 4, 21, 15, 0, tzinfo=BRT)
    )


# ---------------------------------------------------------------------------
# Caso 1 — "O que ficou sem resposta de ontem?"
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_caso1_sem_resposta_de_ontem():
    registros = [
        _chamado(1, "2026-04-20", operador=None),  # sem resposta, ativo
        _chamado(2, "2026-04-20", operador="Alguém"),  # atribuído
        _chamado(3, "2026-04-20", operador=None, finalizado=True),  # já fechado
        _chamado(4, "2026-04-19", operador=None),  # dia errado
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(
        client,
        data_criacao_de="2026-04-20",
        data_criacao_ate="2026-04-20",
        apenas_ativos=True,
        sem_operador=True,
        limite=500,
    )
    assert [c.chave for c in chamados] == [1]


# ---------------------------------------------------------------------------
# Caso 2 — "Quantos de ontem foram resolvidos?"
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_caso2_resolvidos_ontem():
    registros = [
        _chamado(1, "2026-04-20", finalizado=True, status="Resolvido",
                 data_finalizacao="2026-04-20", hora_finalizacao="14:00:00"),
        _chamado(2, "2026-04-20", status="Em Andamento"),  # não resolvido
        _chamado(3, "2026-04-20", finalizado=True, status="Finalizado",
                 data_finalizacao="2026-04-20", hora_finalizacao="16:30:00"),
        _chamado(4, "2026-04-19", finalizado=True, status="Resolvido",
                 data_finalizacao="2026-04-19", hora_finalizacao="11:00:00"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(
        client,
        data_criacao_de="2026-04-20",
        data_criacao_ate="2026-04-20",
        apenas_ativos=False,
        status=["Resolvido", "Finalizado"],
        limite=1000,
    )
    chaves = sorted(c.chave for c in chamados)
    assert chaves == [1, 3]
    # Campos novos populados nos finalizados
    for c in chamados:
        assert c.data_finalizacao == "2026-04-20"
        assert c.hora_finalizacao is not None
        assert c.finalizado_no_mesmo_dia is True
        assert c.horas_ate_finalizacao_uteis is not None


# ---------------------------------------------------------------------------
# Caso 3 — "Passivo da fila Folha nos últimos 7 dias"
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_caso3_janela_7_dias_fila_folha():
    registros = [
        _chamado(1, "2026-04-14", grupo="Suporte - Folha de Pagamento"),
        _chamado(2, "2026-04-17", grupo="Suporte - Folha de Pagamento"),
        _chamado(3, "2026-04-20", grupo="Suporte - Folha de Pagamento"),
        _chamado(4, "2026-04-20", grupo="Suporte - Web"),  # fila errada
        _chamado(5, "2026-04-13", grupo="Suporte - Folha de Pagamento"),  # fora janela
        _chamado(6, "2026-04-21", grupo="Suporte - Folha de Pagamento"),  # futuro da janela
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(
        client,
        data_criacao_de="2026-04-14",
        data_criacao_ate="2026-04-20",
        grupo="Suporte - Folha de Pagamento",
        apenas_ativos=True,
        limite=2000,
    )
    assert sorted(c.chave for c in chamados) == [1, 2, 3]


# ---------------------------------------------------------------------------
# Caso 4 — "O que a Jessica finalizou ontem?"
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_caso4_finalizado_por_operador_parcial():
    registros = [
        _chamado(1, "2026-04-15", operador="Jessica Lopes", finalizado=True,
                 data_finalizacao="2026-04-20", hora_finalizacao="11:00:00",
                 status="Resolvido"),
        _chamado(2, "2026-04-19", operador="Jessica Almeida", finalizado=True,
                 data_finalizacao="2026-04-20", hora_finalizacao="14:30:00",
                 status="Resolvido"),
        _chamado(3, "2026-04-18", operador="Ana Paula", finalizado=True,
                 data_finalizacao="2026-04-20", hora_finalizacao="09:00:00",
                 status="Resolvido"),
        _chamado(4, "2026-04-17", operador="Jessica Lopes", finalizado=True,
                 data_finalizacao="2026-04-19", hora_finalizacao="15:00:00",
                 status="Resolvido"),  # dia errado
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(
        client,
        data_finalizacao_de="2026-04-20",
        data_finalizacao_ate="2026-04-20",
        operador="jessica",  # match parcial case-insensitive
        apenas_ativos=False,
        limite=500,
    )
    assert sorted(c.chave for c in chamados) == [1, 2]


# ---------------------------------------------------------------------------
# Caso 5 — Retrocompatibilidade: listar_chamados_ativos_hoje
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_caso5_alias_hoje_retrocompativel():
    registros = [
        _chamado(1, "2026-04-21"),
        _chamado(2, "2026-04-20"),  # dia anterior
    ]
    client = FakeClient(registros)
    # Fixture fixa agora=2026-04-21
    chamados = await tool_chamados.listar_chamados_ativos_hoje(client, limite=50)
    assert [c.chave for c in chamados] == [1]


# ---------------------------------------------------------------------------
# Validações da seção 2.4
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validacao_janela_90d_criacao():
    client = FakeClient([])
    with pytest.raises(ValueError, match="excede o máximo de 90 dias"):
        await tool_chamados.listar_chamados(
            client,
            data_criacao_de="2026-01-01",
            data_criacao_ate="2026-04-21",
        )


@pytest.mark.asyncio
async def test_validacao_janela_90d_finalizacao():
    client = FakeClient([])
    with pytest.raises(ValueError, match="excede o máximo de 90 dias"):
        await tool_chamados.listar_chamados(
            client,
            data_finalizacao_de="2026-01-01",
            data_finalizacao_ate="2026-04-21",
            apenas_ativos=False,
        )


@pytest.mark.asyncio
async def test_janela_exatamente_90d_aceita():
    """Boundary: 90 dias exatos devem passar."""
    client = FakeClient([])
    # 2026-04-21 - 2026-01-21 = 90 dias exatos
    await tool_chamados.listar_chamados(
        client,
        data_criacao_de="2026-01-21",
        data_criacao_ate="2026-04-21",
    )


@pytest.mark.asyncio
async def test_validacao_data_finalizacao_invertida():
    client = FakeClient([])
    with pytest.raises(ValueError, match="Intervalo data_finalizacao inválido"):
        await tool_chamados.listar_chamados(
            client,
            data_finalizacao_de="2026-04-20",
            data_finalizacao_ate="2026-04-10",
            apenas_ativos=False,
        )


# ---------------------------------------------------------------------------
# Campos novos
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_finalizado_no_mesmo_dia_true():
    client = FakeClient([
        _chamado(1, "2026-04-20", finalizado=True,
                 data_finalizacao="2026-04-20", hora_finalizacao="14:00:00"),
    ])
    chamados = await tool_chamados.listar_chamados(
        client, apenas_ativos=False, limite=10
    )
    assert chamados[0].finalizado_no_mesmo_dia is True
    assert chamados[0].data_finalizacao == "2026-04-20"
    assert chamados[0].horas_ate_finalizacao_uteis is not None


@pytest.mark.asyncio
async def test_finalizado_no_mesmo_dia_false():
    client = FakeClient([
        _chamado(1, "2026-04-18", finalizado=True,
                 data_finalizacao="2026-04-20", hora_finalizacao="14:00:00"),
    ])
    chamados = await tool_chamados.listar_chamados(
        client, apenas_ativos=False, limite=10
    )
    assert chamados[0].finalizado_no_mesmo_dia is False


@pytest.mark.asyncio
async def test_ativo_nao_tem_data_finalizacao():
    client = FakeClient([_chamado(1, "2026-04-20")])
    chamados = await tool_chamados.listar_chamados(client, limite=10)
    assert chamados[0].ativo is True
    assert chamados[0].data_finalizacao is None
    assert chamados[0].finalizado_no_mesmo_dia is None
    assert chamados[0].horas_ate_finalizacao_uteis is None


# ---------------------------------------------------------------------------
# Filtros adicionais
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_operador_match_parcial():
    registros = [
        _chamado(1, "2026-04-20", operador="Jessica Lopes"),
        _chamado(2, "2026-04-20", operador="Jessica Almeida"),
        _chamado(3, "2026-04-20", operador="Ana Paula"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(
        client, operador="jessica", limite=50
    )
    assert sorted(c.chave for c in chamados) == [1, 2]


@pytest.mark.asyncio
async def test_operador_chave_match_exato():
    registros = [
        _chamado(1, "2026-04-20", operador="A", chave_operador=100),
        _chamado(2, "2026-04-20", operador="B", chave_operador=200),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(
        client, operador_chave=200, limite=50
    )
    assert [c.chave for c in chamados] == [2]


# ---------------------------------------------------------------------------
# Paginação
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_paginacao_interna_ate_2000():
    # 1200 registros forçam 3 páginas (500+500+200)
    registros = [_chamado(i, "2026-04-20") for i in range(1, 1201)]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(client, limite=2000)
    assert len(chamados) == 1200
    assert client.chamadas_listar == 3


@pytest.mark.asyncio
async def test_paginacao_respeita_limite():
    registros = [_chamado(i, "2026-04-20") for i in range(1, 1201)]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(client, limite=700)
    assert len(chamados) == 700
    # Buscou 2 páginas (500+500=1000) — limite aplicado depois
    assert client.chamadas_listar == 2


@pytest.mark.asyncio
async def test_teto_limite_2000():
    """limite > 2000 é clampado para 2000."""
    registros = [_chamado(i, "2026-04-20") for i in range(1, 3001)]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados(client, limite=5000)
    assert len(chamados) == 2000
