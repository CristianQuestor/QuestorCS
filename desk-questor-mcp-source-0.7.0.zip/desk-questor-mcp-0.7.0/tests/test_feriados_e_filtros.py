"""Testes da Feature 2 (feriados) e complementos da Feature 1 (validação/sem_operador).

Cobrem critérios de aceitação da issue_mcp_desk_questor_filtro_data_feriados.md.
"""

from __future__ import annotations

import os
from datetime import datetime

import pytest

from src import enrichment
from src.enrichment import BRT, _eh_dia_util, _horas_uteis_entre
from src.tools import chamados as tool_chamados


# ---------------------------------------------------------------------------
# Feature 2 — horas úteis considerando feriados
# ---------------------------------------------------------------------------


def _limpar_cache_feriados():
    enrichment._feriados_br.cache_clear()


def test_eh_dia_util_sabado_domingo():
    assert _eh_dia_util(datetime(2026, 4, 18, 10, 0, tzinfo=BRT)) is False  # sábado
    assert _eh_dia_util(datetime(2026, 4, 19, 10, 0, tzinfo=BRT)) is False  # domingo


def test_eh_dia_util_tiradentes_e_natal():
    _limpar_cache_feriados()
    assert _eh_dia_util(datetime(2026, 4, 21, 10, 0, tzinfo=BRT)) is False  # Tiradentes
    assert _eh_dia_util(datetime(2026, 12, 25, 10, 0, tzinfo=BRT)) is False  # Natal


def test_eh_dia_util_segunda_comum():
    assert _eh_dia_util(datetime(2026, 4, 20, 10, 0, tzinfo=BRT)) is True  # segunda


def test_horas_uteis_feriado_retorna_zero():
    """Chamado aberto 08:00 e consultado 19:00 no mesmo feriado → 0 horas úteis."""
    inicio = datetime(2026, 4, 21, 8, 0, tzinfo=BRT)
    fim = datetime(2026, 4, 21, 19, 0, tzinfo=BRT)
    assert _horas_uteis_entre(inicio, fim) == 0.0


def test_horas_uteis_sexta_17h_segunda_09h_atravessando_fim_de_semana():
    """Sexta 17h → Segunda 09h = 7h sexta (17-24) + 9h segunda = 16h úteis."""
    sexta = datetime(2026, 4, 17, 17, 0, tzinfo=BRT)
    segunda = datetime(2026, 4, 20, 9, 0, tzinfo=BRT)
    assert _horas_uteis_entre(sexta, segunda) == 16.0


def test_horas_uteis_atravessando_natal():
    """23/12/2026 (qua) 09h → 27/12/2026 (dom) 09h:
    - 23 (qua): 09h→24h = 15h
    - 24 (qui) ~~ feriado municipal (não nacional); útil → 24h
    - 25 (sex): Natal → 0
    - 26 (sáb): 0
    - 27 (dom) 00→09h: 0
    Total: 15 + 24 = 39h
    """
    _limpar_cache_feriados()
    inicio = datetime(2026, 12, 23, 9, 0, tzinfo=BRT)
    fim = datetime(2026, 12, 27, 9, 0, tzinfo=BRT)
    assert _horas_uteis_entre(inicio, fim) == 39.0


def test_feriados_extras_via_env(monkeypatch):
    """DESK_QUESTOR_FERIADOS_EXTRAS adiciona datas ao conjunto."""
    monkeypatch.setenv("DESK_QUESTOR_FERIADOS_EXTRAS", "2026-04-20")
    _limpar_cache_feriados()
    try:
        # 2026-04-20 é segunda, normalmente dia útil
        assert _eh_dia_util(datetime(2026, 4, 20, 10, 0, tzinfo=BRT)) is False
    finally:
        _limpar_cache_feriados()


def test_feriados_extras_ignora_entradas_invalidas(monkeypatch):
    monkeypatch.setenv("DESK_QUESTOR_FERIADOS_EXTRAS", "abc, 2026-04-20 , xxx")
    _limpar_cache_feriados()
    try:
        assert _eh_dia_util(datetime(2026, 4, 20, 10, 0, tzinfo=BRT)) is False
    finally:
        _limpar_cache_feriados()


# ---------------------------------------------------------------------------
# Feature 1 — validações + sem_operador
# ---------------------------------------------------------------------------


class FakeClient:
    def __init__(self, registros: list[dict]):
        self.registros = registros

    async def listar(self, entidade, body):
        if entidade == "Operadores":
            return {"root": []}
        if entidade == "ChamadosSuporte":
            return {"root": list(self.registros), "total": len(self.registros)}
        raise RuntimeError(f"entidade {entidade} não mockada")


def _reg(chave: int, operador: str | None = None) -> dict:
    return {
        "Chave": chave,
        "CodChamado": f"0426-{chave:06d}",
        "Assunto": f"Chamado {chave}",
        "DataCriacao": "2026-04-20",
        "HoraCriacao": "09:00:00",
        "DataAlteracao": "2026-04-20",
        "HoraAlteracao": "10:00:00",
        "DataFinalizacao": "0000-00-00",
        "HoraFinalizacao": "",
        "NomeStatus": "Em Andamento",
        "NomeGrupo": "Suporte - Web",
        "NomeOperador": operador,
        "NomeUsuario": "Cliente",
        "SobrenomeUsuario": "Teste",
        "Sla1Expirado": "N",
        "Sla2Expirado": "N",
        "TempoRestantePrimeiroAtendimento": "04:00:00",
        "TempoRestanteSegundoAtendimento": "08:00:00",
        "QtAcoes": 0,
    }


@pytest.fixture(autouse=True)
def travar_agora(monkeypatch):
    monkeypatch.setattr(
        enrichment, "_agora_brt", lambda: datetime(2026, 4, 20, 15, 0, tzinfo=BRT)
    )


@pytest.mark.asyncio
async def test_valida_formato_data():
    client = FakeClient([])
    with pytest.raises(ValueError, match="YYYY-MM-DD"):
        await tool_chamados.listar_chamados_ativos(client, data_criacao_de="20/04/2026")


@pytest.mark.asyncio
async def test_valida_data_inexistente():
    client = FakeClient([])
    with pytest.raises(ValueError):
        await tool_chamados.listar_chamados_ativos(client, data_criacao_de="2026-13-01")


@pytest.mark.asyncio
async def test_valida_intervalo_invertido():
    client = FakeClient([])
    with pytest.raises(ValueError, match="Intervalo data_criacao inválido"):
        await tool_chamados.listar_chamados_ativos(
            client,
            data_criacao_de="2026-04-20",
            data_criacao_ate="2026-04-10",
        )


@pytest.mark.asyncio
async def test_sem_operador_true_retorna_apenas_nao_atribuidos():
    client = FakeClient([_reg(1, operador=None), _reg(2, operador="Fulano")])
    chamados = await tool_chamados.listar_chamados_ativos(
        client, sem_operador=True, limite=100
    )
    assert [c.chave for c in chamados] == [1]


@pytest.mark.asyncio
async def test_sem_operador_false_retorna_apenas_atribuidos():
    client = FakeClient([_reg(1, operador=None), _reg(2, operador="Fulano")])
    chamados = await tool_chamados.listar_chamados_ativos(
        client, sem_operador=False, limite=100
    )
    assert [c.chave for c in chamados] == [2]


@pytest.mark.asyncio
async def test_sem_operador_none_nao_filtra():
    client = FakeClient([_reg(1, operador=None), _reg(2, operador="Fulano")])
    chamados = await tool_chamados.listar_chamados_ativos(client, limite=100)
    assert sorted(c.chave for c in chamados) == [1, 2]


@pytest.mark.asyncio
async def test_listar_ativos_hoje_ainda_funciona():
    """Alias retrocompatível — Feature 1 não pode quebrar a tool antiga."""
    client = FakeClient([
        _reg(1),  # hoje (travado em 2026-04-20 pelo fixture)
        {**_reg(2), "DataCriacao": "2026-04-15"},
    ])
    chamados = await tool_chamados.listar_chamados_ativos_hoje(client, limite=100)
    assert [c.chave for c in chamados] == [1]
