"""Testes do DeskClient com respx mockando o transporte HTTP."""

from __future__ import annotations

import httpx
import pytest
import respx

from src.desk_client import DeskAPIError, DeskAuthError, DeskClient, DeskConfig


def _config() -> DeskConfig:
    return DeskConfig(
        auth_header="auth-header",
        public_key="pub-key",
        back_req_token="back-token",
        login_url="https://login.test/Login/autenticar",
        login_body_format="form",
        api_url="https://api.test",
        lista_timeout=30,
        call_timeout=10,
        rate_limit_ms=0,
        token_refresh_margin=30,
        token_ttl=1800,
    )


@pytest.mark.asyncio
@respx.mock
async def test_listar_faz_login_uma_vez_e_reutiliza_token():
    login = respx.post("https://login.test/Login/autenticar").mock(
        return_value=httpx.Response(200, text="TOKEN123")
    )
    lista = respx.post("https://api.test/ChamadosSuporte/lista").mock(
        return_value=httpx.Response(200, json={"root": [], "total": 0})
    )

    async with httpx.AsyncClient() as http:
        client = DeskClient(_config(), http=http)
        r1 = await client.listar("ChamadosSuporte")
        r2 = await client.listar("ChamadosSuporte")

    assert r1 == {"root": [], "total": 0}
    assert r2 == {"root": [], "total": 0}
    assert login.call_count == 1  # login só uma vez
    assert lista.call_count == 2


@pytest.mark.asyncio
@respx.mock
async def test_listar_renova_token_em_401():
    respx.post("https://login.test/Login/autenticar").mock(
        side_effect=[
            httpx.Response(200, text="TOKEN-AAAAAAA"),
            httpx.Response(200, text="TOKEN-BBBBBBB"),
        ]
    )
    respx.post("https://api.test/ChamadosSuporte/lista").mock(
        side_effect=[
            httpx.Response(401, text="token expirado"),
            httpx.Response(200, json={"root": [{"Chave": 1}], "total": 1}),
        ]
    )

    async with httpx.AsyncClient() as http:
        client = DeskClient(_config(), http=http)
        result = await client.listar("ChamadosSuporte")
    assert result["total"] == 1


@pytest.mark.asyncio
@respx.mock
async def test_login_falha_propaga_desk_auth_error():
    respx.post("https://login.test/Login/autenticar").mock(
        return_value=httpx.Response(500, text="boom")
    )
    async with httpx.AsyncClient() as http:
        client = DeskClient(_config(), http=http)
        with pytest.raises(DeskAuthError):
            await client.listar("ChamadosSuporte")


@pytest.mark.asyncio
@respx.mock
async def test_lista_erro_4xx_propaga_desk_api_error():
    respx.post("https://login.test/Login/autenticar").mock(
        return_value=httpx.Response(200, text="TOKEN123456")
    )
    respx.post("https://api.test/ChamadosSuporte/lista").mock(
        return_value=httpx.Response(400, text="bad request")
    )
    async with httpx.AsyncClient() as http:
        client = DeskClient(_config(), http=http)
        with pytest.raises(DeskAPIError) as exc:
            await client.listar("ChamadosSuporte")
    assert exc.value.status_code == 400


@pytest.mark.asyncio
@respx.mock
async def test_listar_paginado_percorre_paginas():
    respx.post("https://login.test/Login/autenticar").mock(
        return_value=httpx.Response(200, text="TOKEN-PAG")
    )
    pagina1 = [{"Chave": i} for i in range(3000)]
    pagina2 = [{"Chave": 3000 + i} for i in range(500)]
    respx.post("https://api.test/ChamadosSuporte/lista").mock(
        side_effect=[
            httpx.Response(200, json={"root": pagina1, "total": 3500}),
            httpx.Response(200, json={"root": pagina2, "total": 3500}),
        ]
    )
    async with httpx.AsyncClient() as http:
        client = DeskClient(_config(), http=http)
        tudo = await client.listar_paginado("ChamadosSuporte")
    assert len(tudo) == 3500
    assert tudo[0]["Chave"] == 0
    assert tudo[-1]["Chave"] == 3499
