"""Testes unitários das funções puras de ably_chat (parsing e filtros)."""
from __future__ import annotations

from datetime import datetime

import pytest

from src import ably_chat


class _FakeMsg:
    """Simula um objeto Ably.Message."""
    def __init__(self, name: str, data):
        self.name = name
        self.data = data


def test_parse_alerta_opers_multiplos_ignora_zeros():
    assert ably_chat._parse_alerta_opers("786,0,123") == [786, 123]
    assert ably_chat._parse_alerta_opers("0") == []
    assert ably_chat._parse_alerta_opers("") == []
    assert ably_chat._parse_alerta_opers(None) == []
    assert ably_chat._parse_alerta_opers(786) == [786]


def test_classificar_msg_por_flag():
    assert ably_chat.classificar_msg({"Criar": "true"}) == "cliente"
    assert ably_chat.classificar_msg({"Alerta": "true"}) == "operador"
    assert ably_chat.classificar_msg({"Ocultar": "true"}) == "typing"
    assert ably_chat.classificar_msg({"Msg": "oi"}) is None


def test_normalizar_msg_cliente():
    dados = {
        "Criar": "true",
        "Msg": "Bom dia",
        "NomeCompleto": "Flavia pires",
        "CodUsuario": "85187",
        "AlertaOpers": "786,0",
        "SMS": "flavia@empresa.com",
        "DH": "2026-04-24 08:06:38",
    }
    quando = datetime(2026, 4, 24, 8, 6, 40)
    r = ably_chat.normalizar_msg(dados, quando)
    assert r["tipo"] == "cliente"
    assert r["nome_emissor"] == "Flavia pires"
    assert r["cod_usuario_cliente"] == "85187"
    assert r["operadores_envolvidos"] == [786]
    assert r["texto"] == "Bom dia"
    assert r["email_cliente"] == "flavia@empresa.com"
    assert r["dh_mensagem"] == "2026-04-24 08:06:38"


def test_normalizar_msg_operador_sem_email():
    r = ably_chat.normalizar_msg(
        {"Alerta": "true", "Msg": "ok", "CodUsuario": "1", "SMS": "0"},
        datetime.now(),
    )
    assert r["tipo"] == "operador"
    assert r["email_cliente"] is None


def test_msg_pertence_ao_par():
    msg = {
        "cod_usuario_cliente": "85187",
        "operadores_envolvidos": [786, 123],
    }
    assert ably_chat.msg_pertence_ao_par(msg, cod_usuario=85187, chave_operador=786)
    assert ably_chat.msg_pertence_ao_par(msg, cod_usuario=85187, chave_operador=123)
    assert not ably_chat.msg_pertence_ao_par(msg, cod_usuario=99, chave_operador=786)
    assert not ably_chat.msg_pertence_ao_par(msg, cod_usuario=85187, chave_operador=999)
    # Sem filtros: aceita
    assert ably_chat.msg_pertence_ao_par(msg, cod_usuario=None, chave_operador=None)


def test_msg_pertence_ao_par_filtra_so_cliente():
    """Quando operador não é informado, só o cliente precisa bater."""
    msg = {
        "cod_usuario_cliente": "85187",
        "operadores_envolvidos": [786],
    }
    assert ably_chat.msg_pertence_ao_par(msg, cod_usuario=85187, chave_operador=None)
    assert not ably_chat.msg_pertence_ao_par(msg, cod_usuario=99, chave_operador=None)


def test_msg_pertence_cod_usuario_invalido_retorna_false():
    msg = {"cod_usuario_cliente": None, "operadores_envolvidos": [786]}
    assert not ably_chat.msg_pertence_ao_par(msg, cod_usuario=85187, chave_operador=786)


@pytest.mark.asyncio
async def test_escutar_chat_levanta_se_ably_nao_instalado(monkeypatch):
    monkeypatch.setattr(ably_chat, "AblyRealtime", None)
    with pytest.raises(ably_chat.AblyNaoDisponivel):
        await ably_chat.escutar_chat(1.0)
