"""Cobre bugs laterais 4.1 e 4.2 da v3 da investigação:

- obter_chamado deve enriquecer operador/status/cliente mesmo quando o
  payload do Desk vem envelopado em `{"TChamado": {...}}` com campos
  `CodOperador=[{id,text}]` (padrão do endpoint singular, diferente da lista).
- obter_chamado(incluir_historico=True) deve resolver CodChamado sozinho
  a partir do TChamado e passar para listar_historico.
"""

from __future__ import annotations

from datetime import datetime

import pytest

from src import enrichment
from src.enrichment import BRT
from src.operadores_cache import OperadoresCache
from src.tools import chamados as tool_chamados


class FakeClient:
    def __init__(
        self,
        detalhe_envelopado: dict,
        operadores: list[dict] | None = None,
        historico_resposta: dict | None = None,
    ):
        self.detalhe = detalhe_envelopado
        self.operadores = operadores or []
        self.historico_resposta = historico_resposta or {"root": []}
        self.chave_historico_recebida: int | None = None

        class _Cfg:
            back_req_token = None

        self.config = _Cfg()

    async def obter(self, entidade, chave, *, body_extra=None):
        assert entidade == "ChamadosSuporte"
        return self.detalhe

    async def listar(self, entidade, body, *, auth_mode="login"):
        if entidade == "Operadores":
            return {"root": list(self.operadores)}
        raise RuntimeError(f"listar {entidade} não mockado")

    async def listar_historico_chamado(self, chave):
        self.chave_historico_recebida = chave
        return self.historico_resposta


_DETALHE_ENVELOPADO = {
    "TChamado": {
        "Chave": 1624098,
        "CodChamado": "0426-011564",
        "Assunto": "Suporte — Faturamento",
        "DataCriacao": "2026-04-20",
        "HoraCriacao": "09:35:44",
        "DataAlteracao": "2026-04-20",
        "HoraAlteracao": "10:00:00",
        "DataFinalizacao": "0000-00-00",
        "HoraFinalizacao": "",
        "CodStatusAtual": [{"id": "367", "sequence": "000006", "text": "Andamento"}],
        "CodOperador": [{"id": "605", "text": "Analice Franceschi"}],
        "CodUsuario": [{"id": "78806", "text": "Wagner Hammerich"}],
        "Sla1Expirado": "S",
        "Sla2Expirado": "S",
        "TempoRestantePrimeiroAtendimento": "-00:15:50",
        "TempoRestanteSegundoAtendimento": "-03:58:10",
        "TAcoes": 3,
    }
}


@pytest.fixture(autouse=True)
def travar_agora(monkeypatch):
    monkeypatch.setattr(
        enrichment, "_agora_brt", lambda: datetime(2026, 4, 20, 15, 0, 0, tzinfo=BRT)
    )


@pytest.mark.asyncio
async def test_desempacotar_detalhe_acha_campos_dentro_de_TChamado():
    plano = tool_chamados._desempacotar_detalhe(_DETALHE_ENVELOPADO)
    assert plano["CodChamado"] == "0426-011564"
    assert plano["NomeOperador"] == "Analice Franceschi"
    assert plano["ChaveOperador"] == 605
    assert plano["NomeStatus"] == "Andamento"
    assert plano["NomeUsuario"] == "Wagner Hammerich"
    assert plano["ChaveUsuario"] == 78806


@pytest.mark.asyncio
async def test_obter_chamado_enriquece_operador_mesmo_no_detalhe():
    client = FakeClient(
        _DETALHE_ENVELOPADO,
        operadores=[
            {
                "ChaveOperador": 605,
                "NomeOperador": "Analice Franceschi",
                "OnOff": "S",
                "NomeGrupoPrincipal": "Suporte - ERP",
                "Ativo": "S",
            }
        ],
    )
    cache = OperadoresCache(client, ttl_segundos=60)
    resultado = await tool_chamados.obter_chamado(
        client, chave=1624098, incluir_historico=False, operadores=cache
    )
    chamado = resultado["chamado"]
    assert chamado["codigo"] == "0426-011564"
    assert chamado["operador"] == "Analice Franceschi"
    assert chamado["operador_chave"] == 605
    assert chamado["operador_online"] is True
    assert chamado["operador_grupo_principal"] == "Suporte - ERP"
    assert chamado["status"] == "Andamento"
    assert chamado["sla1_expirado"] is True


@pytest.mark.asyncio
async def test_obter_chamado_usa_chave_para_historico():
    client = FakeClient(
        _DETALHE_ENVELOPADO,
        historico_resposta={
            "root": [
                {
                    "DataAcao": "2026-04-20",
                    "HoraAcaoInicio": "09:40:12",
                    "Operador": [{"id": "605", "text": "Analice"}],
                    "Descricao": "oi",
                    "Aberto": "S",
                }
            ],
            "total": "1",
        },
    )
    resultado = await tool_chamados.obter_chamado(
        client, chave=1624098, incluir_historico=True
    )
    historico = resultado["historico"]
    assert "erro" not in historico
    assert historico["chave"] == 1624098
    assert historico["total"] == 1
    assert client.chave_historico_recebida == 1624098
