"""Testes do cache SQLite persistente (Fase 2)."""

from __future__ import annotations

import asyncio
import time
from pathlib import Path

import pytest

from src.desk_cache import DeskCache
from src.historico import listar_historico


@pytest.fixture
def cache_temp(tmp_path: Path) -> DeskCache:
    c = DeskCache(
        tmp_path / "test.sqlite",
        ttl_ativo_segundos=300,
        ttl_finalizado_dias=30,
        enabled=True,
    )
    yield c
    c.close()


# ---------------------------------------------------------------------------
# Cache de chamado
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_miss_quando_chamado_nao_cacheado(cache_temp):
    assert await cache_temp.get_chamado(123) is None


@pytest.mark.asyncio
async def test_set_e_get_chamado_ativo(cache_temp):
    payload = {"chamado": {"chave": 1, "codigo": "0426-0001", "ativo": True}}
    await cache_temp.set_chamado(
        1, payload, data_alteracao="2026-04-21", hora_alteracao="10:00:00", finalizado=False
    )
    obtido = await cache_temp.get_chamado(1)
    assert obtido == payload


@pytest.mark.asyncio
async def test_invalidacao_por_data_alteracao_mudou(cache_temp):
    payload = {"chamado": {"chave": 1}}
    await cache_temp.set_chamado(
        1, payload, data_alteracao="2026-04-21", hora_alteracao="10:00:00", finalizado=False
    )
    # Vem uma listagem nova dizendo que mudou 11:00
    obtido = await cache_temp.get_chamado(
        1, data_alteracao_atual="2026-04-21", hora_alteracao_atual="11:00:00"
    )
    assert obtido is None


@pytest.mark.asyncio
async def test_mesma_data_alteracao_nao_invalida(cache_temp):
    payload = {"chamado": {"chave": 1}}
    await cache_temp.set_chamado(
        1, payload, data_alteracao="2026-04-21", hora_alteracao="10:00:00", finalizado=False
    )
    obtido = await cache_temp.get_chamado(
        1, data_alteracao_atual="2026-04-21", hora_alteracao_atual="10:00:00"
    )
    assert obtido == payload


@pytest.mark.asyncio
async def test_ttl_ativo_expira(tmp_path):
    c = DeskCache(tmp_path / "t.sqlite", ttl_ativo_segundos=0, enabled=True)
    await c.set_chamado(
        1, {"chamado": {"chave": 1}},
        data_alteracao="2026-04-21", hora_alteracao="10:00:00", finalizado=False,
    )
    # TTL=0 → sempre expirado
    assert await c.get_chamado(1) is None
    c.close()


@pytest.mark.asyncio
async def test_finalizado_tem_ttl_longo(tmp_path):
    """Finalizado respeita ttl_finalizado, não ttl_ativo — fica vivo mesmo com ativo=0."""
    c = DeskCache(
        tmp_path / "t.sqlite", ttl_ativo_segundos=0, ttl_finalizado_dias=30, enabled=True
    )
    await c.set_chamado(
        1, {"chamado": {"chave": 1, "ativo": False}},
        data_alteracao="2026-04-21", hora_alteracao="10:00:00", finalizado=True,
    )
    obtido = await c.get_chamado(1)
    assert obtido is not None
    c.close()


# ---------------------------------------------------------------------------
# Cache de histórico
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_set_e_get_historico(cache_temp):
    payload = {"chave": 1, "total": 2, "acoes": [{"sequencia": 1}, {"sequencia": 2}]}
    await cache_temp.set_historico(
        1, payload,
        data_alteracao_chamado="2026-04-21", hora_alteracao_chamado="10:00:00",
        finalizado=False,
    )
    assert await cache_temp.get_historico(1) == payload


@pytest.mark.asyncio
async def test_historico_invalida_quando_chamado_altera(cache_temp):
    await cache_temp.set_historico(
        1, {"acoes": []},
        data_alteracao_chamado="2026-04-21", hora_alteracao_chamado="10:00:00",
        finalizado=False,
    )
    assert await cache_temp.get_historico(
        1, data_alteracao_atual="2026-04-22", hora_alteracao_atual="09:00:00"
    ) is None


# ---------------------------------------------------------------------------
# Cache desabilitado
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cache_desabilitado_sempre_miss(tmp_path):
    c = DeskCache(tmp_path / "t.sqlite", enabled=False)
    await c.set_chamado(1, {"a": 1}, data_alteracao=None, hora_alteracao=None, finalizado=False)
    assert await c.get_chamado(1) is None
    assert await c.get_historico(1) is None


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_stats_conta_itens(cache_temp):
    await cache_temp.set_chamado(
        1, {"x": 1}, data_alteracao=None, hora_alteracao=None, finalizado=False
    )
    await cache_temp.set_chamado(
        2, {"x": 2}, data_alteracao=None, hora_alteracao=None, finalizado=True
    )
    await cache_temp.set_historico(
        1, {"h": 1}, data_alteracao_chamado=None, hora_alteracao_chamado=None, finalizado=False
    )
    s = await cache_temp.stats()
    assert s["enabled"] is True
    assert s["chamados_total"] == 2
    assert s["chamados_finalizados"] == 1
    assert s["historicos_total"] == 1


# ---------------------------------------------------------------------------
# Integração com listar_historico
# ---------------------------------------------------------------------------


class FakeClient:
    """Mock do DeskClient para teste de integração."""

    def __init__(self, historico_resposta, snapshot_resposta):
        self.historico_resposta = historico_resposta
        self.snapshot_resposta = snapshot_resposta
        self.chamadas_historico = 0
        self.chamadas_snapshot = 0

    async def listar_historico_chamado(self, chave):
        self.chamadas_historico += 1
        return self.historico_resposta

    async def listar(self, entidade, body, *, auth_mode="login"):
        if entidade == "ChamadosSuporte":
            self.chamadas_snapshot += 1
            return self.snapshot_resposta
        return {"root": []}


@pytest.mark.asyncio
async def test_listar_historico_usa_cache_na_segunda_chamada(tmp_path):
    client = FakeClient(
        historico_resposta={
            "root": [{"Chave": "1", "Descricao": "teste", "DataAcao": "2026-04-21",
                      "HoraAcaoInicio": "10:00:00",
                      "Operador": [{"id": "1", "text": "Op"}], "Aberto": "S"}],
            "total": "1",
        },
        snapshot_resposta={
            "root": [{"Chave": 999, "DataAlteracao": "2026-04-21",
                      "HoraAlteracao": "10:00:00", "DataFinalizacao": "0000-00-00"}],
            "total": 1,
        },
    )
    cache = DeskCache(tmp_path / "t.sqlite", enabled=True)

    try:
        r1 = await listar_historico(client, chave=999, cache=cache)
        r2 = await listar_historico(client, chave=999, cache=cache)

        assert r1["_cache_hit"] is False
        assert r2["_cache_hit"] is True
        # Só uma chamada ao histórico — segunda veio do cache
        assert client.chamadas_historico == 1
        # Snapshot só na 1ª (cache fresh <60s pula snapshot na 2ª — otimização)
        assert client.chamadas_snapshot == 1
    finally:
        cache.close()


@pytest.mark.asyncio
async def test_listar_historico_refetcha_quando_chamado_muda(tmp_path):
    """Força bypass do 'fresh' com janela zero pra validar invalidação real."""
    hist1 = {
        "root": [{"Chave": "1", "Descricao": "v1", "DataAcao": "2026-04-21",
                  "HoraAcaoInicio": "10:00:00",
                  "Operador": [{"id": "1", "text": "Op"}], "Aberto": "S"}],
        "total": "1",
    }
    client = FakeClient(
        historico_resposta=hist1,
        snapshot_resposta={
            "root": [{"Chave": 999, "DataAlteracao": "2026-04-21",
                      "HoraAlteracao": "10:00:00", "DataFinalizacao": "0000-00-00"}],
        },
    )
    cache = DeskCache(tmp_path / "t.sqlite", enabled=True)

    try:
        r1 = await listar_historico(client, chave=999, cache=cache)
        assert r1["_cache_hit"] is False

        # Monkeypatch: força snapshot rodar (janela 0) simulando cache envelhecido
        import src.desk_cache
        original = src.desk_cache.DeskCache.historico_esta_fresh
        async def nao_fresh(*a, **kw):
            return False
        src.desk_cache.DeskCache.historico_esta_fresh = nao_fresh
        try:
            # Chamado foi alterado
            client.snapshot_resposta = {
                "root": [{"Chave": 999, "DataAlteracao": "2026-04-21",
                          "HoraAlteracao": "11:30:00", "DataFinalizacao": "0000-00-00"}],
            }
            r2 = await listar_historico(client, chave=999, cache=cache)
            assert r2["_cache_hit"] is False
            assert client.chamadas_historico == 2  # refetch
        finally:
            src.desk_cache.DeskCache.historico_esta_fresh = original
    finally:
        cache.close()


@pytest.mark.asyncio
async def test_ignorar_cache_forca_refresh(tmp_path):
    client = FakeClient(
        historico_resposta={"root": [], "total": "0"},
        snapshot_resposta={"root": [{"Chave": 999, "DataAlteracao": "2026-04-21",
                                      "HoraAlteracao": "10:00:00",
                                      "DataFinalizacao": "0000-00-00"}]},
    )
    cache = DeskCache(tmp_path / "t.sqlite", enabled=True)
    try:
        await listar_historico(client, chave=999, cache=cache)
        await listar_historico(client, chave=999, cache=cache, ignorar_cache=True)
        assert client.chamadas_historico == 2
    finally:
        cache.close()
