"""Testes do cache de operadores — TTL, normalização de nome, lookups."""

from __future__ import annotations

import pytest

from src.operadores_cache import OperadoresCache, _normalizar_nome


class FakeClient:
    def __init__(self, root: list[dict]):
        self.root = root
        self.calls = 0

    async def listar(self, entidade, body):
        assert entidade == "Operadores"
        self.calls += 1
        return {"root": list(self.root)}


@pytest.mark.asyncio
async def test_lookup_por_nome_ignorando_maiusculas_e_espacos():
    client = FakeClient(
        [
            {
                "ChaveOperador": 615,
                "NomeOperador": "Agata Barreto",
                "OnOff": "N",
                "NomeGrupoPrincipal": "Suporte - Folha de Pagamento",
                "Ativo": "S",
            },
            {
                "ChaveOperador": 777,
                "NomeOperador": "Ana Paula Mendes",
                "OnOff": "S",
                "Ativo": "S",
            },
        ]
    )
    cache = OperadoresCache(client, ttl_segundos=30)
    info = await cache.info_por_nome("  AGATA  barreto  ")
    assert info is not None
    assert info["chave"] == 615
    assert info["online"] is False
    assert info["grupo_principal"] == "Suporte - Folha de Pagamento"


@pytest.mark.asyncio
async def test_lookup_por_chave():
    client = FakeClient(
        [{"ChaveOperador": 42, "NomeOperador": "X", "OnOff": "S", "Ativo": "S"}]
    )
    cache = OperadoresCache(client, ttl_segundos=30)
    info = await cache.info_por_chave(42)
    assert info is not None
    assert info["online"] is True


@pytest.mark.asyncio
async def test_onoff_desconhecido_vira_none():
    client = FakeClient(
        [{"ChaveOperador": 1, "NomeOperador": "Sem Flag", "OnOff": "", "Ativo": "S"}]
    )
    cache = OperadoresCache(client, ttl_segundos=30)
    info = await cache.info_por_nome("Sem Flag")
    assert info["online"] is None


@pytest.mark.asyncio
async def test_cache_respeita_ttl_e_reutiliza():
    client = FakeClient(
        [{"ChaveOperador": 1, "NomeOperador": "A", "OnOff": "S", "Ativo": "S"}]
    )
    cache = OperadoresCache(client, ttl_segundos=3600)
    await cache.info_por_nome("A")
    await cache.info_por_nome("A")
    await cache.info_por_nome("A")
    assert client.calls == 1


@pytest.mark.asyncio
async def test_falha_na_api_nao_levanta_so_mantem_vazio():
    class Quebrado:
        async def listar(self, *a, **k):
            raise RuntimeError("boom")

    cache = OperadoresCache(Quebrado(), ttl_segundos=30)
    assert await cache.info_por_nome("qualquer") is None


def test_normalizar_nome():
    assert _normalizar_nome("  Agata   Barreto ") == "agata barreto"
    assert _normalizar_nome(None) == ""
    assert _normalizar_nome("") == ""


@pytest.mark.asyncio
async def test_resolver_prioriza_chave_sobre_nome():
    client = FakeClient(
        [
            {"ChaveOperador": 1, "NomeOperador": "Nome Antigo", "OnOff": "N", "Ativo": "S"},
        ]
    )
    cache = OperadoresCache(client, ttl_segundos=30)
    # nome que não existe no cache, mas chave existe → resolver por chave
    info = await cache.resolver(nome="Nome Mudou", chave=1)
    assert info is not None
    assert info["online"] is False
