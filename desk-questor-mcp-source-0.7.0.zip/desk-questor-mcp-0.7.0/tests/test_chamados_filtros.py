"""Testes da tool listar_chamados_ativos — filtros client-side + presença."""

from __future__ import annotations

from datetime import datetime

import pytest

from src import enrichment
from src.enrichment import BRT
from src.operadores_cache import OperadoresCache
from src.tools import chamados as tool_chamados


class FakeClient:
    def __init__(self, registros: list[dict], operadores: list[dict] | None = None):
        self.registros = registros
        self.operadores = operadores or []

    async def listar(self, entidade, body):
        if entidade == "Operadores":
            return {"root": list(self.operadores)}
        if entidade == "ChamadosSuporte":
            return {"root": list(self.registros), "total": len(self.registros)}
        raise RuntimeError(f"entidade {entidade} não mockada")


def _chamado(
    chave: int,
    data_criacao: str,
    data_alteracao: str | None = None,
    operador: str | None = None,
    chave_operador: int | None = None,
    grupo: str = "Suporte - Web",
    status: str = "Em Andamento",
    finalizado: bool = False,
) -> dict:
    return {
        "Chave": chave,
        "CodChamado": f"0426-{chave:06d}",
        "Assunto": f"Chamado {chave}",
        "DataCriacao": data_criacao,
        "HoraCriacao": "09:00:00",
        "DataAlteracao": data_alteracao or data_criacao,
        "HoraAlteracao": "10:00:00",
        "DataFinalizacao": "2026-04-20" if finalizado else "0000-00-00",
        "HoraFinalizacao": "18:00:00" if finalizado else "",
        "NomeStatus": status,
        "NomeGrupo": grupo,
        "NomeOperador": operador,
        "ChaveOperador": chave_operador,
        "NomeUsuario": "Cliente",
        "SobrenomeUsuario": "Teste",
        "Sla1Expirado": "N",
        "Sla2Expirado": "N",
        "TempoRestantePrimeiroAtendimento": "04:00:00",
        "TempoRestanteSegundoAtendimento": "08:00:00",
        "QtAcoes": 0,
    }


@pytest.fixture(autouse=True)
def travar_agora(monkeypatch):
    agora = datetime(2026, 4, 20, 15, 0, 0, tzinfo=BRT)
    monkeypatch.setattr(enrichment, "_agora_brt", lambda: agora)


@pytest.mark.asyncio
async def test_filtro_por_data_criacao_inclusivo_nas_duas_pontas():
    registros = [
        _chamado(1, "2026-04-18"),
        _chamado(2, "2026-04-15"),
        _chamado(3, "2026-04-10"),
        _chamado(4, "2026-04-01"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados_ativos(
        client,
        data_criacao_de="2026-04-10",
        data_criacao_ate="2026-04-15",
        limite=100,
    )
    chaves = sorted(c.chave for c in chamados)
    assert chaves == [2, 3]


@pytest.mark.asyncio
async def test_trabalhado_hoje_mas_aberto_antes():
    registros = [
        _chamado(1, data_criacao="2026-04-10", data_alteracao="2026-04-20"),
        _chamado(2, data_criacao="2026-04-20", data_alteracao="2026-04-20"),
        _chamado(3, data_criacao="2026-04-10", data_alteracao="2026-04-15"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados_ativos(
        client,
        data_alteracao_de="2026-04-20",
        data_criacao_ate="2026-04-19",
        limite=100,
    )
    assert [c.chave for c in chamados] == [1]


@pytest.mark.asyncio
async def test_filtro_status_multiplos_case_insensitive():
    registros = [
        _chamado(1, "2026-04-20", status="Em Andamento"),
        _chamado(2, "2026-04-20", status="Aguardando Atendimento"),
        _chamado(3, "2026-04-20", status="Resolvido"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados_ativos(
        client,
        status=["em andamento", "aguardando atendimento"],
        limite=100,
    )
    assert sorted(c.chave for c in chamados) == [1, 2]


@pytest.mark.asyncio
async def test_apenas_ativos_true_ignora_finalizados():
    registros = [
        _chamado(1, "2026-04-20"),
        _chamado(2, "2026-04-20", finalizado=True),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados_ativos(client, limite=100)
    assert [c.chave for c in chamados] == [1]


@pytest.mark.asyncio
async def test_presenca_do_operador_eh_enriquecida():
    registros = [
        _chamado(1, "2026-04-20", operador="Agata Barreto", chave_operador=615),
        _chamado(2, "2026-04-20", operador="Ana Paula Mendes", chave_operador=777),
        _chamado(3, "2026-04-20", operador=None, chave_operador=None),
    ]
    operadores = [
        {
            "ChaveOperador": 615,
            "NomeOperador": "Agata Barreto",
            "OnOff": "N",
            "NomeGrupoPrincipal": "Suporte - Folha",
            "Ativo": "S",
        },
        {
            "ChaveOperador": 777,
            "NomeOperador": "Ana Paula Mendes",
            "OnOff": "S",
            "Ativo": "S",
        },
    ]
    client = FakeClient(registros, operadores=operadores)
    cache = OperadoresCache(client, ttl_segundos=60)
    chamados = await tool_chamados.listar_chamados_ativos(
        client, limite=100, operadores=cache
    )
    por_chave = {c.chave: c for c in chamados}
    assert por_chave[1].operador_online is False
    assert por_chave[1].operador_grupo_principal == "Suporte - Folha"
    assert por_chave[1].operador_chave == 615
    assert por_chave[2].operador_online is True
    # sem operador → online fica None
    assert por_chave[3].operador_online is None


@pytest.mark.asyncio
async def test_listar_ativos_hoje_delega_para_generico():
    registros = [
        _chamado(1, "2026-04-20"),
        _chamado(2, "2026-04-19"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados_ativos_hoje(client, limite=100)
    # 2026-04-20 é o dia travado no fixture
    assert [c.chave for c in chamados] == [1]


@pytest.mark.asyncio
async def test_filtro_por_operador_exato():
    registros = [
        _chamado(1, "2026-04-20", operador="Fulano"),
        _chamado(2, "2026-04-20", operador="Beltrano"),
    ]
    client = FakeClient(registros)
    chamados = await tool_chamados.listar_chamados_ativos(
        client, operador="Fulano", limite=100
    )
    assert [c.chave for c in chamados] == [1]
