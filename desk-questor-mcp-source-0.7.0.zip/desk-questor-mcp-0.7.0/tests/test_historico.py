"""Testes da normalização de histórico de chamados.

Contrato validado contra o fonte oficial do coletor (HubtechData): endpoint
`POST /ChamadoHistoricos/lista` com body JSON `{Chave, Solicitante, Colunas}`.
"""

from __future__ import annotations

import pytest

from src import historico


class FakeClient:
    """Simula o DeskClient — apenas os métodos usados pelo módulo historico."""

    def __init__(
        self,
        *,
        historico_resposta: dict | None = None,
        historico_falha: Exception | None = None,
        lista_respostas: dict[str, dict] | None = None,
    ):
        self.historico_resposta = historico_resposta
        self.historico_falha = historico_falha
        self.lista_respostas = lista_respostas or {}
        self.chamadas_historico: list[int] = []
        self.chamadas_json: list[tuple[str, dict]] = []

    async def listar_historico_chamado(self, chave):
        self.chamadas_historico.append(chave)
        if self.historico_falha:
            raise self.historico_falha
        return self.historico_resposta or {"root": [], "total": "0"}

    async def listar(self, entidade, body, *, auth_mode="login"):
        self.chamadas_json.append((entidade, body))
        if entidade in self.lista_respostas:
            return self.lista_respostas[entidade]
        return {"root": [], "total": "0"}


@pytest.mark.asyncio
async def test_endpoint_canonico_chamadohistoricos_json():
    client = FakeClient(
        historico_resposta={
            "root": [
                {
                    "Chave": "1",
                    "Descricao": "Bom dia. Pode me enviar o XML?",
                    "Status": [{"id": "1", "sequence": "000005", "text": "Aberto"}],
                    "Aberto": "S",
                    "DataAcao": "2026-04-20",
                    "HoraAcaoInicio": "09:40:12",
                    "HoraAcaoFim": "09:45:00",
                    "Operador": [{"id": "10", "text": "Jessica Peruzzo"}],
                    "Solicitante": [],
                    "NomeFormaAtendimento": "E-mail",
                    "TotalHoras": "00:04:48",
                },
                {
                    "Chave": "2",
                    "Descricao": "Cliente não respondeu.",
                    "Status": [{"id": "2", "sequence": "000010", "text": "Em andamento"}],
                    "Aberto": "N",
                    "DataAcao": "2026-04-20",
                    "HoraAcaoInicio": "10:15:44",
                    "Operador": [{"id": "10", "text": "Jessica Peruzzo"}],
                    "NomeFormaAtendimento": "Interno",
                    "TotalHoras": "00:01:00",
                },
            ],
            "total": "2",
        }
    )
    resultado = await historico.listar_historico(client, chave=1624098)

    assert resultado["endpoint"] == "ChamadoHistoricos"
    assert resultado["chave"] == 1624098
    assert resultado["total"] == 2
    assert client.chamadas_historico == [1624098]

    publica = resultado["acoes"][0]
    assert publica["publico"] is True
    assert publica["operador"] == "Jessica Peruzzo"
    assert publica["status"]["text"] == "Aberto"
    assert publica["data_hora"] == "2026-04-20 09:40:12"
    assert publica["tipo"] == "E-mail"

    interna = resultado["acoes"][1]
    assert interna["publico"] is False


@pytest.mark.asyncio
async def test_resolve_chave_a_partir_do_codigo():
    client = FakeClient(
        historico_resposta={"root": [], "total": "0"},
        lista_respostas={
            "ChamadosSuporte": {
                "root": [{"Chave": 1624098, "CodChamado": "0426-011564"}],
                "total": "1",
            }
        },
    )
    resultado = await historico.listar_historico(client, codigo="0426-011564")
    assert resultado["chave"] == 1624098
    assert client.chamadas_historico == [1624098]


@pytest.mark.asyncio
async def test_chamado_sem_acoes_retorna_lista_vazia_sem_erro():
    client = FakeClient(historico_resposta={"root": [], "total": "0"})
    resultado = await historico.listar_historico(client, chave=42)
    assert resultado["total"] == 0
    assert resultado["acoes"] == []
    assert resultado["endpoint"] == "ChamadoHistoricos"


@pytest.mark.asyncio
async def test_exige_chave_ou_codigo():
    client = FakeClient()
    with pytest.raises(ValueError):
        await historico.listar_historico(client)


@pytest.mark.asyncio
async def test_levanta_quando_resolucao_de_chave_falha():
    client = FakeClient(
        lista_respostas={"ChamadosSuporte": {"root": [], "total": "0"}}
    )
    with pytest.raises(RuntimeError, match="resolver Chave"):
        await historico.listar_historico(client, codigo="0426-XXXXXX")


def test_parse_publico_tolerante():
    assert historico._parse_publico("S") is True
    assert historico._parse_publico("N") is False
    assert historico._parse_publico(True) is True
    assert historico._parse_publico(0) is False
    assert historico._parse_publico(None) is False


def test_detectar_tipo_usa_fallback_quando_ausente():
    assert historico._detectar_tipo({"Descricao": "x"}, publico=True) == "Resposta Pública"
    assert historico._detectar_tipo({"Descricao": "x"}, publico=False) == "Comentário Interno"


def test_detectar_tipo_prefere_forma_atendimento():
    assert (
        historico._detectar_tipo({"NomeFormaAtendimento": "Telefone"}, publico=True)
        == "Telefone"
    )


def test_combinar_data_hora_com_data_zerada_retorna_none():
    assert historico._combinar_data_hora("0000-00-00", "00:00:00") is None
    assert historico._combinar_data_hora("", "10:00:00") is None
    assert historico._combinar_data_hora("2026-04-20", "") == "2026-04-20 00:00:00"


def test_extrai_operador_de_array_do_coletor():
    item = {"Operador": [{"id": "10", "text": "Jessica Peruzzo"}]}
    assert historico._extrair_operador(item) == "Jessica Peruzzo"


def test_extrai_status_do_array_do_coletor():
    item = {"Status": [{"id": "1", "sequence": "000030", "text": "Aguardando Aprovação"}]}
    status = historico._extrair_status(item)
    assert status["sequence"] == "000030"
    assert status["text"] == "Aguardando Aprovação"


def test_extrai_status_do_formato_flat_listaCustom():
    # Formato usado pelo endpoint /ChamadoHistoricos/listaCustom (UI)
    item = {"NomeStatus": "Resolvido", "CodStatus": "000002"}
    status = historico._extrair_status(item)
    assert status["text"] == "Resolvido"
    assert status["sequence"] == "000002"


@pytest.mark.asyncio
async def test_formato_flat_listaCustom_e_parseado_como_chat():
    """Sessão de chat vinda via /listaCustom — sem `Aberto`, sem arrays."""
    client = FakeClient(
        historico_resposta={
            "root": [
                {
                    "Chave": 2676092,
                    "CodChamado": 1624588,
                    "Descricao": "Bom dia Flavia, vou conectar novamente\n2026-04-24 08:58:22 Caciano",
                    "DataAcao": "2026-04-24",
                    "HoraAcaoInicio": "08:06:38",
                    "HoraAcaoFim": "09:26:35",
                    "NomeOperador": "Caciano Mateus",
                    "CodOperador": 786,
                    "NomeStatus": "Resolvido",
                    "CodStatus": "000002",
                    "NomeFormaAtendimento": "Chat",
                    "TotalHoras": "01:19:57",
                },
            ],
            "total": "1",
        }
    )
    resultado = await historico.listar_historico(client, chave=1624588)
    assert resultado["total"] == 1
    acao = resultado["acoes"][0]
    assert acao["operador"] == "Caciano Mateus"
    assert acao["status"]["text"] == "Resolvido"
    assert acao["tipo"] == "Chat"
    assert acao["publico"] is True  # Chat é derivado como público
    assert acao["data_hora"] == "2026-04-24 08:06:38"
