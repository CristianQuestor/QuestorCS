"""Testes do módulo de enrichment — cálculos em BRT e heurística de urgência."""

from datetime import datetime, timedelta

import pytest

from src import enrichment
from src.enrichment import (
    BRT,
    _horas_uteis_entre,
    _parse_desk_datetime,
    _parse_sn,
    _parse_tempo_restante,
    calcular_urgencia,
    enriquecer_chamado,
    ordenar_chamados,
)


def test_parse_desk_datetime_ok():
    dt = _parse_desk_datetime("2026-04-17", "09:34:32")
    assert dt == datetime(2026, 4, 17, 9, 34, 32, tzinfo=BRT)


def test_parse_desk_datetime_data_zerada():
    assert _parse_desk_datetime("0000-00-00", "") is None
    assert _parse_desk_datetime("0000-00-00", "00:00:00") is None
    assert _parse_desk_datetime("", "09:00:00") is None
    assert _parse_desk_datetime(None, None) is None


def test_parse_desk_datetime_data_invalida():
    assert _parse_desk_datetime("foo", "09:00:00") is None
    assert _parse_desk_datetime("2026-13-40", "09:00:00") is None


def test_parse_sn():
    assert _parse_sn("S") is True
    assert _parse_sn("s") is True
    assert _parse_sn("N") is False
    assert _parse_sn("") is None
    assert _parse_sn(None) is None


def test_parse_tempo_restante():
    assert _parse_tempo_restante("02:30:00") == timedelta(hours=2, minutes=30)
    assert _parse_tempo_restante("-01:15:00") == -timedelta(hours=1, minutes=15)
    assert _parse_tempo_restante("00:00:00") == timedelta(0)
    assert _parse_tempo_restante("") is None
    assert _parse_tempo_restante(None) is None


def test_calcular_urgencia_alto_por_sla_expirado():
    assert calcular_urgencia(
        sla1_expirado=True, sla2_expirado=False,
        horas_sem_resposta=0.1, tempo_restante_sla1=timedelta(hours=5),
    ) == "alto"


def test_calcular_urgencia_alto_por_sla_quase_estourando():
    assert calcular_urgencia(
        sla1_expirado=False, sla2_expirado=False,
        horas_sem_resposta=0.5, tempo_restante_sla1=timedelta(minutes=20),
    ) == "alto"


def test_calcular_urgencia_medio():
    assert calcular_urgencia(
        sla1_expirado=False, sla2_expirado=False,
        horas_sem_resposta=0.5, tempo_restante_sla1=timedelta(hours=1, minutes=30),
    ) == "medio"


def test_calcular_urgencia_baixo():
    assert calcular_urgencia(
        sla1_expirado=False, sla2_expirado=False,
        horas_sem_resposta=1.0, tempo_restante_sla1=timedelta(hours=10),
    ) == "baixo"


def test_enriquecer_chamado_ativo(monkeypatch):
    # Trava "agora" em 2026-04-17 15:00 BRT para cálculo estável
    agora_fixo = datetime(2026, 4, 17, 15, 0, 0, tzinfo=BRT)
    monkeypatch.setattr(enrichment, "_agora_brt", lambda: agora_fixo)

    raw = {
        "Chave": 1623378,
        "CodChamado": "0426-010844",
        "Assunto": "Problema no relatório X",
        "DataCriacao": "2026-04-17",
        "HoraCriacao": "09:00:00",
        "DataAlteracao": "2026-04-17",
        "HoraAlteracao": "10:00:00",
        "DataFinalizacao": "0000-00-00",
        "NomeStatus": "Aguardando Atendimento",
        "NomeUsuario": "Alessandra",
        "SobrenomeUsuario": "de Aguiar",
        "NomeGrupo": "Suporte - Web",
        "Sla1Expirado": "N",
        "Sla2Expirado": "N",
        "TempoRestantePrimeiroAtendimento": "04:00:00",
    }
    c = enriquecer_chamado(raw)
    assert c.ativo is True
    assert c.horas_aberto == 6.0  # 15h - 9h
    assert c.horas_sem_resposta == 5.0  # 15h - 10h
    assert c.cliente_nome_completo == "Alessandra de Aguiar"
    assert c.sla1_expirado is False
    assert c.urgencia == "baixo"


def test_enriquecer_chamado_finalizado(monkeypatch):
    agora_fixo = datetime(2026, 4, 17, 15, 0, 0, tzinfo=BRT)
    monkeypatch.setattr(enrichment, "_agora_brt", lambda: agora_fixo)

    raw = {
        "Chave": 1,
        "DataCriacao": "2026-04-17",
        "HoraCriacao": "09:00:00",
        "DataFinalizacao": "2026-04-17",
        "HoraFinalizacao": "12:00:00",
        "Sla1Expirado": "N",
    }
    c = enriquecer_chamado(raw)
    assert c.ativo is False
    assert c.horas_aberto == 3.0  # finalizado com 3h


def test_horas_uteis_entre_mesmo_dia_util():
    from datetime import datetime
    ini = datetime(2026, 4, 20, 9, 0, 0, tzinfo=BRT)  # segunda
    fim = datetime(2026, 4, 20, 15, 0, 0, tzinfo=BRT)
    assert _horas_uteis_entre(ini, fim) == 6.0


def test_horas_uteis_entre_atravessa_fim_de_semana():
    from datetime import datetime
    # sexta 14h → segunda 10h (pula sáb/dom)
    ini = datetime(2026, 4, 17, 14, 0, 0, tzinfo=BRT)  # sexta
    fim = datetime(2026, 4, 20, 10, 0, 0, tzinfo=BRT)  # segunda
    # sexta 14h→00h = 10h + segunda 00h→10h = 10h → 20h úteis
    assert _horas_uteis_entre(ini, fim) == 20.0


def test_horas_uteis_entre_totalmente_em_fim_de_semana():
    from datetime import datetime
    ini = datetime(2026, 4, 18, 9, 0, 0, tzinfo=BRT)   # sábado
    fim = datetime(2026, 4, 19, 23, 0, 0, tzinfo=BRT)  # domingo
    assert _horas_uteis_entre(ini, fim) == 0.0


def test_horas_uteis_ignorando_none():
    assert _horas_uteis_entre(None, None) is None


def test_ordenar_chamados_tempo_aberto_desc(monkeypatch):
    agora_fixo = datetime(2026, 4, 17, 15, 0, 0, tzinfo=BRT)
    monkeypatch.setattr(enrichment, "_agora_brt", lambda: agora_fixo)

    a = enriquecer_chamado({
        "Chave": 1, "DataCriacao": "2026-04-17", "HoraCriacao": "14:00:00",
        "DataFinalizacao": "0000-00-00", "Sla1Expirado": "N",
    })
    b = enriquecer_chamado({
        "Chave": 2, "DataCriacao": "2026-04-17", "HoraCriacao": "09:00:00",
        "DataFinalizacao": "0000-00-00", "Sla1Expirado": "N",
    })
    ordenados = ordenar_chamados([a, b], "tempo_aberto_desc")
    assert [c.chave for c in ordenados] == [2, 1]  # b está aberto há mais tempo
