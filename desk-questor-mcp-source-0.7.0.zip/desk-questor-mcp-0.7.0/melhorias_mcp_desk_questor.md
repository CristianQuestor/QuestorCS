# Melhorias Técnicas — MCP `desk-questor`

**Autor:** Fabio Puhl — Diretoria de Tecnologia
**Data:** 20/04/2026
**Repositório:** integração MCP `desk-questor` (servidor local + API Desk Manager)
**Destinatário:** Time responsável pela manutenção do MCP

---

## 1. Contexto

O MCP `desk-questor` vem sendo utilizado como camada de orquestração entre Claude (operador de análise) e o Desk Manager para monitoramento em tempo real do suporte Questor (filas, SLA, produtividade de atendentes, gargalos operacionais).

Durante análise conduzida em 20/04/2026 sobre o status do suporte (208 → 214 chamados ativos ao longo do dia), foram identificadas **três lacunas técnicas** que impedem conclusões confiáveis e limitam o valor analítico do MCP. Este documento formaliza os problemas, evidências e propostas de correção, para priorização no backlog do time responsável.

---

## 2. Resumo executivo das lacunas

| # | Lacuna | Severidade | Impacto analítico |
|---|---|---|---|
| 1 | Endpoint de histórico de ações **não responde** | Alta | Impossibilita distinguir "atendente respondeu ao cliente" de "atendente só moveu status" |
| 2 | Listagem de chamados ativos **limitada a "criados hoje"** | Alta | Ignora o passivo acumulado de dias anteriores; operadores invisíveis aparentam estar ociosos |
| 3 | Dados do chamado **não expõem presença do operador** | Média | Chamados atribuídos a operador offline passam despercebidos |

---

## 3. Lacuna 1 — Endpoint de histórico de ações não responde

### 3.1 Comportamento atual

Tool: `listar_historico_chamado(chave)`

Retorno observado para qualquer chave válida:

```json
{
  "erro": "Erro inesperado (RuntimeError): Nenhum endpoint de histórico respondeu (tentado: Acoes, ChamadosHistorico, HistoricoChamado)"
}
```

Chaves testadas em 20/04/2026 que reproduziram o erro:
- `1623969` (chamado 0426-011435)
- `1624098` (chamado 0426-011564)
- `1624241` (chamado 0426-011707)

O mesmo erro aparece quando `obter_chamado` é chamado com `incluir_historico=true` — o campo `historico` do retorno vem com `{"erro": "..."}` em vez de dados.

### 3.2 Hipótese da causa

O MCP tenta três endpoints sequenciais da API Desk (`Acoes`, `ChamadosHistorico`, `HistoricoChamado`) e nenhum responde. Possibilidades:

1. Endpoint descontinuado ou renomeado na versão atual do Desk Manager.
2. Credencial/token sem permissão para leitura de histórico.
3. Rota correta existe mas não está mapeada no cliente HTTP do MCP.

### 3.3 Comportamento esperado

Retorno estruturado por ação, em ordem cronológica:

```json
{
  "chave": 1624098,
  "total": 2,
  "acoes": [
    {
      "sequencia": 1,
      "data_hora": "2026-04-20 09:40:12",
      "operador": "Jessica Peruzzo",
      "tipo": "Resposta Pública",
      "publico": true,
      "texto": "Bom dia. Pode me enviar o XML completo do erro?",
      "anexos": []
    },
    {
      "sequencia": 2,
      "data_hora": "2026-04-20 10:15:44",
      "operador": "Jessica Peruzzo",
      "tipo": "Comentário Interno",
      "publico": false,
      "texto": "Cliente não respondeu. Aguardando.",
      "anexos": []
    }
  ]
}
```

Campos críticos: **`tipo`** e **`publico`** — é o que permite distinguir "respondeu o cliente" de "só anotou internamente" ou "só mudou status".

### 3.4 Critério de aceitação

- [ ] `listar_historico_chamado(chave=1624098)` retorna array não-vazio de ações.
- [ ] Cada ação possui `tipo`, `publico`, `data_hora`, `operador`, `texto`.
- [ ] `obter_chamado(chave=1624098, incluir_historico=true)` embute o mesmo payload no campo `historico`.
- [ ] Para um chamado com `TAcoes=0`, retorno vem como `{"chave": ..., "total": 0, "acoes": []}` (não erro).

---

## 4. Lacuna 2 — Listagem de chamados ativos limitada a "criados hoje"

### 4.1 Comportamento atual

Tool: `listar_chamados_ativos_hoje(...)`

Pelo nome e pelo comportamento observado, a tool filtra por `DataCriacao = hoje`. Isso é adequado para monitoramento intraday, mas **insuficiente para análise de produtividade e capacidade**.

### 4.2 Por que isso distorce a análise

Em 20/04/2026 o retorno indicou:
- **178 operadores ativos** cadastrados.
- **44 operadores** com ao menos um chamado "em andamento" criado hoje.
- **134 operadores restantes** aparentemente ociosos.

Os 134 operadores "invisíveis" estão, muito provavelmente, atendendo:
- chamados criados em **dias anteriores** ainda não finalizados;
- chamados de implantação (ciclo longo);
- chamados transferidos de outras filas.

Sem enxergar esse passivo, qualquer leitura de capacidade fica enviesada.

### 4.3 Proposta — nova tool `listar_chamados_ativos`

Generalização da tool atual, aceitando filtros de data:

```python
listar_chamados_ativos(
    data_criacao_de: Optional[str] = None,   # "YYYY-MM-DD"
    data_criacao_ate: Optional[str] = None,  # default = hoje
    data_alteracao_de: Optional[str] = None, # útil para ver o que se mexeu hoje
    operador: Optional[str] = None,          # filtro por operador
    grupo: Optional[str] = None,
    status: Optional[List[str]] = None,      # ex: ["Andamento", "Aguardando Atendimento"]
    sla_expirado: Optional[bool] = None,
    limite: int = 100,                        # teto maior recomendado: 1000
    ordem: str = "tempo_aberto_desc"
)
```

Casos de uso que isso destrava:

| Pergunta de negócio | Query |
|---|---|
| Quantos chamados ativos existem no total (não só de hoje)? | sem filtro de data |
| Quais chamados estão sendo trabalhados hoje mas foram abertos antes? | `data_alteracao_de=hoje`, `data_criacao_ate=ontem` |
| Qual operador tem backlog e não está pegando chamado novo? | filtrar por operador, ver distribuição por data_criacao |
| Qual fila tem chamado antigo (>7 dias) ainda aberto? | `data_criacao_ate = hoje-7` |

### 4.4 Manter compatibilidade

A tool `listar_chamados_ativos_hoje` atual pode ser mantida como **alias** de `listar_chamados_ativos(data_criacao_de=hoje, data_criacao_ate=hoje)` para não quebrar skills e workflows existentes.

### 4.5 Critério de aceitação

- [ ] Nova tool aceita todos os filtros listados acima.
- [ ] Retorno tem o mesmo schema enriquecido da tool atual (`cliente_nome_completo`, `urgencia`, `horas_aberto`, etc.).
- [ ] Performance: retorno de até 1000 chamados em < 10s.
- [ ] `listar_chamados_ativos_hoje` continua funcionando (retrocompatibilidade).

---

## 5. Lacuna 3 — Presença do operador não exposta no chamado

### 5.1 Comportamento atual

- A tool `listar_operadores` retorna o campo `OnOff` ("S"/"N") para cada operador.
- A tool `listar_chamados_ativos_hoje` retorna o nome do operador atribuído, mas **não** o status de presença.

Para cruzar as duas informações hoje é preciso fazer duas chamadas e merge local — operação razoável mas que obriga toda skill/análise a reimplementar o cruzamento.

### 5.2 Evidência de impacto

Em 20/04/2026, pelo menos **15 dos 100 chamados em "Andamento"** tinham operador com `OnOff="N"`. Exemplo:

| Chamado | Operador | OnOff | Horas sem resposta |
|---|---|---|---|
| 0426-011435 | Agata Barreto | **N** | 5,4h |
| 0426-011443 | Ana Paula Mendes | S | 5,2h |
| 0426-011664 | Taise Dayse Oliveira | S | 1,8h |

Os chamados com operador offline tendem a ficar muito tempo sem resposta, como esperado. Mas **nenhum alerta é disparado** porque não há cruzamento automático.

### 5.3 Proposta

Enriquecer o retorno de `listar_chamados_ativos_*` e `obter_chamado` com três campos novos:

```json
{
  "operador": "Agata Barreto",
  "operador_online": false,
  "operador_grupo_principal": "Suporte - Folha de Pagamento",
  "operador_chave": 615
}
```

A fonte é a mesma consulta já feita em `listar_operadores`. Sugestão de implementação: cache em memória da tabela de operadores (refresh a cada 60s) e join in-process na serialização do chamado.

### 5.4 Critério de aceitação

- [ ] Todo chamado retornado pelas tools de listagem/detalhe carrega os três campos.
- [ ] Campo `operador_online` reflete o estado atual (cache <= 60s).
- [ ] Chamados sem operador atribuído retornam `operador_online=null`.

---

## 6. Priorização sugerida

| Prioridade | Lacuna | Justificativa |
|---|---|---|
| **P0 — urgente** | #1 (histórico) | Sem histórico detalhado, qualquer análise qualitativa de atendimento fica cega. Impacta diretamente o uso do agent N3 e análises de DIR T.I. |
| **P1 — alta** | #2 (filtro de data) | Destrava análises de passivo, capacidade e produtividade — essenciais para conversas de dimensionamento de equipe com Diretoria de Suporte. |
| **P2 — média** | #3 (presença) | Correção barata (dado já existe), ganho de clareza imediato. Pode ser entregue junto com qualquer uma das anteriores. |

---

## 7. Validação pós-entrega

Sugestão de roteiro de smoke test a ser executado após o deploy:

```text
1. listar_chamados_ativos_hoje(limite=5)                 → funciona como antes
2. listar_historico_chamado(chave=<qualquer>)             → retorna lista não-vazia quando TAcoes>0
3. obter_chamado(chave=X, incluir_historico=true)         → campo historico populado
4. listar_chamados_ativos(data_criacao_de="2026-04-01",
                          data_criacao_ate="2026-04-15") → retorna chamados do período
5. Qualquer retorno de chamado                            → contém operador_online
```

---

## 8. Observações finais

- Todas as três lacunas são **do lado do MCP** (wrapper Python) — não exigem, aparentemente, alteração no Desk Manager. Investigar primeiro se os endpoints do Desk já expõem os dados necessários antes de escalar para o fornecedor.
- Após a correção da lacuna #1, vale reavaliar a tool `dashboard_n3` para incluir métricas derivadas do histórico (ex.: tempo médio até primeira resposta pública, não só até primeira ação qualquer).
- Recomendo criar repositório de smoke tests (pytest + chaves-canário de chamados) para evitar regressão.

---

**Próximos passos sugeridos:**

1. Abrir issue no Redmine referenciando este documento (projeto responsável pelo MCP).
2. Validar prioridades com Joana Pompermaier (Gerente Suporte) e Rodrigo Comin (Gerente TI).
3. Planejar entrega incremental: lacuna #1 primeiro, #3 junto, #2 em sequência.
