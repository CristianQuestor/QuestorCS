# Investigação — Endpoints da API Desk Manager (v2)

**Data:** 20/04/2026 (tarde)
**Responsável:** Fabio Puhl
**MCP envolvido:** `desk-questor` v0.3.0
**Escopo:** Mapear o contrato **real** de TODOS os endpoints `api.desk.ms` usados pelo MCP, não só o de histórico.
**Status:** ✅ Evidência colhida; correções aplicadas no wrapper.

---

## 1. Resumo do que mudou entre v1 e v2

| Item | v1 | v2 |
|---|---|---|
| Endpoint de histórico | Desconhecido, 8 rotas tentadas → 404 | Conhecido: `ChamadoHistoricos/lista` com form + BackReqToken + `CodChamado` |
| Fonte da descoberta | Inspeção do workflow `7L2r516aXil2ZGZW` | + `cfg_desk` (datalake) + call chain completo até o `ChamadoHistoricos` |
| Universo de entidades mapeadas | 7–8 (chute) | **57** (listagem canônica do datalake) |
| MCP | 0.2.0 | **0.3.1** (com `auth_mode`, `listar_form`, `horas_uteis_aberto`, login como default) |

---

## 2. Caminho completo — do schedule trigger até a API Desk

Quando queremos reaproveitar o contrato que o n8n já prova em produção, o caminho completo é este (observado nos metadados do n8n, DB id 14, tabela `workflow_entity`):

```
[Schedule Trigger 30min]    # workflow AiU6VSQx9R52gXtd
        │
        ▼
[Postgres5 — datalake DB 2] # SELECT DISTINCT C.chave, C.Cod_Chamado
        │                   #   FROM coletor_chamados C
        │                   #   LEFT JOIN desk_chamadohistoricos_dados ch
        │                   #     ON c.Chave = ch."ChaveChamado" AND c.Cod_Chamado = ch."CodChamado"
        │                   #   WHERE c.data_criacao >= '2024-02-01'
        │                   #     AND ch."ChaveChamado" IS NULL   # ainda não baixado
        │                   #   ORDER BY C.Cod_Chamado LIMIT 2000;
        │
        ▼
[Loop Over Items]           # splitInBatches — batch 1 por vez
        │                   # por item: {Chave: int, CodChamado: "0426-011564"}
        │
        ▼
[Execute Workflow2 → 7L2r516aXil2ZGZW]   # modo "each", waitForSubWorkflow
        │
        ▼
[Workflow 7L2r516aXil2ZGZW "Desk_MS_Pegar ChamadoHistoricos"]
        │
        ▼
[HTTP Request — ChamadoHistoricos/lista]   # o node chave
        │
        ├─ URL: https://api.desk.ms/ChamadoHistoricos/lista
        ├─ Method: POST
        ├─ Content-Type: application/x-www-form-urlencoded
        ├─ Authorization: {BackReqToken} (cred n8n #16)
        └─ Body form:
             Solicitante=S
             CodChamado={{ $json.CodChamado }}   # ← vem do chamador
```

Achados que isso valida:

1. **A chave está em `CodChamado` (string)**, não em `ChaveChamado` (int). O `Chave` passado no item do loop só é usado para o left join no datalake, não chega na API Desk.
2. **Modo `each`** no `executeWorkflow` = um item por execução do sub-workflow. Logo, o endpoint real recebe **um** `CodChamado` por request — não aceita lista.
3. O schedule roda a cada **30 minutos** pegando até **2000 chamados** que ainda não têm histórico baixado. Batch interval de 200ms entre páginas.

---

## 3. `cfg_desk` — catálogo canônico dos endpoints Desk

Tabela `cfg_desk` no datalake (DB id 2, schema `public`) mantém o nome **oficial** de cada entidade da API Desk + configuração de coleta para o datalake.

Schema:

| Coluna | Tipo | Uso |
|---|---|---|
| `nome` | text | nome da entidade (ex.: `ChamadosSuporte`, `ChamadoHistoricos`). É o que vai em `api.desk.ms/{nome}/lista`. |
| `ativo` | bool | se o coletor do datalake deve processar essa entidade hoje |
| `filtro` | json | corpo JSON extra a enviar em `/lista` (ordenação, colunas) |
| `data_atualizacao` / `data_atualizacao_concluida` | ts | progresso do último ciclo |
| `pegarultimaspaginas` | int | limita páginas da listagem (0 = tudo) |

### 3.1 Entidades disponíveis (57)

Estado em 20/04/2026:
- **Ativo para coleta:** `ChamadosSuporte` (pega as 3 últimas páginas por ciclo).
- **Inativas** (57 no total — mas existem na API, só não estão sendo coletadas):

```
Agendamentos, AreaICs, Ativos, AutoCategorias, Avaliacao, AvaliacaoTecnica,
BaseConhecimento, CampoExtra, Cargos, Categorias, Causas, CentroCusto,
ChamadoHistoricos, ChamadoProgramado, Chamados, Clientes, Competencias,
Contratos, Departamentos, Despesas, Documentos, EstadoCivil, Feriados,
FormaAtendimento, FrasesProntas, Funcoes, GerenteOperador, GMUDs,
GrupoEmpresas, Grupos, Habilitacao, ICs, InventarioManual, Locais,
ModeloContratos, ModeloICs, Notificacoes, NotificacoesProgramadas,
ObservadorPadrao, Operadores, PesquisaSatisfacao, Projetos, SemanaHoras,
SLA, Solicitacoes, Status, StatusICs, StatusSla, SubAtivos, SubCategorias,
Tarefas, TipoDespesas, TipoOcorrencias, Tipos, TipoSuporte, Usuarios
```

Esta lista é **a fonte canônica de nomes de entidades**. Evita confusão como `ChamadosHistorico` vs `HistoricoChamado` vs `ChamadoHistoricos` — a API aceita exatamente o nome registrado aqui.

### 3.2 Impacto no MCP

Tools do MCP que se beneficiam dessa fonte:

- **Validação de parâmetros** — `grupo` (GrupoEmpresas), `status` (Status), `operador` (Operadores) podem ser validados contra o nome canônico.
- **Novas tools possíveis sem esforço** — `SLA/lista`, `Contratos/lista`, `Usuarios/lista`, `BaseConhecimento/lista`, etc. são endpoints conhecidos. Qualquer uma com o mesmo contrato base (POST `/lista`, body JSON com `Tatual`/`Quantidade`, BackReqToken).

Não foram criadas tools novas nesta rodada — apenas registrado o catálogo. Priorização em próxima iteração.

---

## 4. Contrato real por endpoint (observado em produção)

Mapa consolidado do que **funciona hoje** nos workflows n8n:

### 4.1 Endpoints "padrão" — JSON + BackReqToken

| Entidade | URL | Body |
|---|---|---|
| `ChamadosSuporte` | `POST /ChamadosSuporte/lista` | JSON `{Tatual, Quantidade, Filtros, Ordenacao}` |
| `ChamadosSuporte` (detalhe) | `POST /ChamadosSuporte` | JSON `{Chave: <int>}` |
| Demais `/lista` genéricos (`Operadores`, `Grupos`, `Status`, `Categorias`, `Clientes`, `GrupoEmpresas`, etc.) | `POST /{nome}/lista` | mesmo contrato JSON |

Evidência: workflow `jiAHz6rY13e91RbU` ("Desk_MS_Pegar_Dados_Para_DataLake executor") node "Pegar" usa URL template `={{ $json["nome"] }}/lista` com `bodyContentType: json` e cred #16 (BackReqToken).

> **Observação:** o MCP atual tem isso como `auth_mode="login"`. Funciona no nosso tenant porque o token de login também autoriza essa rota. Mas o **padrão oficial** do workflow n8n usa **BackReqToken**. Deixamos como está (funcionando) — migrar tudo para BackReqToken é tarefa pendente se aparecer algum endpoint que quebre com token de login.

### 4.2 Endpoint `ChamadoHistoricos` — form + token de login + CodChamado

| Atributo | Valor |
|---|---|
| URL | `POST /ChamadoHistoricos/lista` |
| Content-Type | `application/x-www-form-urlencoded` |
| Authorization | **Token do login** (mesmo que autoriza os demais endpoints) |
| Body | `Solicitante=S&CodChamado=<cod>` |

Evidência: workflow `7L2r516aXil2ZGZW` node "HTTP Request". O workflow
usa a cred n8n #16 ("BackReqToken"), que — como explicado na seção 4.5 —
é apenas um token de login **pré-gerado** persistido em credencial.

Implementado no MCP 0.3.1 (`src/historico.py`), `auth_mode="login"` por default
com fallback para `auth_mode="backreq"` caso o `.env` defina a variável
`DESK_BACKREQTOKEN`.

### 4.5 Não existe "BackReqToken" na API — é só apelido de token de login

Descoberta-chave depois de analisar múltiplos workflows:

- Cred n8n **#16 "Header Auth account Desk MS BackReqToken"** → valor é um
  token estático, renovado manualmente.
- Cred n8n **#67 "Desk-Token-Gerado_Matheus"** → literalmente gerado pelo
  Matheus e colado ali. Usado por workflows ativos como
  `9zwhoKQ6kEsBw0xb` ("Monitoramento Clientes na Fila Deskmanager").
- Cred n8n **#52 "Desk"** → credencial de cabeçalho para o
  endpoint de login em `api.desk.ms/Login/autenticar` (variante form).

Todas guardam **tokens de login obtidos via `Login/autenticar`**. Não há
um segundo tipo de credencial na API Desk. Por isso, a estratégia correta
do MCP é **fazer login e usar o próprio token para tudo** — renova
automático, não depende de alguém do time atualizar cred no n8n quando
o token expira.

**Impacto no `.env` do MCP:** `DESK_BACKREQTOKEN` virou opcional de novo.
Deixar em branco que o MCP funciona via login normalmente.

### 4.3 Endpoint `Relatorios/imprimir` — JSON + cred #67

Presente em workflows "Fila Hubtech" e "Desk_MS_Pegar_Chamados_Tarefas_Relatorio". Usado para gerar relatórios em PDF/CSV.

- URL: `POST /Relatorios/imprimir`
- Auth: cred #67 ("Desk-Token-Gerado_Matheus") — token **pré-gerado e estático**, diferente de BackReqToken
- Body: JSON com parâmetros do relatório
- **Não exposto** no MCP hoje (candidato a tool futura `imprimir_relatorio`)

### 4.4 Login `api.desk.ms/Login/autenticar` vs `questor.desk.ms/Login/autenticar`

Duas URLs coexistem:
- `questor.desk.ms/Login/autenticar` — usado nos workflows antigos (cred `8dQInvpOE6nTU2zf`).
- `api.desk.ms/Login/autenticar` — alguns workflows modernos usam form body + cred #52 ("Desk").

O MCP usa a primeira (`questor.desk.ms`) com JSON body — padrão documentado no CLAUDE.md. Continua correto.

---

## 5. Divergências entre MCP atual e workflows n8n

Mapa de divergências (só as que **funcionam** hoje no MCP, mas não são exatamente o padrão do n8n):

| Endpoint MCP | Auth MCP | Auth n8n oficial | Impacto |
|---|---|---|---|
| `ChamadosSuporte/lista` | login token | **BackReqToken** | Nenhum — funcionando; mantido |
| `Operadores/lista`, `GrupoEmpresas/lista`, `Status/lista`, `Categorias/lista`, `Anexos/lista` | login token | **BackReqToken** | Nenhum — funcionando; mantido |
| `ChamadoHistoricos/lista` | ~~login + JSON~~ → form + BackReqToken | form + BackReqToken | **Corrigido na v0.3.0** |
| `ChamadosSuporte` (detalhe) | login token | BackReqToken | Nenhum — funcionando |
| Comentar / Atualizar status | endpoints "chutados" (`Comentar`, `AtualizarStatus`, `Acoes`) | não mapeados nos workflows n8n | **Risco** — nenhum workflow oficial grava; pode estar errado. Ver seção 6 |

---

## 6. Ponto em aberto — endpoints de escrita (comentar / atualizar status)

Hoje o MCP tenta múltiplos endpoints por heurística:

- `comentar_chamado`: `ChamadosSuporte/Comentar`, `Acoes`, `ChamadosSuporte/Acao`
- `atualizar_status_chamado`: `ChamadosSuporte/AtualizarStatus`, `ChamadosSuporte/Status`, `ChamadosSuporte`

Não encontramos **nenhum workflow n8n que escreva** (comentário ou status) em chamado. Todos os workflows analisados são **read-only**. Portanto não há como validar esses endpoints pela mesma técnica de inspeção.

**Recomendação:** antes de usar essas tools em produção, repetir o roteiro do Passo 1 no Desk Web (F12 → Network → clicar em "Comentar" / "Alterar status") para capturar a rota real. Até lá, tratar como "best-effort".

---

## 7. Checklist (v2)

### Endpoint de histórico
- [x] URL: `POST /ChamadoHistoricos/lista`
- [x] Content-Type: form-urlencoded
- [x] Auth: BackReqToken
- [x] Filtro: `CodChamado` (string) + `Solicitante=S`
- [x] MCP 0.3.0 entrega a correção
- [ ] Smoke test com chave `1624098` após reinício do Claude Desktop

### Catálogo de entidades
- [x] `cfg_desk` documentada como fonte canônica
- [x] 57 entidades mapeadas
- [ ] Tools para `SLA/lista`, `Contratos/lista`, `BaseConhecimento/lista`, `Usuarios/lista` (backlog — nenhuma urgente hoje)

### Endpoints de escrita
- [ ] Validar rota real de `Comentar`
- [ ] Validar rota real de `AtualizarStatus`

---

## 8. Como reproduzir as consultas usadas nesta investigação

Todas as evidências vieram de 2 queries simples no Metabase.

**Descobrir quem chama um workflow n8n (DB 14):**
```sql
SELECT w.id, w.name, w.active, node->>'name' AS node_name
FROM workflow_entity w, jsonb_array_elements(w.nodes::jsonb) node
WHERE node::text ILIKE '%<WF_ID_ALVO>%'
  AND node->>'type' = 'n8n-nodes-base.executeWorkflow';
```

**Extrair os nodes HTTP de um workflow:**
```sql
SELECT node->>'name', jsonb_pretty((node->'parameters')::jsonb)
FROM workflow_entity w, jsonb_array_elements(w.nodes::jsonb) node
WHERE w.id = '<WF_ID>'
  AND node->>'type' = 'n8n-nodes-base.httpRequest';
```

**Catálogo de entidades Desk (DB 2):**
```sql
SELECT nome, ativo, pegarultimaspaginas, filtro
FROM cfg_desk ORDER BY nome;
```

Esse trio resolve 80% das dúvidas de "qual endpoint real da API Desk para X?".
